#nullable disable
using System;
using System.Drawing;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace baitap6a
{
    public partial class frmLop : Form
    {
        private Label lblMaKhoa;
        private Label lblMaLop;
        private Label lblTenLop;
        
        private TextBox txtMaKhoa;
        private TextBox txtMaLop;
        private TextBox txtTenLop;

        private Button btnThem;
        private Button btnXoa;
        private Button btnSua;

        // Chuỗi kết nối SQL Server
        private string connectionString = "Server=LAPTOP-I2772QNH\\MSSQL2022;Database=QLSinhVien;Trusted_Connection=True;";

        public frmLop()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "frmLop";
            this.Size = new Size(420, 260);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Khởi tạo các Label
            lblMaKhoa = new Label() { Text = "Mã khoa", Location = new Point(25, 25), AutoSize = true };
            lblMaLop = new Label() { Text = "Mã lớp", Location = new Point(25, 65), AutoSize = true };
            lblTenLop = new Label() { Text = "Tên lớp", Location = new Point(25, 105), AutoSize = true };

            // Khởi tạo các TextBox
            txtMaKhoa = new TextBox() { Location = new Point(110, 22), Size = new Size(260, 25) };
            txtMaLop = new TextBox() { Location = new Point(110, 62), Size = new Size(260, 25) };
            txtTenLop = new TextBox() { Location = new Point(110, 102), Size = new Size(260, 25) };

            // Khởi tạo các Button Thêm, Xóa, Sửa
            btnThem = new Button() { Text = "Thêm", Location = new Point(110, 150), Size = new Size(75, 35) };
            btnThem.Click += new EventHandler(this.btnThem_Click);

            btnXoa = new Button() { Text = "Xóa", Location = new Point(200, 150), Size = new Size(75, 35) };
            btnXoa.Click += new EventHandler(this.btnXoa_Click);

            btnSua = new Button() { Text = "Sửa", Location = new Point(290, 150), Size = new Size(75, 35) };
            btnSua.Click += new EventHandler(this.btnSua_Click);

            // Thêm các control vào Form
            this.Controls.Add(lblMaKhoa);
            this.Controls.Add(lblMaLop);
            this.Controls.Add(lblTenLop);
            this.Controls.Add(txtMaKhoa);
            this.Controls.Add(txtMaLop);
            this.Controls.Add(txtTenLop);
            this.Controls.Add(btnThem);
            this.Controls.Add(btnXoa);
            this.Controls.Add(btnSua);
        }

        // 1. CHỨC NĂNG THÊM DỮ LIỆU
        private void btnThem_Click(object sender, EventArgs e)
        {
            string maKhoa = txtMaKhoa.Text.Trim();
            string maLop = txtMaLop.Text.Trim();
            string tenLop = txtTenLop.Text.Trim();

            // Ràng buộc: Mã khoa, Mã lớp, Tên lớp không được để trống
            if (string.IsNullOrEmpty(maKhoa) || string.IsNullOrEmpty(maLop) || string.IsNullOrEmpty(tenLop))
            {
                MessageBox.Show("Mã khoa, Mã lớp và Tên lớp không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO Lop (MaLop, TenLop, MaKhoa) VALUES (@MaLop, @TenLop, @MaKhoa)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaLop", maLop);
                        cmd.Parameters.AddWithValue("@TenLop", tenLop);
                        cmd.Parameters.AddWithValue("@MaKhoa", maKhoa);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Thêm lớp thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearFields();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi thêm dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // 2. CHỨC NĂNG XÓA DỮ LIỆU
        private void btnXoa_Click(object sender, EventArgs e)
        {
            string maLop = txtMaLop.Text.Trim();
            string maKhoa = txtMaKhoa.Text.Trim();
            string tenLop = txtTenLop.Text.Trim();

            // Ràng buộc: Mã lớp không được để trống, Mã khoa và Tên lớp phải để trống
            if (string.IsNullOrEmpty(maLop))
            {
                MessageBox.Show("Vui lòng nhập Mã lớp cần xóa!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaLop.Focus();
                return;
            }

            if (!string.IsNullOrEmpty(maKhoa) || !string.IsNullOrEmpty(tenLop))
            {
                MessageBox.Show("Khi xóa, chỉ được nhập Mã lớp, các trường Mã khoa và Tên lớp phải để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM Lop WHERE MaLop = @MaLop";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaLop", maLop);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Xóa lớp thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy Mã lớp cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi xóa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // 3. CHỨC NĂNG SỬA DỮ LIỆU
        private void btnSua_Click(object sender, EventArgs e)
        {
            string maLop = txtMaLop.Text.Trim();
            string maKhoa = txtMaKhoa.Text.Trim();
            string tenLop = txtTenLop.Text.Trim();

            // Ràng buộc: Mã lớp không được để trống, Mã khoa và Tên lớp phải có ít nhất 1 trường có dữ liệu
            if (string.IsNullOrEmpty(maLop))
            {
                MessageBox.Show("Mã lớp không được để trống khi sửa!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaLop.Focus();
                return;
            }

            if (string.IsNullOrEmpty(maKhoa) && string.IsNullOrEmpty(tenLop))
            {
                MessageBox.Show("Phải nhập ít nhất Mã khoa hoặc Tên lớp cần thay đổi!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "UPDATE Lop SET ";
                    bool hasUpdate = false;

                    if (!string.IsNullOrEmpty(maKhoa))
                    {
                        query += "MaKhoa = @MaKhoa";
                        hasUpdate = true;
                    }

                    if (!string.IsNullOrEmpty(tenLop))
                    {
                        query += hasUpdate ? ", TenLop = @TenLop" : "TenLop = @TenLop";
                    }

                    query += " WHERE MaLop = @MaLop";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaLop", maLop);
                        if (!string.IsNullOrEmpty(maKhoa)) cmd.Parameters.AddWithValue("@MaKhoa", maKhoa);
                        if (!string.IsNullOrEmpty(tenLop)) cmd.Parameters.AddWithValue("@TenLop", tenLop);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cập nhật thông tin lớp thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy Mã lớp để sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi sửa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ClearFields()
        {
            txtMaKhoa.Clear();
            txtMaLop.Clear();
            txtTenLop.Clear();
            txtMaKhoa.Focus();
        }
    }
}