using System;
using System.Windows.Forms;

namespace baitap6a
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Cấu hình giao diện và độ phân giải màn hình (Dành cho .NET Core / .NET 6/7/8/9+)
            ApplicationConfiguration.Initialize();
            
            // Khởi chạy Form chính (frmLop)
            Application.Run(new frmLop());
        }
    }
}