#nullable disable
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace baitap6b
{
    // ==========================================
    // 1. FORM CHÍNH (QUẢN LÝ MENU)
    // ==========================================
    public partial class Form1 : Form
    {
        private string connectionString = "Server=LAPTOP-I2772QNH\\MSSQL2022;Database=QLCuaHang;Trusted_Connection=True;";

        public Form1()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "Phần Mềm Quản Lý Cửa Hàng - baitap6b";
            this.Size = new Size(700, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            MenuStrip menuStrip = new MenuStrip();

            // Menu Kho Hàng
            ToolStripMenuItem mnuKhoHang = new ToolStripMenuItem("Kho Hàng");
            ToolStripMenuItem mnuTaoTonKho = new ToolStripMenuItem("Tạo tồn kho", null, mnuTaoTonKho_Click);
            ToolStripMenuItem mnuThemSP = new ToolStripMenuItem("Thêm sản phẩm mới", null, mnuThemSP_Click);
            mnuKhoHang.DropDownItems.Add(mnuTaoTonKho);
            mnuKhoHang.DropDownItems.Add(mnuThemSP);

            // Menu Bán Hàng
            ToolStripMenuItem mnuBanHangMenu = new ToolStripMenuItem("Bán Hàng");
            ToolStripMenuItem mnuLapHoaDon = new ToolStripMenuItem("Giao diện bán hàng", null, mnuLapHoaDon_Click);
            mnuBanHangMenu.DropDownItems.Add(mnuLapHoaDon);

            menuStrip.Items.Add(mnuKhoHang);
            menuStrip.Items.Add(mnuBanHangMenu);

            this.MainMenuStrip = menuStrip;
            this.Controls.Add(menuStrip);
        }

        public void mnuTaoTonKho_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        DECLARE @HomNay DATE = CAST(GETDATE() AS DATE);
                        DECLARE @NgayHomQua DATE = DATEADD(day, -1, @HomNay);

                        IF NOT EXISTS (SELECT 1 FROM TONKHO WHERE NgayTon = @HomNay)
                        BEGIN
                            INSERT INTO TONKHO (MaSP, NgayTon, SLDau, SLNhap, SLBan)
                            SELECT 
                                sp.MaSP,
                                @HomNay,
                                ISNULL(tk.SLDau, 0) + ISNULL(tk.SLNhap, 0) - ISNULL(tk.SLBan, 0),
                                0,
                                0
                            FROM SANPHAM sp
                            LEFT JOIN TONKHO tk ON sp.MaSP = tk.MaSP AND tk.NgayTon = @NgayHomQua;

                            SELECT 1;
                        END
                        ELSE
                        BEGIN
                            SELECT 0;
                        END";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        object val = cmd.ExecuteScalar();
                        int res = val != null ? Convert.ToInt32(val) : 0;
                        if (res == 1)
                        {
                            MessageBox.Show("Tạo tồn kho cho ngày hôm nay thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Tồn kho của ngày hôm nay đã được tạo trước đó!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi tạo tồn kho: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void mnuThemSP_Click(object sender, EventArgs e)
        {
            frmThemSanPham frm = new frmThemSanPham(connectionString);
            frm.ShowDialog();
        }

        public void mnuLapHoaDon_Click(object sender, EventArgs e)
        {
            frmBanHang frm = new frmBanHang(connectionString);
            frm.ShowDialog();
        }
    }


    // ==========================================
    // 2. FORM THÊM SẢN PHẨM MỚI
    // ==========================================
    public partial class frmThemSanPham : Form
    {
        private TextBox txtTenSP;
        private Button btnThem, btnThoat;
        private string connectionString;

        public frmThemSanPham(string connStr)
        {
            connectionString = connStr;
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "Thêm sản phẩm mới";
            this.Size = new Size(460, 220);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterParent;

            Label lblTenSP = new Label() { Text = "Tên sản phẩm", Location = new Point(40, 50), AutoSize = true };
            txtTenSP = new TextBox() { Location = new Point(135, 47), Size = new Size(260, 25) };

            btnThem = new Button() { Text = "Thêm", Location = new Point(135, 100), Size = new Size(95, 30) };
            btnThem.Click += BtnThem_Click;

            btnThoat = new Button() { Text = "Thoát", Location = new Point(300, 100), Size = new Size(95, 30) };
            btnThoat.Click += (s, e) => this.Close();

            this.Controls.Add(lblTenSP);
            this.Controls.Add(txtTenSP);
            this.Controls.Add(btnThem);
            this.Controls.Add(btnThoat);
        }

        public void BtnThem_Click(object sender, EventArgs e)
        {
            string tenSP = txtTenSP.Text.Trim();
            if (string.IsNullOrEmpty(tenSP))
            {
                MessageBox.Show("Tên sản phẩm không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTenSP.Focus();
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (SqlTransaction tran = conn.BeginTransaction())
                    {
                        using (SqlCommand cmd = conn.CreateCommand())
                        {
                            cmd.Transaction = tran;
                            cmd.CommandText = "INSERT INTO SANPHAM (TenSP) VALUES (@TenSP); SELECT SCOPE_IDENTITY();";
                            cmd.Parameters.AddWithValue("@TenSP", tenSP);
                            int maSPMoi = Convert.ToInt32(cmd.ExecuteScalar());

                            // Đã sửa vị trí từ khóa DISTINCT cho đúng cú pháp SQL Server
                            cmd.Parameters.Clear();
                            cmd.CommandText = @"
                                INSERT INTO TONKHO (MaSP, NgayTon, SLDau, SLNhap, SLBan)
                                SELECT DISTINCT @MaSP, NgayTon, 0, 0, 0 
                                FROM TONKHO
                                WHERE NOT EXISTS (
                                    SELECT 1 FROM TONKHO WHERE MaSP = @MaSP AND NgayTon = TONKHO.NgayTon
                                );

                                IF NOT EXISTS (SELECT 1 FROM TONKHO WHERE MaSP = @MaSP)
                                BEGIN
                                    INSERT INTO TONKHO (MaSP, NgayTon, SLDau, SLNhap, SLBan)
                                    VALUES (@MaSP, CAST(GETDATE() AS DATE), 0, 0, 0);
                                END";
                            cmd.Parameters.AddWithValue("@MaSP", maSPMoi);
                            cmd.ExecuteNonQuery();

                            tran.Commit();
                            MessageBox.Show("Thêm sản phẩm mới thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtTenSP.Clear();
                            txtTenSP.Focus();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi thêm sản phẩm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }


    // ==========================================
    // 3. FORM BÁN HÀNG
    // ==========================================
    public partial class frmBanHang : Form
    {
        private Button btnTaoHoaDonMoi, btnThemCTHD, btnHuy, btnThanhToan;
        private TextBox txtMaHD, txtSoLuong;
        private ComboBox cboMaSP;
        private GroupBox grbChiTiet;
        private string connectionString;
        private int currentMaHD = -1;

        public frmBanHang(string connStr)
        {
            connectionString = connStr;
            InitializeComponentCustom();
            ToggleControls(false);
        }

        private void InitializeComponentCustom()
        {
            this.Text = "BanHang";
            this.Size = new Size(620, 480);
            this.StartPosition = FormStartPosition.CenterParent;

            btnTaoHoaDonMoi = new Button() { Text = "Tạo hóa đơn mới", Location = new Point(440, 25), Size = new Size(130, 30) };
            btnTaoHoaDonMoi.Click += BtnTaoHoaDonMoi_Click;

            grbChiTiet = new GroupBox() { Text = "Chi tiết hóa đơn", Location = new Point(35, 75), Size = new Size(535, 250) };

            Label lblMaHD = new Label() { Text = "Mã hóa đơn", Location = new Point(25, 35), AutoSize = true };
            txtMaHD = new TextBox() { Location = new Point(130, 32), Size = new Size(260, 25), ReadOnly = true };

            Label lblMaSP = new Label() { Text = "Mã sản phẩm", Location = new Point(25, 80), AutoSize = true };
            cboMaSP = new ComboBox() { Location = new Point(130, 77), Size = new Size(260, 25), DropDownStyle = ComboBoxStyle.DropDownList };
            LoadSanPhamToComboBox();

            Label lblSoLuong = new Label() { Text = "Số lượng", Location = new Point(25, 125), AutoSize = true };
            txtSoLuong = new TextBox() { Location = new Point(130, 122), Size = new Size(260, 25) };

            btnThemCTHD = new Button() { Text = "Thêm", Location = new Point(200, 185), Size = new Size(75, 30) };
            btnThemCTHD.Click += BtnThemCTHD_Click;

            btnHuy = new Button() { Text = "Hủy", Location = new Point(315, 185), Size = new Size(75, 30) };
            btnHuy.Click += BtnHuy_Click;

            grbChiTiet.Controls.Add(lblMaHD);
            grbChiTiet.Controls.Add(txtMaHD);
            grbChiTiet.Controls.Add(lblMaSP);
            grbChiTiet.Controls.Add(cboMaSP);
            grbChiTiet.Controls.Add(lblSoLuong);
            grbChiTiet.Controls.Add(txtSoLuong);
            grbChiTiet.Controls.Add(btnThemCTHD);
            grbChiTiet.Controls.Add(btnHuy);

            btnThanhToan = new Button() { Text = "Thanh toán", Location = new Point(440, 350), Size = new Size(130, 35) };
            btnThanhToan.Click += BtnThanhToan_Click;

            this.Controls.Add(btnTaoHoaDonMoi);
            this.Controls.Add(grbChiTiet);
            this.Controls.Add(btnThanhToan);
        }

        private void ToggleControls(bool isEnabled)
        {
            txtSoLuong.Enabled = isEnabled;
            cboMaSP.Enabled = isEnabled;
            btnThemCTHD.Enabled = isEnabled;
            btnHuy.Enabled = isEnabled;
            btnThanhToan.Enabled = isEnabled;
        }

        private void LoadSanPhamToComboBox()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT MaSP, TenSP FROM SANPHAM";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    cboMaSP.DataSource = dt;
                    cboMaSP.DisplayMember = "TenSP";
                    cboMaSP.ValueMember = "MaSP";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi tải danh sách sản phẩm: " + ex.Message);
                }
            }
        }

        public void BtnTaoHoaDonMoi_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO HOADON (NgayTao, TinhTrangThanhToan) VALUES (GETDATE(), 0); SELECT SCOPE_IDENTITY();";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        currentMaHD = Convert.ToInt32(cmd.ExecuteScalar());
                        txtMaHD.Text = currentMaHD.ToString();
                        ToggleControls(true);
                        MessageBox.Show("Tạo hóa đơn mới thành công! Vui lòng nhập chi tiết sản phẩm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi tạo hóa đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void BtnThemCTHD_Click(object sender, EventArgs e)
        {
            if (currentMaHD == -1)
            {
                MessageBox.Show("Chưa có hóa đơn nào được tạo!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cboMaSP.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng chọn sản phẩm!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtSoLuong.Text.Trim(), out int soLuongBan) || soLuongBan <= 0)
            {
                MessageBox.Show("Số lượng bán phải là số nguyên lớn hơn 0!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSoLuong.Focus();
                return;
            }

            int maSP = Convert.ToInt32(cboMaSP.SelectedValue);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (SqlTransaction tran = conn.BeginTransaction())
                    {
                        SqlCommand cmd = conn.CreateCommand();
                        cmd.Transaction = tran;

                        cmd.CommandText = @"
                            SELECT ISNULL(SLDau, 0) + ISNULL(SLNhap, 0) - ISNULL(SLBan, 0) AS TonCuoi 
                            FROM TONKHO 
                            WHERE MaSP = @MaSP AND NgayTon = CAST(GETDATE() AS DATE)";
                        cmd.Parameters.AddWithValue("@MaSP", maSP);
                        
                        object result = cmd.ExecuteScalar();
                        if (result == null)
                        {
                            throw new Exception("Chưa tạo tồn kho cho ngày hôm nay! Vui lòng vào 'Kho Hàng -> Tạo tồn kho' trước.");
                        }

                        int tonKho = Convert.ToInt32(result);
                        if (soLuongBan > tonKho)
                        {
                            throw new Exception("Số lượng bán vượt quá số lượng tồn kho hiện có (" + tonKho + ")!");
                        }

                        cmd.Parameters.Clear();
                        cmd.CommandText = @"
                            IF EXISTS (SELECT 1 FROM CHITIET_HOADON WHERE MaHD = @MaHD AND MaSP = @MaSP)
                                UPDATE CHITIET_HOADON SET SoLuong = SoLuong + @SoLuong WHERE MaHD = @MaHD AND MaSP = @MaSP;
                            ELSE
                                INSERT INTO CHITIET_HOADON (MaHD, MaSP, SoLuong) VALUES (@MaHD, @MaSP, @SoLuong);";
                        cmd.Parameters.AddWithValue("@MaHD", currentMaHD);
                        cmd.Parameters.AddWithValue("@MaSP", maSP);
                        cmd.Parameters.AddWithValue("@SoLuong", soLuongBan);
                        cmd.ExecuteNonQuery();

                        cmd.Parameters.Clear();
                        cmd.CommandText = @"
                            UPDATE TONKHO 
                            SET SLBan = SLBan + @SoLuong 
                            WHERE MaSP = @MaSP AND NgayTon = CAST(GETDATE() AS DATE)";
                        cmd.Parameters.AddWithValue("@SoLuong", soLuongBan);
                        cmd.Parameters.AddWithValue("@MaSP", maSP);
                        cmd.ExecuteNonQuery();

                        tran.Commit();
                        MessageBox.Show("Thêm chi tiết hóa đơn thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtSoLuong.Clear();
                        txtSoLuong.Focus();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void BtnHuy_Click(object sender, EventArgs e)
        {
            txtSoLuong.Clear();
            if (cboMaSP.Items.Count > 0) cboMaSP.SelectedIndex = 0;
        }

        public void BtnThanhToan_Click(object sender, EventArgs e)
        {
            if (currentMaHD == -1)
            {
                MessageBox.Show("Không có hóa đơn nào đang được xử lý!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "UPDATE HOADON SET TinhTrangThanhToan = 1 WHERE MaHD = @MaHD";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaHD", currentMaHD);
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Thanh toán hóa đơn thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        currentMaHD = -1;
                        txtMaHD.Clear();
                        ToggleControls(false);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi thanh toán: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}