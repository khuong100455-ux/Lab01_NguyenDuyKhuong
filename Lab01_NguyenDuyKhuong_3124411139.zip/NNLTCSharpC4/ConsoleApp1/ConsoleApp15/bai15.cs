﻿using System;

class Mang
{
    public void Nhap(int[] a)
    {
        for (int i = 0; i < a.Length; i++)
        {
            Console.Write($"a[{i}] = ");
            a[i] = int.Parse(Console.ReadLine());
        }
    }

    public void Xuat(int[] a)
    {
        foreach (int x in a)
            Console.Write(x + " ");
        Console.WriteLine();
    }

    public void TimMinMax(int[] a, out int min, out int max)
    {
        min = max = a[0];
        foreach (int x in a)
        {
            if (x < min) min = x;
            if (x > max) max = x;
        }
    }

    public int[] LocSoNguyenTo(int[] a)
    {
        // Tạm dùng List để dễ dàng
        var list = new System.Collections.Generic.List<int>();
        foreach (int x in a)
        {
            if (LaNguyenTo(x))
                list.Add(x);
        }
        return list.ToArray();
    }

    private bool LaNguyenTo(int n)
    {
        if (n < 2) return false;
        for (int i = 2; i <= Math.Sqrt(n); i++)
            if (n % i == 0) return false;
        return true;
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Nhap so phan tu n: ");
        int n = int.Parse(Console.ReadLine());
        int[] a = new int[n];

        Mang m = new Mang();
        m.Nhap(a);

        Console.Write("Mang: ");
        m.Xuat(a);

        m.TimMinMax(a, out int min, out int max);
        Console.WriteLine($"Min = {min}, Max = {max}");

        int[] nt = m.LocSoNguyenTo(a);
        Console.Write("Cac so nguyen to: ");
        m.Xuat(nt);
    }
}