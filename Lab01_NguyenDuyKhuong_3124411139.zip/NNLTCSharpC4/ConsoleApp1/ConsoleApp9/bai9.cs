﻿using System;

class TinhToan
{
    public void TimMaxMin(double a, double b, double c, out double max, out double min)
    {
        max = a;
        min = a;

        if (b > max) max = b;
        if (c > max) max = c;

        if (b < min) min = b;
        if (c < min) min = c;
    }
}

class Program
{
    static void Main()
    {
        TinhToan tt = new TinhToan();

        Console.Write("Nhap a: ");
        double a = double.Parse(Console.ReadLine());
        Console.Write("Nhap b: ");
        double b = double.Parse(Console.ReadLine());
        Console.Write("Nhap c: ");
        double c = double.Parse(Console.ReadLine());

        double max, min;   

        tt.TimMaxMin(a, b, c, out max, out min);

        Console.WriteLine($"Max = {max}");
        Console.WriteLine($"Min = {min}");
    }
}