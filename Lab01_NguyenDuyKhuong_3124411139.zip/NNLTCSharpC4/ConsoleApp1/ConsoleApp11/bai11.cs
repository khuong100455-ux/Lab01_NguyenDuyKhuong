﻿using System;

class XuLyChuoi
{
    public string DaoChuoi(string s)
    {
        char[] arr = s.ToCharArray();
        Array.Reverse(arr);
        return new string(arr);
    }
}

class Program
{
    static void Main()
    {
        XuLyChuoi xl = new XuLyChuoi();

        Console.Write("Nhap chuoi: ");
        string s = Console.ReadLine();

        Console.WriteLine("Chuoi dao: " + xl.DaoChuoi(s));
    }
}