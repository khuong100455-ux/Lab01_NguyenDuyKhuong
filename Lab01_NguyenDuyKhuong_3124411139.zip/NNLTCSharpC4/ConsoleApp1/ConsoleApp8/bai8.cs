﻿using System;

class TinhToan
{
    
    public void HoanVi(ref double a, ref double b)
    {
        double temp = a;
        a = b;
        b = temp;
    }
}

class Program
{
    static void Main()
    {
        TinhToan tt = new TinhToan();

        Console.Write("Nhap a: ");
        double a = double.Parse(Console.ReadLine());
        Console.Write("Nhap b: ");
        double b = double.Parse(Console.ReadLine());

        Console.WriteLine($"Truoc hoan vi: a = {a}, b = {b}");

        tt.HoanVi(ref a, ref b);

        Console.WriteLine($"Sau hoan vi: a = {a}, b = {b}");
    }
}