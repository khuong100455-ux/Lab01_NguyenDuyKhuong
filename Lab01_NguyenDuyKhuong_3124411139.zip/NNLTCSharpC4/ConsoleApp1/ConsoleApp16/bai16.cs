﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap so nguoi n: ");
        int n = int.Parse(Console.ReadLine());

        string[] ten = new string[n];
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Nhap ten thu {i + 1}: ");
            ten[i] = Console.ReadLine();
        }

        Array.Sort(ten);   // Sắp xếp tăng dần

        Console.WriteLine("\nDanh sach sau khi sap xep:");
        foreach (string t in ten)
            Console.WriteLine(t);
    }
}