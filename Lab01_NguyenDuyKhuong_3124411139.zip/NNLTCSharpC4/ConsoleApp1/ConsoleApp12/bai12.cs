﻿using System;

class XuLyChuoi
{
    public void XuLy(string s)
    {
        Console.WriteLine("Chuoi thuong: " + s.ToLower());
        Console.WriteLine("Chuoi hoa: " + s.ToUpper());

        string[] tu = s.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        Console.WriteLine("So tu: " + tu.Length);
    }
}

class Program
{
    static void Main()
    {
        XuLyChuoi xl = new XuLyChuoi();

        Console.Write("Nhap chuoi: ");
        string s = Console.ReadLine();

        xl.XuLy(s);
    }
}