﻿using System;

class TinhToan
{
    public bool LaSoNguyenTo(int n)
    {
        if (n < 2) return false;

        for (int i = 2; i <= Math.Sqrt(n); i++)
        {
            if (n % i == 0)
                return false;
        }
        return true;
    }
}

class Program
{
    static void Main()
    {
        TinhToan tt = new TinhToan();

        Console.Write("Nhap n: ");
        int n = int.Parse(Console.ReadLine());

        if (tt.LaSoNguyenTo(n))
            Console.WriteLine($"{n} la so nguyen to");
        else
            Console.WriteLine($"{n} khong phai so nguyen to");
    }
}