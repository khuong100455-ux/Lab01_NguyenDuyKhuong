﻿using System;

namespace Bai1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap ho ten cua ban: ");
            string hoTen = Console.ReadLine();

            Console.WriteLine("Ho ten ban vua nhap la: " + hoTen);

            Console.ReadKey(); 
        }
    }
}