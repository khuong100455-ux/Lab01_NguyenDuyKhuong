﻿using System;

class NhanVien
{
    public string HoTen;
    public double MucLuong;
    public int SoNgayVang;

    public void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhap muc luong: ");
        MucLuong = double.Parse(Console.ReadLine());
        Console.Write("Nhap so ngay vang: ");
        SoNgayVang = int.Parse(Console.ReadLine());
    }

    public double TinhLuong()
    {
        return MucLuong - SoNgayVang * 100000;
    }

    public void Xuat()
    {
        Console.WriteLine($"Ho ten: {HoTen}");
        Console.WriteLine($"Luong thuc nhan: {TinhLuong():N0} VND");
    }
}

class Program
{
    static void Main()
    {
        NhanVien nv = new NhanVien();
        nv.Nhap();
        nv.Xuat();
    }
}