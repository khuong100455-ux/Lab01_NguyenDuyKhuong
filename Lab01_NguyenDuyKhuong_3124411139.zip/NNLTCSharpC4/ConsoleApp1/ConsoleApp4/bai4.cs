﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap so nguyen x: ");
        string sx = Console.ReadLine();

        Console.Write("Nhap so nguyen y: ");
        string sy = Console.ReadLine();

        if (int.TryParse(sx, out int x) && int.TryParse(sy, out int y))
        {
            Console.WriteLine($"Ket qua {x} mu {y} la:");
            Console.WriteLine(Math.Pow(x, y));
        }
        else
        {
            Console.WriteLine("Loi: x hoac y khong phai la so nguyen!");
        }
    }
}