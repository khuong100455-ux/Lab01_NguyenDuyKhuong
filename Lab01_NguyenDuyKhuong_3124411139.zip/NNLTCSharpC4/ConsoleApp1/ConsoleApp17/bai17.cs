﻿using System;

class Mang2Chieu
{
    public int[,] SinhNgauNhien(int n, int m)
    {
        int[,] a = new int[n, m];
        Random rd = new Random();

        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                a[i, j] = rd.Next(10, 101); // [10, 100]

        return a;
    }

    public void Xuat(int[,] a)
    {
        int n = a.GetLength(0);
        int m = a.GetLength(1);

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
                Console.Write(a[i, j] + "\t");
            Console.WriteLine();
        }
    }

    public void TachChanLe(int[,] a, out int[] chan, out int[] le)
    {
        var listChan = new System.Collections.Generic.List<int>();
        var listLe = new System.Collections.Generic.List<int>();

        foreach (int x in a)
        {
            if (x % 2 == 0) listChan.Add(x);
            else listLe.Add(x);
        }

        chan = listChan.ToArray();
        le = listLe.ToArray();
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Nhap n: ");
        int n = int.Parse(Console.ReadLine());
        Console.Write("Nhap m: ");
        int m = int.Parse(Console.ReadLine());

        Mang2Chieu mang = new Mang2Chieu();
        int[,] a = mang.SinhNgauNhien(n, m);

        Console.WriteLine("Mang ngau nhien:");
        mang.Xuat(a);

        mang.TachChanLe(a, out int[] chan, out int[] le);

        Console.WriteLine("\nCac so chan:");
        foreach (int x in chan) Console.Write(x + " ");

        Console.WriteLine("\nCac so le:");
        foreach (int x in le) Console.Write(x + " ");
    }
}