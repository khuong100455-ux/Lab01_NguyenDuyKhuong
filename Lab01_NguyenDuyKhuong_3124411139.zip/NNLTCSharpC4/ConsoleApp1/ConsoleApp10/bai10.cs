﻿using System;

class XuLyChuoi
{
    public bool LaDoiXung(string s)
    {
        s = s.ToLower().Replace(" ", ""); 

        int left = 0;
        int right = s.Length - 1;

        while (left < right)
        {
            if (s[left] != s[right])
                return false;
            left++;
            right--;
        }
        return true;
    }
}

class Program
{
    static void Main()
    {
        XuLyChuoi xl = new XuLyChuoi();

        Console.Write("Nhap chuoi: ");
        string s = Console.ReadLine();

        if (xl.LaDoiXung(s))
            Console.WriteLine("Chuoi doi xung");
        else
            Console.WriteLine("Chuoi khong doi xung");
    }
}