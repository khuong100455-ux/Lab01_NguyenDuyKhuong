﻿using System;

class SinhVien
{
    // Fields
    public string MaSV;
    public string HoTen;
    public string DiaChi;
    public int Nam;

    // Constructor
    public SinhVien()
    {
        MaSV = "";
        HoTen = "";
        DiaChi = "";
        Nam = 1;
    }

    // Method nhập
    public void Nhap()
    {
        Console.Write("Nhap ma SV: ");
        MaSV = Console.ReadLine();
        Console.Write("Nhap ho ten: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhap dia chi: ");
        DiaChi = Console.ReadLine();
        Console.Write("Nhap nam thu: ");
        Nam = int.Parse(Console.ReadLine());
    }

    // Method xuất
    public void Xuat()
    {
        Console.WriteLine($"Ma SV: {MaSV}");
        Console.WriteLine($"Ho ten: {HoTen}");
        Console.WriteLine($"Dia chi: {DiaChi}");
        Console.WriteLine($"Sinh vien nam thu: {Nam}");
    }
}

class Program
{
    static void Main()
    {
        SinhVien sv = new SinhVien();
        sv.Nhap();
        Console.WriteLine("\nThong tin sinh vien:");
        sv.Xuat();
    }
}