#nullable disable
using System;
using System.Drawing;
using System.Windows.Forms;

namespace baitaptailop1
{
    public partial class frmUocSo : Form
    {
        // Khai báo các Controls
        private Label lblNhapSo, lblDanhSachUoc;
        private TextBox txtNhapSo;
        private Button btnCapNhat;
        private ComboBox cboSo;
        private ListBox listUocSo;
        private Button btnTongUoc, btnSoLuongUocChan, btnSoLuongUocNguyenTo, btnThoat;

        public frmUocSo()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "ComboBox và Ước số";
            this.Size = new Size(600, 450);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormClosing += new FormClosingEventHandler(this.frmUocSo_FormClosing);

            // Group Nhập số & ComboBox
            lblNhapSo = new Label() { Text = "Nhập Số", Location = new Point(30, 25), AutoSize = true };
            txtNhapSo = new TextBox() { Location = new Point(30, 50), Width = 120, Height = 25 };
            
            // HotKey cho Cập nhật (&Cập nhật -> Alt + C)
            btnCapNhat = new Button() { Text = "&Cập nhật", Location = new Point(160, 48), Width = 90, Height = 28 };
            btnCapNhat.Click += new EventHandler(this.btnCapNhat_Click);

            cboSo = new ComboBox() { Location = new Point(30, 90), Width = 220, Height = 25, DropDownStyle = ComboBoxStyle.DropDownList };
            cboSo.SelectedIndexChanged += new EventHandler(this.cboSo_SelectedIndexChanged);

            // Group Danh sách các ước số & ListBox
            lblDanhSachUoc = new Label() { Text = "Danh sách các ước số", Location = new Point(310, 25), AutoSize = true };
            listUocSo = new ListBox() { Location = new Point(310, 50), Width = 220, Height = 160 };

            // Các Button tính toán có HotKey (Alt + T, Alt + C, Alt + N...)
            btnTongUoc = new Button() { Text = "&Tổng các ước số", Location = new Point(310, 230), Width = 220, Height = 35 };
            btnTongUoc.Click += new EventHandler(this.btnTongUoc_Click);

            btnSoLuongUocChan = new Button() { Text = "Số lượng các ước số &chẵn", Location = new Point(310, 275), Width = 220, Height = 35 };
            btnSoLuongUocChan.Click += new EventHandler(this.btnSoLuongUocChan_Click);

            btnSoLuongUocNguyenTo = new Button() { Text = "Số lượng các ước số nguyên &tố", Location = new Point(310, 320), Width = 220, Height = 35 };
            btnSoLuongUocNguyenTo.Click += new EventHandler(this.btnSoLuongUocNguyenTo_Click);

            // Button Thoát (&Thoát)
            btnThoat = new Button() { Text = "&Thoát", Location = new Point(150, 320), Width = 100, Height = 35 };
            btnThoat.Click += new EventHandler(this.btnThoat_Click);

            // Thêm các control vào Form
            this.Controls.Add(lblNhapSo);
            this.Controls.Add(txtNhapSo);
            this.Controls.Add(btnCapNhat);
            this.Controls.Add(cboSo);
            this.Controls.Add(lblDanhSachUoc);
            this.Controls.Add(listUocSo);
            this.Controls.Add(btnTongUoc);
            this.Controls.Add(btnSoLuongUocChan);
            this.Controls.Add(btnSoLuongUocNguyenTo);
            this.Controls.Add(btnThoat);
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            string input = txtNhapSo.Text.Trim();

            if (!int.TryParse(input, out int so) || so <= 0)
            {
                MessageBox.Show("Vui lòng nhập vào một số nguyên dương hợp lệ!", "Lỗi dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNhapSo.Focus();
                txtNhapSo.SelectAll();
                return;
            }

            if (cboSo.Items.Contains(so))
            {
                MessageBox.Show("Số này đã tồn tại trong danh sách ComboBox!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNhapSo.Focus();
                txtNhapSo.SelectAll();
                return;
            }

            cboSo.Items.Add(so);
            cboSo.SelectedItem = so;

            txtNhapSo.Clear();
            txtNhapSo.Focus();
        }

        private void cboSo_SelectedIndexChanged(object sender, EventArgs e)
        {
            listUocSo.Items.Clear();
            if (cboSo.SelectedItem != null)
            {
                int n = Convert.ToInt32(cboSo.SelectedItem);
                for (int i = 1; i <= n; i++)
                {
                    if (n % i == 0)
                    {
                        listUocSo.Items.Add(i);
                    }
                }
            }
        }

        private void btnTongUoc_Click(object sender, EventArgs e)
        {
            if (listUocSo.Items.Count == 0)
            {
                MessageBox.Show("Chưa có danh sách ước số để tính!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int tong = 0;
            foreach (var item in listUocSo.Items)
            {
                tong += Convert.ToInt32(item);
            }

            MessageBox.Show($"Tổng các ước số là: {tong}", "Kết quả", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSoLuongUocChan_Click(object sender, EventArgs e)
        {
            if (listUocSo.Items.Count == 0)
            {
                MessageBox.Show("Chưa có danh sách ước số để tính!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int dem = 0;
            foreach (var item in listUocSo.Items)
            {
                int val = Convert.ToInt32(item);
                if (val % 2 == 0)
                {
                    dem++;
                }
            }

            MessageBox.Show($"Số lượng các ước số chẵn là: {dem}", "Kết quả", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private bool IsPrime(int n)
        {
            if (n < 2) return false;
            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0) return false;
            }
            return true;
        }

        private void btnSoLuongUocNguyenTo_Click(object sender, EventArgs e)
        {
            if (listUocSo.Items.Count == 0)
            {
                MessageBox.Show("Chưa có danh sách ước số để tính!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int dem = 0;
            foreach (var item in listUocSo.Items)
            {
                int val = Convert.ToInt32(item);
                if (IsPrime(val))
                {
                    dem++;
                }
            }

            MessageBox.Show($"Số lượng các ước số nguyên tố là: {dem}", "Kết quả", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmUocSo_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muốn thoát ứng dụng không?", "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}
