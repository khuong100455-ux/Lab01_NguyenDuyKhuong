#nullable disable
using System;
using System.Windows.Forms;

namespace baitaptailop1
{
    static class Program
    {
        /// <summary>
        /// Điểm khởi đầu chính cho ứng dụng.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmUocSo());
        }
    }
}