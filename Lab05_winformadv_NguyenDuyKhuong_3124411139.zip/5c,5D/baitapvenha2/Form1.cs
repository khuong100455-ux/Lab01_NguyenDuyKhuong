#nullable disable
using System;
using System.Drawing;
using System.Windows.Forms;

namespace baitapvenha2
{
    public partial class Form1 : Form
    {
        private Label lblTitle;
        private GroupBox grpNhap;
        private TextBox txtN;
        private Button btnNhap;
        private ListBox listBox1;

        private GroupBox grpXuLy;
        private Button btnTong;
        private Button btnXoaDauCuoi;
        private Button btnXoaDangChon;
        private Button btnTang2;
        private Button btnBinhPhong;
        private Button btnChonChan;
        private Button btnChonLe;

        private Button btnKetThuc;

        public Form1()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "frmListbox";
            this.Size = new Size(540, 520);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Tiêu đề form
            lblTitle = new Label() { Text = "LISTBOX", Font = new Font("Arial", 16, FontStyle.Bold), ForeColor = Color.OrangeRed, Location = new Point(180, 15), AutoSize = true };

            // GroupBox Nhập liệu
            grpNhap = new GroupBox() { Text = "Listbox", Location = new Point(20, 55), Size = new Size(220, 355) };
            txtN = new TextBox() { Location = new Point(15, 30), Size = new Size(190, 25) };
            btnNhap = new Button() { Text = "Nhập", Location = new Point(15, 65), Size = new Size(190, 30) };
            btnNhap.Click += new EventHandler(this.btnNhap_Click);

            // ListBox hỗ trợ chọn nhiều phần tử (MultiExtended)
            listBox1 = new ListBox() { Location = new Point(15, 105), Size = new Size(190, 235), SelectionMode = SelectionMode.MultiExtended };

            grpNhap.Controls.Add(txtN);
            grpNhap.Controls.Add(btnNhap);
            grpNhap.Controls.Add(listBox1);

            // GroupBox Xử lý ListBox
            grpXuLy = new GroupBox() { Text = "Xử lý Listbox", Location = new Point(255, 55), Size = new Size(245, 355) };
            
            int btnY = 25;
            int btnH = 35;
            int spacing = 8;

            btnTong = new Button() { Text = "Tổng các phần tử trong List", Location = new Point(15, btnY), Size = new Size(215, btnH) };
            btnTong.Click += new EventHandler(this.btnTong_Click);

            btnXoaDauCuoi = new Button() { Text = "Xóa Phần tử đầu và cuối", Location = new Point(15, btnY += (btnH + spacing)), Size = new Size(215, btnH) };
            btnXoaDauCuoi.Click += new EventHandler(this.btnXoaDauCuoi_Click);

            btnXoaDangChon = new Button() { Text = "Xóa Phần tử đang chọn", Location = new Point(15, btnY += (btnH + spacing)), Size = new Size(215, btnH) };
            btnXoaDangChon.Click += new EventHandler(this.btnXoaDangChon_Click);

            btnTang2 = new Button() { Text = "Tăng mỗi phần tử lên 2", Location = new Point(15, btnY += (btnH + spacing)), Size = new Size(215, btnH) };
            btnTang2.Click += new EventHandler(this.btnTang2_Click);

            btnBinhPhong = new Button() { Text = "Thay bằng bình phương", Location = new Point(15, btnY += (btnH + spacing)), Size = new Size(215, btnH) };
            btnBinhPhong.Click += new EventHandler(this.btnBinhPhong_Click);

            btnChonChan = new Button() { Text = "Chọn số chẵn", Location = new Point(15, btnY += (btnH + spacing)), Size = new Size(215, btnH) };
            btnChonChan.Click += new EventHandler(this.btnChonChan_Click);

            btnChonLe = new Button() { Text = "Chọn số lẻ", Location = new Point(15, btnY += (btnH + spacing)), Size = new Size(215, btnH) };
            btnChonLe.Click += new EventHandler(this.btnChonLe_Click);

            grpXuLy.Controls.Add(btnTong);
            grpXuLy.Controls.Add(btnXoaDauCuoi);
            grpXuLy.Controls.Add(btnXoaDangChon);
            grpXuLy.Controls.Add(btnTang2);
            grpXuLy.Controls.Add(btnBinhPhong);
            grpXuLy.Controls.Add(btnChonChan);
            grpXuLy.Controls.Add(btnChonLe);

            // Nút Kết thúc
            btnKetThuc = new Button() { Text = "KẾT THÚC", Location = new Point(20, 420), Size = new Size(480, 35) };
            btnKetThuc.Click += (s, e) => this.Close();

            // Thêm tất cả vào Form
            this.Controls.Add(lblTitle);
            this.Controls.Add(grpNhap);
            this.Controls.Add(grpXuLy);
            this.Controls.Add(btnKetThuc);
        }

        private void btnNhap_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtN.Text.Trim(), out int n))
            {
                listBox1.Items.Add(n);
                txtN.Clear();
                txtN.Focus();
            }
            else
            {
                MessageBox.Show("Vui lòng nhập vào một số tự nhiên hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtN.Focus();
            }
        }

        private void btnTong_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0)
            {
                MessageBox.Show("Danh sách ListBox đang trống!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int sum = 0;
            foreach (var item in listBox1.Items)
            {
                sum += Convert.ToInt32(item);
            }
            MessageBox.Show($"Tổng các phần tử trong ListBox là: {sum}", "Kết quả", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnXoaDauCuoi_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0)
            {
                MessageBox.Show("Danh sách đã trống!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            listBox1.Items.RemoveAt(0);
            if (listBox1.Items.Count > 0)
            {
                listBox1.Items.RemoveAt(listBox1.Items.Count - 1);
            }
            MessageBox.Show("Đã xóa phần tử đầu và cuối thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnXoaDangChon_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn ít nhất một phần tử cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            for (int i = listBox1.SelectedIndices.Count - 1; i >= 0; i--)
            {
                listBox1.Items.RemoveAt(listBox1.SelectedIndices[i]);
            }
        }

        private void btnTang2_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0) return;

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                int val = Convert.ToInt32(listBox1.Items[i]);
                listBox1.Items[i] = val + 2;
            }
            MessageBox.Show("Đã tăng mỗi phần tử lên 2 đơn vị!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnBinhPhong_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0) return;

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                int val = Convert.ToInt32(listBox1.Items[i]);
                listBox1.Items[i] = val * val;
            }
            MessageBox.Show("Đã thay thế các phần tử bằng bình phương của chúng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnChonChan_Click(object sender, EventArgs e)
        {
            listBox1.ClearSelected();
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                int val = Convert.ToInt32(listBox1.Items[i]);
                if (val % 2 == 0)
                {
                    listBox1.SetSelected(i, true);
                }
            }
        }

        private void btnChonLe_Click(object sender, EventArgs e)
        {
            listBox1.ClearSelected();
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                int val = Convert.ToInt32(listBox1.Items[i]);
                if (val % 2 != 0)
                {
                    listBox1.SetSelected(i, true);
                }
            }
        }
    }
}