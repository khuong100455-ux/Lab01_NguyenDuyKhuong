#nullable disable
using System;
using System.Drawing;
using System.Windows.Forms;

namespace baitapvenha3
{
    public partial class frmBTVN2 : Form
    {
        private TreeView treeView1;
        private GroupBox grpThongTin;
        private Label lblFirstName;
        private Label lblLastName;
        private TextBox txtFirstName;
        private TextBox txtLastName;
        private Button btnAdd;
        private Button btnExit;

        public frmBTVN2()
        {
            InitializeComponentCustom();
            KhoiTaoCayAlphabet();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "frmBTVN2";
            this.Size = new Size(620, 440);
            this.StartPosition = FormStartPosition.CenterScreen;

            // 1. TreeView hiển thị danh bạ bên trái
            treeView1 = new TreeView() { Location = new Point(15, 15), Size = new Size(260, 370) };

            // 2. GroupBox nhập thông tin liên lạc bên phải
            grpThongTin = new GroupBox() { Text = "", Location = new Point(290, 15), Size = new Size(300, 270) };

            lblFirstName = new Label() { Text = "First Name", Location = new Point(20, 45), AutoSize = true };
            txtFirstName = new TextBox() { Location = new Point(110, 42), Size = new Size(170, 25) };

            lblLastName = new Label() { Text = "Last Name", Location = new Point(20, 100), AutoSize = true };
            txtLastName = new TextBox() { Location = new Point(110, 97), Size = new Size(170, 25) };

            btnAdd = new Button() { Text = "Add", Location = new Point(180, 150), Size = new Size(100, 35) };
            btnAdd.Click += new EventHandler(this.btnAdd_Click);

            grpThongTin.Controls.Add(lblFirstName);
            grpThongTin.Controls.Add(txtFirstName);
            grpThongTin.Controls.Add(lblLastName);
            grpThongTin.Controls.Add(txtLastName);
            grpThongTin.Controls.Add(btnAdd);

            // 3. Nút Exit
            btnExit = new Button() { Text = "Exit", Location = new Point(490, 305), Size = new Size(100, 35) };
            btnExit.Click += (s, e) => this.Close();

            // Thêm các control vào Form chính
            this.Controls.Add(treeView1);
            this.Controls.Add(grpThongTin);
            this.Controls.Add(btnExit);
        }

        private void KhoiTaoCayAlphabet()
        {
            treeView1.Nodes.Clear();
            for (char c = 'A'; c <= 'Z'; c++)
            {
                treeView1.Nodes.Add(c.ToString(), c.ToString());
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();

            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ First Name và Last Name!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            char firstChar = char.ToUpper(lastName[0]);

            if (firstChar >= 'A' && firstChar <= 'Z')
            {
                string parentKey = firstChar.ToString();
                TreeNode parentNode = treeView1.Nodes[parentKey];

                if (parentNode != null)
                {
                    string contactName = $"{lastName}, {firstName}";
                    parentNode.Nodes.Add(contactName);
                    parentNode.Expand();

                    txtFirstName.Clear();
                    txtLastName.Clear();
                    txtLastName.Focus();
                }
            }
            else
            {
                MessageBox.Show("Ký tự đầu của Last Name phải là chữ cái Alphabet (A-Z)!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}