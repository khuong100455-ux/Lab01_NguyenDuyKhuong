#nullable disable
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Baitaptailop2
{
    public partial class Form1 : Form
    {
        private TreeView treeView1;
        private ComboBox cboChonLop;
        private Label lblChonLop;
        
        private GroupBox grpThongTinSV;
        private Label lblMaSV, lblHoTen, lblDiaChi;
        private TextBox txtMaSV, txtHoTen, txtDiaChi;
        private Button btnCapNhat, btnXoa;

        private CheckBox chkThemLop;
        private GroupBox grpThemLop;
        private Label lblTenLop;
        private TextBox txtTenLop;
        private Button btnThemLop;

        public Form1()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "Quản lý sinh viên";
            this.Size = new Size(720, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            treeView1 = new TreeView() { Location = new Point(20, 20), Size = new Size(250, 410) };
            treeView1.AfterSelect += new TreeViewEventHandler(this.treeView1_AfterSelect);

            lblChonLop = new Label() { Text = "Chọn Lớp", Location = new Point(300, 25), AutoSize = true };
            cboChonLop = new ComboBox() { Location = new Point(380, 22), Size = new Size(280, 25), DropDownStyle = ComboBoxStyle.DropDownList };

            grpThongTinSV = new GroupBox() { Text = "Thông tin sinh viên", Location = new Point(290, 60), Width = 390, Height = 230 };
            
            lblMaSV = new Label() { Text = "Mã SV:", Location = new Point(20, 35), AutoSize = true };
            txtMaSV = new TextBox() { Location = new Point(90, 32), Width = 275, Height = 25 };

            lblHoTen = new Label() { Text = "Họ Tên:", Location = new Point(20, 75), AutoSize = true };
            txtHoTen = new TextBox() { Location = new Point(90, 72), Width = 275, Height = 25 };

            lblDiaChi = new Label() { Text = "Địa Chỉ:", Location = new Point(20, 115), AutoSize = true };
            txtDiaChi = new TextBox() { Location = new Point(90, 112), Width = 275, Height = 25 };

            btnCapNhat = new Button() { Text = "Cập Nhật", Location = new Point(90, 165), Width = 110, Height = 35 };
            btnCapNhat.Click += new EventHandler(this.btnCapNhat_Click);

            btnXoa = new Button() { Text = "Xóa", Location = new Point(255, 165), Width = 110, Height = 35 };
            btnXoa.Click += new EventHandler(this.btnXoa_Click);

            grpThongTinSV.Controls.Add(lblMaSV);
            grpThongTinSV.Controls.Add(txtMaSV);
            grpThongTinSV.Controls.Add(lblHoTen);
            grpThongTinSV.Controls.Add(txtHoTen);
            grpThongTinSV.Controls.Add(lblDiaChi);
            grpThongTinSV.Controls.Add(txtDiaChi);
            grpThongTinSV.Controls.Add(btnCapNhat);
            grpThongTinSV.Controls.Add(btnXoa);

            chkThemLop = new CheckBox() { Text = "Thêm lớp", Location = new Point(290, 305), AutoSize = true };
            chkThemLop.CheckedChanged += new EventHandler(this.chkThemLop_CheckedChanged);

            grpThemLop = new GroupBox() { Text = "Thông tin lớp", Location = new Point(290, 335), Width = 390, Height = 100, Visible = false };
            
            lblTenLop = new Label() { Text = "Tên lớp", Location = new Point(20, 35), AutoSize = true };
            txtTenLop = new TextBox() { Location = new Point(90, 32), Width = 170, Height = 25 };
            
            btnThemLop = new Button() { Text = "Thêm lớp", Location = new Point(275, 30), Width = 90, Height = 28 };
            btnThemLop.Click += new EventHandler(this.btnThemLop_Click);

            grpThemLop.Controls.Add(lblTenLop);
            grpThemLop.Controls.Add(txtTenLop);
            grpThemLop.Controls.Add(btnThemLop);

            this.Controls.Add(treeView1);
            this.Controls.Add(lblChonLop);
            this.Controls.Add(cboChonLop);
            this.Controls.Add(grpThongTinSV);
            this.Controls.Add(chkThemLop);
            this.Controls.Add(grpThemLop);

            KhoiTaoDuLieuMau();
        }

        private void KhoiTaoDuLieuMau()
        {
            string[] dsLop = { "05DHTH1", "05DHTH2", "05DHTH3", "05DHTH4" };
            foreach (var lop in dsLop)
            {
                treeView1.Nodes.Add(lop);
                cboChonLop.Items.Add(lop);
            }
            if (cboChonLop.Items.Count > 0)
                cboChonLop.SelectedIndex = 0;
        }

        private void chkThemLop_CheckedChanged(object sender, EventArgs e)
        {
            grpThemLop.Visible = chkThemLop.Checked;
        }

        private void btnThemLop_Click(object sender, EventArgs e)
        {
            string tenLop = txtTenLop.Text.Trim();
            if (string.IsNullOrEmpty(tenLop))
            {
                MessageBox.Show("Tên lớp không được để trống!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            foreach (TreeNode node in treeView1.Nodes)
            {
                if (node.Text.Equals(tenLop, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Tên lớp này đã tồn tại!", "Lỗi trùng tên", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            treeView1.Nodes.Add(tenLop);
            cboChonLop.Items.Add(tenLop);
            txtTenLop.Clear();
            MessageBox.Show("Thêm lớp thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            string maSV = txtMaSV.Text.Trim();
            string hoTen = txtHoTen.Text.Trim();
            string diaChi = txtDiaChi.Text.Trim();
            string lopChon = cboChonLop.Text;

            if (string.IsNullOrEmpty(maSV) || string.IsNullOrEmpty(hoTen) || string.IsNullOrEmpty(diaChi))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin sinh viên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(lopChon))
            {
                MessageBox.Show("Vui lòng chọn lớp trong ComboBox!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            TreeNode targetNode = null;
            foreach (TreeNode node in treeView1.Nodes)
            {
                if (node.Text == lopChon)
                {
                    targetNode = node;
                    break;
                }
            }

            if (targetNode == null) return;

            foreach (TreeNode svNode in targetNode.Nodes)
            {
                string existingMaSV = svNode.Text.Split(',')[0].Trim();
                if (existingMaSV.Equals(maSV, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Mã sinh viên đã tồn tại trong lớp này!", "Lỗi trùng mã", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            TreeNode nodeSV = new TreeNode($"{maSV}, {hoTen}");
            nodeSV.Nodes.Add(diaChi);

            targetNode.Nodes.Add(nodeSV);
            targetNode.Expand();

            txtMaSV.Clear();
            txtHoTen.Clear();
            txtDiaChi.Clear();
            MessageBox.Show("Thêm sinh viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeView1.SelectedNode;
            if (selectedNode == null)
            {
                MessageBox.Show("Vui lòng chọn một sinh viên trên TreeView để xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (selectedNode.Level == 1)
            {
                DialogResult dr = MessageBox.Show("Bạn có chắc chắn muốn xóa sinh viên này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    selectedNode.Remove();
                    txtMaSV.Clear();
                    txtHoTen.Clear();
                    txtDiaChi.Clear();
                }
            }
            else
            {
                MessageBox.Show("Chỉ được phép xóa thông tin sinh viên, không được xóa tên lớp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Level == 1)
            {
                string[] parts = e.Node.Text.Split(',');
                if (parts.Length >= 2)
                {
                    txtMaSV.Text = parts[0].Trim();
                    txtHoTen.Text = parts[1].Trim();
                }
                if (e.Node.Nodes.Count > 0)
                {
                    txtDiaChi.Text = e.Node.Nodes[0].Text.Trim();
                }
            }
        }
    }
}