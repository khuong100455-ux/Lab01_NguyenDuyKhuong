#nullable disable
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace baitapvenha1
{
    public partial class Form1 : Form
    {
        private TabControl tabControl1;
        private TabPage tabAnhViet, tabVietAnh;

        // Tab Anh - Việt Controls
        private ComboBox cboTimAnh;
        private ListBox listAnh;
        private TextBox txtNghiaViet;
        private Label lblTuAnh, lblNghiaViet;

        // Tab Việt - Anh Controls
        private ComboBox cboTimViet;
        private ListBox listViet;
        private TextBox txtNghiaAnh;
        private Label lblTuViet, lblNghiaAnh;

        private Button btnThoat;

        // Dữ liệu từ điển mẫu
        private Dictionary<string, string> dictAnhViet;
        private Dictionary<string, string> dictVietAnh;

        public Form1()
        {
            InitializeComponentCustom();
            KhoiTaoDuLieuTuDien();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "TỪ ĐIỂN ANH VIỆT - VIỆT ANH";
            this.Size = new Size(650, 480);
            this.StartPosition = FormStartPosition.CenterScreen;

            // TabControl chứa 2 tab
            tabControl1 = new TabControl() { Location = new Point(12, 12), Size = new Size(610, 390) };
            
            tabAnhViet = new TabPage("ANH - VIỆT");
            tabVietAnh = new TabPage("VIỆT - ANH");

            // --- CẤU HÌNH TAB ANH - VIỆT ---
            lblTuAnh = new Label() { Text = "Tiếng Anh", Location = new Point(15, 15), AutoSize = true };
            cboTimAnh = new ComboBox() { Location = new Point(15, 40), Size = new Size(220, 25) };
            cboTimAnh.KeyUp += new KeyEventHandler(this.cboTimAnh_KeyUp);
            cboTimAnh.SelectedIndexChanged += new EventHandler(this.cboTimAnh_SelectedIndexChanged);

            listAnh = new ListBox() { Location = new Point(15, 75), Size = new Size(220, 255) };
            listAnh.DoubleClick += new EventHandler(this.listAnh_DoubleClick);
            listAnh.KeyDown += new KeyEventHandler(this.listAnh_KeyDown);
            listAnh.SelectedIndexChanged += new EventHandler(this.listAnh_SelectedIndexChanged);

            lblNghiaViet = new Label() { Text = "Tiếng Việt", Location = new Point(255, 15), AutoSize = true };
            txtNghiaViet = new TextBox() { Location = new Point(255, 40), Size = new Size(330, 290), Multiline = true, ReadOnly = true };

            tabAnhViet.Controls.Add(lblTuAnh);
            tabAnhViet.Controls.Add(cboTimAnh);
            tabAnhViet.Controls.Add(listAnh);
            tabAnhViet.Controls.Add(lblNghiaViet);
            tabAnhViet.Controls.Add(txtNghiaViet);

            // --- CẤU HÌNH TAB VIỆT - ANH ---
            lblTuViet = new Label() { Text = "Tiếng Việt", Location = new Point(15, 15), AutoSize = true };
            cboTimViet = new ComboBox() { Location = new Point(15, 40), Size = new Size(220, 25) };
            cboTimViet.KeyUp += new KeyEventHandler(this.cboTimViet_KeyUp);
            cboTimViet.SelectedIndexChanged += new EventHandler(this.cboTimViet_SelectedIndexChanged);

            listViet = new ListBox() { Location = new Point(15, 75), Size = new Size(220, 255) };
            listViet.DoubleClick += new EventHandler(this.listViet_DoubleClick);
            listViet.KeyDown += new KeyEventHandler(this.listViet_KeyDown);
            listViet.SelectedIndexChanged += new EventHandler(this.listViet_SelectedIndexChanged);

            lblNghiaAnh = new Label() { Text = "Tiếng Anh", Location = new Point(255, 15), AutoSize = true };
            txtNghiaAnh = new TextBox() { Location = new Point(255, 40), Size = new Size(330, 290), Multiline = true, ReadOnly = true };

            tabVietAnh.Controls.Add(lblTuViet);
            tabVietAnh.Controls.Add(cboTimViet);
            tabVietAnh.Controls.Add(listViet);
            tabVietAnh.Controls.Add(lblNghiaAnh);
            tabVietAnh.Controls.Add(txtNghiaAnh);

            // Thêm các tab vào TabControl
            tabControl1.TabPages.Add(tabAnhViet);
            tabControl1.TabPages.Add(tabVietAnh);

            // Nút Thoát
            btnThoat = new Button() { Text = "Thoát", Location = new Point(522, 410), Width = 100, Height = 30 };
            btnThoat.Click += (s, e) => this.Close();

            // Thêm vào Form chính
            this.Controls.Add(tabControl1);
            this.Controls.Add(btnThoat);
        }

        // Khởi tạo từ điển mẫu
        private void KhoiTaoDuLieuTuDien()
        {
            dictAnhViet = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "student", "Sinh viên, học sinh" },
                { "teacher", "Giáo viên, giảng viên" },
                { "worker", "Công nhân, người lao động" },
                { "hat", "Cái mũ, nón" },
                { "head", "Đầu, thủ trưởng" },
                { "mouse", "Con chuột (máy tính, động vật)" },
                { "cat", "Con mèo" },
                { "dog", "Con chó" },
                { "snake", "Con rắn" },
                { "lamb", "Con cừu non" },
                { "loan", "Khoản vay, cho vay" },
                { "frog", "Con ếch" },
                { "sheep", "Con cừu" }
            };

            dictVietAnh = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "Sinh viên, học sinh", "student" },
                { "Giáo viên, giảng viên", "teacher" },
                { "Công nhân, người lao động", "worker" },
                { "Cái mũ, nón", "hat" },
                { "Đầu, thủ trưởng", "head" },
                { "Con chuột", "mouse" },
                { "Con mèo", "cat" },
                { "Con chó", "dog" },
                { "Con rắn", "snake" },
                { "Con cừu non", "lamb" },
                { "Khoản vay", "loan" },
                { "Con ếch", "frog" },
                { "Con cừu", "sheep" }
            };

            // Nạp dữ liệu vào ListBox và ComboBox
            foreach (var kvp in dictAnhViet)
            {
                listAnh.Items.Add(kvp.Key);
                cboTimAnh.Items.Add(kvp.Key);
            }

            foreach (var kvp in dictVietAnh)
            {
                listViet.Items.Add(kvp.Key);
                cboTimViet.Items.Add(kvp.Key);
            }
        }

        // --- XỬ LÝ TAB ANH - VIỆT ---

        private void cboTimAnh_KeyUp(object sender, KeyEventArgs e)
        {
            string keyword = cboTimAnh.Text.Trim();
            if (!string.IsNullOrEmpty(keyword))
            {
                int index = listAnh.FindString(keyword); // Dò tìm từ khớp ký tự gần nhất
                if (index != -1)
                {
                    listAnh.SelectedIndex = index;
                }
            }

            if (e.KeyCode == Keys.Enter)
            {
                HienThiNghiaAnhViet();
            }
        }

        private void cboTimAnh_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboTimAnh.SelectedItem != null)
            {
                string selectedWord = cboTimAnh.SelectedItem.ToString();
                int index = listAnh.FindStringExact(selectedWord);
                if (index != -1)
                {
                    listAnh.SelectedIndex = index;
                }
            }
        }

        private void listAnh_SelectedIndexChanged(object sender, EventArgs e)
        {
            HienThiNghiaAnhViet();
        }

        private void listAnh_DoubleClick(object sender, EventArgs e)
        {
            HienThiNghiaAnhViet();
        }

        private void listAnh_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                HienThiNghiaAnhViet();
            }
        }

        private void HienThiNghiaAnhViet()
        {
            if (listAnh.SelectedItem != null)
            {
                string word = listAnh.SelectedItem.ToString();
                if (dictAnhViet.ContainsKey(word))
                {
                    txtNghiaViet.Text = dictAnhViet[word];
                    cboTimAnh.Text = word;
                }
            }
        }


        // --- XỬ LÝ TAB VIỆT - ANH ---

        private void cboTimViet_KeyUp(object sender, KeyEventArgs e)
        {
            string keyword = cboTimViet.Text.Trim();
            if (!string.IsNullOrEmpty(keyword))
            {
                int index = listViet.FindString(keyword);
                if (index != -1)
                {
                    listViet.SelectedIndex = index;
                }
            }

            if (e.KeyCode == Keys.Enter)
            {
                HienThiNghiaVietAnh();
            }
        }

        private void cboTimViet_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboTimViet.SelectedItem != null)
            {
                string selectedWord = cboTimViet.SelectedItem.ToString();
                int index = listViet.FindStringExact(selectedWord);
                if (index != -1)
                {
                    listViet.SelectedIndex = index;
                }
            }
        }

        private void listViet_SelectedIndexChanged(object sender, EventArgs e)
        {
            HienThiNghiaVietAnh();
        }

        private void listViet_DoubleClick(object sender, EventArgs e)
        {
            HienThiNghiaVietAnh();
        }

        private void listViet_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                HienThiNghiaVietAnh();
            }
        }

        private void HienThiNghiaVietAnh()
        {
            if (listViet.SelectedItem != null)
            {
                string word = listViet.SelectedItem.ToString();
                if (dictVietAnh.ContainsKey(word))
                {
                    txtNghiaAnh.Text = dictVietAnh[word];
                    cboTimViet.Text = word;
                }
            }
        }
    }
}