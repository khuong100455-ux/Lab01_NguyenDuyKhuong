#nullable disable
using System;
using System.Windows.Forms;

namespace baitapvenha5d
{
    static class Program
    {
        [STAThread]
        [Obsolete]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmLop());
        }
    }
}