﻿using System;

namespace BaiTapSapXepTongQuat
{
    public class ThuThuatThuatToan
    {
        // =========================================================================
        // a. PHƯƠNG THỨC SẮP XẾP TỔNG QUÁT MÔ PHỎNG Array.Sort(...)
        // =========================================================================

        /// <summary>
        /// Phương thức tĩnh tổng quát (Generic) sắp xếp mảng bất kỳ chứa các phần tử thực thi IComparable<T>
        /// </summary>
        public static void SapXepTongQuat<T>(T[] arr) where T : IComparable<T>
        {
            if (arr == null || arr.Length <= 1) return;

            int n = arr.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    // Gọi CompareTo() từ Interface IComparable<T>
                    if (arr[i].CompareTo(arr[j]) > 0)
                    {
                        T temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
        }

        // =========================================================================
        // b. STRUCT PHẦN TỬ SẢN PHẨM CÓ CÀI ĐẶT IComparable
        // =========================================================================

        public struct SanPham : IComparable<SanPham>
        {
            public string TenSP;
            public double GiaBan;

            public SanPham(string tenSP, double giaBan)
            {
                TenSP = tenSP;
                GiaBan = giaBan;
            }

            public int CompareTo(SanPham other)
            {
                return this.GiaBan.CompareTo(other.GiaBan);
            }

            public override string ToString()
            {
                return $"Tên SP: {TenSP,-15} | Giá bán: {GiaBan,12:N0} VNĐ";
            }
        }

        // =========================================================================
        // c. CÁC PHƯƠNG THỨC NHẬP DỮ LIỆU TỪ BÀN PHÍM
        // =========================================================================

        // 1. Nhập mảng Số nguyên
        public static int[] NhapMangSoNguyen()
        {
            Console.Write("Nhập số lượng phần tử số nguyên (n): ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Số lượng phải > 0. Nhập lại n: ");
            }

            int[] arr = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write($"  Nhập phần tử thứ [{i}]: ");
                while (!int.TryParse(Console.ReadLine(), out arr[i]))
                {
                    Console.Write($"  Số không hợp lệ. Nhập lại [{i}]: ");
                }
            }
            return arr;
        }

        // 2. Nhập mảng Chuỗi
        public static string[] NhapMangChuoi()
        {
            Console.Write("Nhập số lượng chuỗi (n): ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Số lượng phải > 0. Nhập lại n: ");
            }

            string[] arr = new string[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write($"  Nhập chuỗi thứ [{i}]: ");
                arr[i] = Console.ReadLine();
            }
            return arr;
        }

        // 3. Nhập mảng Sản phẩm
        public static SanPham[] NhapMangSanPham()
        {
            Console.Write("Nhập số lượng sản phẩm (n): ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Số lượng phải > 0. Nhập lại n: ");
            }

            SanPham[] arr = new SanPham[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\n[Sản phẩm thứ {i + 1}]");
                Console.Write("  Nhập tên sản phẩm: ");
                string ten = Console.ReadLine();

                Console.Write("  Nhập giá bán: ");
                double gia;
                while (!double.TryParse(Console.ReadLine(), out gia) || gia < 0)
                {
                    Console.Write("  Giá bán không hợp lệ. Nhập lại: ");
                }

                arr[i] = new SanPham(ten, gia);
            }
            return arr;
        }

        // =========================================================================
        // d. PHƯƠNG THỨC HỖ TRỢ XUẤT MẢNG TỔNG QUÁT
        // =========================================================================

        public static void XuatMang<T>(T[] arr)
        {
            if (arr == null || arr.Length == 0)
            {
                Console.WriteLine("Mảng rỗng.");
                return;
            }

            foreach (T item in arr)
            {
                Console.WriteLine(item);
            }
        }
    }

    // =========================================================================
    // CHƯƠNG TRÌNH CHÍNH (MAIN TRẠY ĐỘC LẬP BÀI 3.2)
    // =========================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== BÀI TẬP 3.2: SẮP XẾP MẢNG TỔNG QUÁT (NHẬP TỪ BÀN PHÍM) ===");

            // ---------------------------------------------------------------------
            // 1. Nhập và tự sắp xếp Mảng Số Nguyên
            // ---------------------------------------------------------------------
            Console.WriteLine("\n--- 1. THỬ NGHIỆM VỚI MẢNG SỐ NGUYÊN ---");
            int[] mangSo = ThuThuatThuatToan.NhapMangSoNguyen();

            ThuThuatThuatToan.SapXepTongQuat(mangSo);
            Console.WriteLine("--> Mảng số nguyên sau khi tự sắp xếp tăng dần:");
            Console.WriteLine(string.Join(", ", mangSo));

            // ---------------------------------------------------------------------
            // 2. Nhập và tự sắp xếp Mảng Chuỗi Ký Tự
            // ---------------------------------------------------------------------
            Console.WriteLine("\n--- 2. THỬ NGHIỆM VỚI MẢNG CHUỖI ---");
            string[] mangChuoi = ThuThuatThuatToan.NhapMangChuoi();

            ThuThuatThuatToan.SapXepTongQuat(mangChuoi);
            Console.WriteLine("--> Mảng chuỗi sau khi tự sắp xếp theo Alphabet:");
            Console.WriteLine(string.Join(", ", mangChuoi));

            // ---------------------------------------------------------------------
            // 3. Nhập và tự sắp xếp Mảng Sản Phẩm
            // ---------------------------------------------------------------------
            Console.WriteLine("\n--- 3. THỬ NGHIỆM VỚI MẢNG ĐỐI TƯỢNG SẢN PHẨM ---");
            ThuThuatThuatToan.SanPham[] dsSanPham = ThuThuatThuatToan.NhapMangSanPham();

            ThuThuatThuatToan.SapXepTongQuat(dsSanPham);
            Console.WriteLine("\n--> Danh sách sản phẩm sau khi tự sắp xếp theo GIÁ BÁN TĂNG DẦN:");
            ThuThuatThuatToan.XuatMang(dsSanPham);

            Console.ReadLine();
        }
    }
}