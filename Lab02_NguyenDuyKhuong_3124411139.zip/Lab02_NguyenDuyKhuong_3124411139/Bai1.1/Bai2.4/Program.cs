﻿using System;
using System.Collections.Generic;

namespace BaiTap2_4
{
    // =========================================================================
    // KHAI BÁO LỚP MẢNG 2 CHIỀU
    // =========================================================================
    public class Mang2Chieu
    {
        // Trường lưu trữ dữ liệu mảng 2 chiều
        private int[,] data;

        // Thuộc tính lấy số dòng và số cột
        public int SoDong
        {
            get { return data != null ? data.GetLength(0) : 0; }
        }

        public int SoCot
        {
            get { return data != null ? data.GetLength(1) : 0; }
        }

        // ---------------------------------------------------------------------
        // a. CÁC LOẠI CONSTRUCTOR
        // ---------------------------------------------------------------------

        // 1. Constructor mặc định: Tạo mảng 0x0
        public Mang2Chieu()
        {
            data = new int[0, 0];
        }

        // 2. Constructor có tham số kích thước n x m
        public Mang2Chieu(int n, int m)
        {
            if (n < 0) n = 0;
            if (m < 0) m = 0;
            data = new int[n, m];
        }

        // 3. Constructor sao chép từ mảng 2 chiều có sẵn
        public Mang2Chieu(int[,] arr)
        {
            if (arr != null)
            {
                int rows = arr.GetLength(0);
                int cols = arr.GetLength(1);
                data = new int[rows, cols];
                Array.Copy(arr, data, arr.Length);
            }
            else
            {
                data = new int[0, 0];
            }
        }

        // ---------------------------------------------------------------------
        // b. INDEXER TRUY CẬP PHẦN TỬ TẠI (i, j)
        // ---------------------------------------------------------------------

        public int this[int i, int j]
        {
            get
            {
                if (i < 0 || i >= SoDong || j < 0 || j >= SoCot)
                {
                    throw new IndexOutOfRangeException("Chỉ số nằm ngoài phạm vi mảng.");
                }
                return data[i, j];
            }
            set
            {
                if (i < 0 || i >= SoDong || j < 0 || j >= SoCot)
                {
                    throw new IndexOutOfRangeException("Chỉ số nằm ngoài phạm vi mảng.");
                }
                data[i, j] = value;
            }
        }

        // ---------------------------------------------------------------------
        // c. NHẬP / XUẤT MẢNG 2 CHIỀU
        // ---------------------------------------------------------------------

        public void Nhap()
        {
            int n, m;
            Console.Write("Nhập số dòng (n): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 0)
            {
                Console.Write("Số dòng không hợp lệ. Nhập lại n: ");
            }

            Console.Write("Nhập số cột (m): ");
            while (!int.TryParse(Console.ReadLine(), out m) || m < 0)
            {
                Console.Write("Số cột không hợp lệ. Nhập lại m: ");
            }

            data = new int[n, m];

            Console.WriteLine($"\n--- Nhập giá trị cho mảng {n}x{m} ---");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write($"Phần tử [{i}, {j}]: ");
                    while (!int.TryParse(Console.ReadLine(), out data[i, j]))
                    {
                        Console.Write($"Giá trị không hợp lệ. Nhập lại [{i}, {j}]: ");
                    }
                }
            }
        }

        public void Xuat()
        {
            if (data == null || SoDong == 0 || SoCot == 0)
            {
                Console.WriteLine("Mảng 2 chiều rỗng.");
                return;
            }

            for (int i = 0; i < SoDong; i++)
            {
                for (int j = 0; j < SoCot; j++)
                {
                    Console.Write($"{data[i, j],6}");
                }
                Console.WriteLine();
            }
        }

        // ---------------------------------------------------------------------
        // d. TÌM CÁC SỐ NGUYÊN TỐ TRONG MẢNG
        // ---------------------------------------------------------------------

        // Hàm hỗ trợ kiểm tra một số có phải số nguyên tố không
        private bool KiemTraNguyenTo(int number)
        {
            if (number < 2) return false;
            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0) return false;
            }
            return true;
        }

        // Trả về danh sách các số nguyên tố có trong mảng
        public List<int> TimSoNguyenTo()
        {
            List<int> dsSoNguyenTo = new List<int>();

            for (int i = 0; i < SoDong; i++)
            {
                for (int j = 0; j < SoCot; j++)
                {
                    if (KiemTraNguyenTo(data[i, j]))
                    {
                        dsSoNguyenTo.Add(data[i, j]);
                    }
                }
            }

            return dsSoNguyenTo;
        }
    }

    // =========================================================================
    // CHƯƠNG TRÌNH CHÍNH (MAIN TRẠY ĐỘC LẬP CHO BÀI 2.4)
    // =========================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== BÀI 2.4: QUẢN LÝ MẢNG 2 CHIỀU ===");

            // 1. Khởi tạo đối tượng mảng 2 chiều và thực hiện Nhập/Xuất
            Mang2Chieu m2c = new Mang2Chieu();
            m2c.Nhap();

            Console.WriteLine("\n--> Ma trận vừa nhập:");
            m2c.Xuat();

            // 2. Kiểm thử Indexer
            if (m2c.SoDong > 0 && m2c.SoCot > 0)
            {
                Console.WriteLine($"\nĐọc giá trị tại vị trí [0, 0] qua Indexer: {m2c[0, 0]}");

                // Đổi giá trị thông qua Indexer
                m2c[0, 0] = 99;
                Console.WriteLine("--> Ma trận sau khi đổi giá trị m2c[0, 0] thành 99:");
                m2c.Xuat();
            }

            // 3. Tìm các số nguyên tố trong mảng
            List<int> danhSachSNT = m2c.TimSoNguyenTo();
            Console.Write("\n--> Các số nguyên tố có trong mảng: ");
            if (danhSachSNT.Count > 0)
            {
                Console.WriteLine(string.Join(", ", danhSachSNT));
            }
            else
            {
                Console.WriteLine("Không có số nguyên tố nào.");
            }

            Console.ReadLine();
        }
    }
}