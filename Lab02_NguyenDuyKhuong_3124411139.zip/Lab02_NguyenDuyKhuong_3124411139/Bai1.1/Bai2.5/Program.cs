﻿using System;

namespace BaiTapDaThuc
{
    // =========================================================================
    // KHAI BÁO LỚP ĐA THỨC
    // =========================================================================
    public class DaThuc
    {
        // Mảng private lưu hệ số các đơn thức: a[i] tương ứng với hệ số của x^i
        private double[] a;

        // Thuộc tính lấy bậc của đa thức (n)
        public int Bac
        {
            get { return a != null && a.Length > 0 ? a.Length - 1 : 0; }
        }

        // ---------------------------------------------------------------------
        // a. CÁC LOẠI CONSTRUCTOR
        // ---------------------------------------------------------------------

        // 1. Constructor mặc định (đa thức bậc 0 với hệ số = 0)
        public DaThuc()
        {
            a = new double[1] { 0 };
        }

        // 2. Constructor tạo đa thức bậc n (mảng có n + 1 phần tử)
        public DaThuc(int n)
        {
            if (n < 0) n = 0;
            a = new double[n + 1];
        }

        // 3. Constructor sao chép từ một mảng hệ số có sẵn
        public DaThuc(double[] heSo)
        {
            if (heSo != null && heSo.Length > 0)
            {
                a = new double[heSo.Length];
                Array.Copy(heSo, a, heSo.Length);
            }
            else
            {
                a = new double[1] { 0 };
            }
        }

        // ---------------------------------------------------------------------
        // b. INDEXER TRUY CẬP HỆ SỐ ĐƠN THỨC BẬC I
        // ---------------------------------------------------------------------

        public double this[int i]
        {
            get
            {
                if (i < 0 || i >= a.Length)
                {
                    throw new IndexOutOfRangeException("Bậc của đơn thức nằm ngoài phạm vi đa thức.");
                }
                return a[i];
            }
            set
            {
                if (i < 0 || i >= a.Length)
                {
                    throw new IndexOutOfRangeException("Bậc của đơn thức nằm ngoài phạm vi đa thức.");
                }
                a[i] = value;
            }
        }

        // ---------------------------------------------------------------------
        // c. NHẬP / XUẤT ĐA THỨC
        // ---------------------------------------------------------------------

        public void Nhap()
        {
            int n;
            Console.Write("Nhập bậc của đa thức (n): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 0)
            {
                Console.Write("Bậc không hợp lệ. Nhập lại n (n >= 0): ");
            }

            a = new double[n + 1];

            Console.WriteLine($"\n--- Nhập hệ số cho đa thức bậc {n} ---");
            for (int i = 0; i <= n; i++)
            {
                Console.Write($"Nhập hệ số a[{i}] (của x^{i}): ");
                while (!double.TryParse(Console.ReadLine(), out a[i]))
                {
                    Console.Write($"Giá trị không hợp lệ. Nhập lại a[{i}]: ");
                }
            }
        }

        public void Xuat()
        {
            if (a == null || a.Length == 0)
            {
                Console.WriteLine("P(x) = 0");
                return;
            }

            Console.Write("P(x) = ");
            bool isFirst = true;

            for (int i = 0; i < a.Length; i++)
            {
                // Bỏ qua các hệ số bằng 0 ngoại trừ trường hợp đa thức chỉ có duy nhất số 0
                if (a[i] == 0 && a.Length > 1) continue;

                if (!isFirst)
                {
                    if (a[i] > 0) Console.Write(" + ");
                    else Console.Write(" - ");
                }
                else
                {
                    if (a[i] < 0) Console.Write("-");
                    isFirst = false;
                }

                double val = Math.Abs(a[i]);

                // In số/x tùy theo số mũ
                if (i == 0)
                {
                    Console.Write(val);
                }
                else if (i == 1)
                {
                    if (val == 1) Console.Write("x");
                    else Console.Write($"{val}*x");
                }
                else
                {
                    if (val == 1) Console.Write($"x^{i}");
                    else Console.Write($"{val}*x^{i}");
                }
            }

            if (isFirst) Console.Write("0");
            Console.WriteLine();
        }

        // ---------------------------------------------------------------------
        // d. TÍNH GIÁ TRỊ CỦA ĐA THỨC VỚI GIÁ TRỊ X NHẬP TỪ BÀN PHÍM
        // ---------------------------------------------------------------------

        public double TinhGiaTri(double x)
        {
            double result = 0;
            for (int i = 0; i < a.Length; i++)
            {
                result += a[i] * Math.Pow(x, i);
            }
            return result;
        }
    }

    // =========================================================================
    // CHƯƠNG TRÌNH CHÍNH (MAIN TRẠY ĐỘC LẬP)
    // =========================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== BÀI TẬP: ĐA THỨC ===");

            // 1. Tạo đối tượng đa thức và thực hiện Nhập / Xuất
            DaThuc dt = new DaThuc();
            dt.Nhap();

            Console.WriteLine("\n--> Biểu thức đa thức vừa nhập:");
            dt.Xuat();

            // 2. Thử nghiệm Indexer
            Console.WriteLine($"\nBậc của đa thức: {dt.Bac}");
            if (dt.Bac >= 0)
            {
                Console.WriteLine($"Đọc hệ số a[0] (hệ số tự do) qua Indexer: {dt[0]}");

                // Thay đổi thử hệ số tự do
                dt[0] = dt[0] + 5;
                Console.WriteLine("--> Đa thức sau khi cộng thêm 5 vào hệ số tự do dt[0]:");
                dt.Xuat();
            }

            // 3. Tính giá trị đa thức P(x) tại x nhập từ bàn phím
            Console.Write("\nNhập giá trị x để tính P(x): ");
            double x;
            while (!double.TryParse(Console.ReadLine(), out x))
            {
                Console.Write("Giá trị x không hợp lệ. Nhập lại: ");
            }

            double result = dt.TinhGiaTri(x);
            Console.WriteLine($"--> Giá trị P({x}) = {result}");

            Console.ReadLine();
        }
    }
}