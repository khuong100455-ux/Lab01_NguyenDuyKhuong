﻿using System;

namespace BaiTapDayPhanSo
{
    public class DayPhanSo
    {
        // Struct Phân số được khai báo nội bộ bên trong lớp DayPhanSo
        public struct PhanSo
        {
            public int TuSo;
            public int MauSo;

            public PhanSo(int tu, int mau)
            {
                TuSo = tu;
                MauSo = mau != 0 ? mau : 1;
            }

            public override string ToString()
            {
                if (MauSo == 1) return TuSo.ToString();
                return $"{TuSo}/{MauSo}";
            }
        }

        // Mảng 1 chiều lưu danh sách các phân số
        private PhanSo[] data;

        // Thuộc tính lấy số lượng phân số
        public int SoLuong
        {
            get { return data != null ? data.Length : 0; }
        }

        // =========================================================================
        // a. CÁC LOẠI CONSTRUCTOR
        // =========================================================================

        // 1. Constructor mặc định
        public DayPhanSo()
        {
            data = new PhanSo[0];
        }

        // 2. Constructor tạo dãy chứa n phân số
        public DayPhanSo(int n)
        {
            if (n < 0) n = 0;
            data = new PhanSo[n];
            for (int i = 0; i < n; i++)
            {
                data[i] = new PhanSo(0, 1);
            }
        }

        // =========================================================================
        // b. INDEXER TRUY CẬP PHẦN TỬ THỨ I
        // =========================================================================

        public PhanSo this[int index]
        {
            get
            {
                if (index < 0 || index >= SoLuong)
                {
                    throw new IndexOutOfRangeException("Chỉ số vượt quá số lượng phân số.");
                }
                return data[index];
            }
            set
            {
                if (index < 0 || index >= SoLuong)
                {
                    throw new IndexOutOfRangeException("Chỉ số vượt quá số lượng phân số.");
                }
                data[index] = value;
            }
        }

        // =========================================================================
        // c. NHẬP / XUẤT DÃY PHÂN SỐ
        // =========================================================================

        public void Nhap()
        {
            int n;
            Console.Write("Nhập số lượng phân số (n): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Số lượng phải là số nguyên dương. Nhập lại n: ");
            }

            data = new PhanSo[n];

            Console.WriteLine($"\n--- Nhập thông tin cho {n} phân số ---");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\n[Phân số thứ {i + 1}]");

                Console.Write("  Nhập tử số: ");
                int tu;
                while (!int.TryParse(Console.ReadLine(), out tu))
                {
                    Console.Write("  Tử số không hợp lệ. Nhập lại tử số: ");
                }

                Console.Write("  Nhập mẫu số (khác 0): ");
                int mau;
                while (!int.TryParse(Console.ReadLine(), out mau) || mau == 0)
                {
                    Console.Write("  Mẫu số không hợp lệ (phải khác 0). Nhập lại mẫu số: ");
                }

                data[i] = new PhanSo(tu, mau);
            }
        }

        public void Xuat()
        {
            if (data == null || SoLuong == 0)
            {
                Console.WriteLine("Dãy phân số rỗng.");
                return;
            }

            for (int i = 0; i < SoLuong; i++)
            {
                Console.Write(data[i]);
                if (i < SoLuong - 1) Console.Write(" ; ");
            }
            Console.WriteLine();
        }

        // =========================================================================
        // d. TÍNH TỔNG N PHÂN SỐ
        // =========================================================================

        // Hàm hỗ trợ tìm ƯCLN để rút gọn tổng phân số
        private int UCLN(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);
            while (b != 0)
            {
                int temp = a % b;
                a = b;
                b = temp;
            }
            return a;
        }

        public PhanSo TinhTong()
        {
            if (SoLuong == 0) return new PhanSo(0, 1);

            int tuTong = 0;
            int mauTong = 1;

            // Quy đồng và cộng dồn từng phân số trong dãy
            foreach (PhanSo ps in data)
            {
                tuTong = tuTong * ps.MauSo + ps.TuSo * mauTong;
                mauTong = mauTong * ps.MauSo;

                // Rút gọn bớt sau mỗi bước cộng để tránh tràn số int
                int ucln = UCLN(tuTong, mauTong);
                tuTong /= ucln;
                mauTong /= ucln;
            }

            // Đảm bảo dấu âm nằm ở tử số
            if (mauTong < 0)
            {
                tuTong = -tuTong;
                mauTong = -mauTong;
            }

            return new PhanSo(tuTong, mauTong);
        }
    }

    // =========================================================================
    // CHƯƠNG TRÌNH CHÍNH (MAIN TRẠY ĐỘC LẬP)
    // =========================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== BÀI TẬP 2.4: QUẢN LÝ DÃY PHÂN SỐ ===");

            // Khởi tạo duy nhất 1 đối tượng Dãy Phân Số
            DayPhanSo dps = new DayPhanSo();

            // Nhập xuất dãy phân số
            dps.Nhap();
            Console.Write("\n--> Dãy phân số vừa nhập: ");
            dps.Xuat();

            // Tính tổng n phân số
            DayPhanSo.PhanSo tong = dps.TinhTong();
            Console.WriteLine($"--> Tổng của {dps.SoLuong} phân số là: {tong}");

            // Thử nghiệm Indexer
            if (dps.SoLuong > 0)
            {
                Console.WriteLine($"\nPhân số đầu tiên trong dãy (dps[0]): {dps[0]}");
            }

            Console.ReadLine();
        }
    }
}