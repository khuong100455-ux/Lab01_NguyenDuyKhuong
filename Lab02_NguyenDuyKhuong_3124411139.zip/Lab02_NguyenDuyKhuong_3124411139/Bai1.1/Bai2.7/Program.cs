﻿using System;

namespace BaiTapTinhLuong
{
    public class PhongBan
    {
        // Struct NhanVien được khai báo nội bộ bên trong lớp PhongBan
        public struct NhanVien
        {
            public string HoTen;
            public double MucLuong;
            public int SoNgayVang;

            public NhanVien(string hoTen, double mucLuong, int soNgayVang)
            {
                HoTen = hoTen;
                MucLuong = mucLuong;
                SoNgayVang = soNgayVang;
            }

            // Tính lương thực lĩnh của 1 nhân viên
            public double TinhLuongThucLinh()
            {
                double luongTru = SoNgayVang * 100000.0;
                double luongThucLinh = MucLuong - luongTru;
                return luongThucLinh > 0 ? luongThucLinh : 0; // Đảm bảo lương không âm
            }

            public override string ToString()
            {
                return $"Họ tên: {HoTen,-20} | Lương cơ bản: {MucLuong,12:N0} VNĐ | Số ngày vắng: {SoNgayVang,2} | Thực lĩnh: {TinhLuongThucLinh(),12:N0} VNĐ";
            }
        }

        // Mảng private chứa danh sách nhân viên trong phòng ban
        private NhanVien[] dsNhanVien;

        // Thuộc tính lấy số lượng nhân viên
        public int SoLuong
        {
            get { return dsNhanVien != null ? dsNhanVien.Length : 0; }
        }

        // =========================================================================
        // a. CÁC LOẠI CONSTRUCTOR
        // =========================================================================

        // 1. Constructor mặc định
        public PhongBan()
        {
            dsNhanVien = new NhanVien[0];
        }

        // 2. Constructor tạo phòng ban có n nhân viên
        public PhongBan(int n)
        {
            if (n < 0) n = 0;
            dsNhanVien = new NhanVien[n];
        }

        // =========================================================================
        // b. INDEXER TRUY CẬP NHÂN VIÊN THỨ I
        // =========================================================================

        public NhanVien this[int index]
        {
            get
            {
                if (index < 0 || index >= SoLuong)
                {
                    throw new IndexOutOfRangeException("Chỉ số vượt quá số lượng nhân viên.");
                }
                return dsNhanVien[index];
            }
            set
            {
                if (index < 0 || index >= SoLuong)
                {
                    throw new IndexOutOfRangeException("Chỉ số vượt quá số lượng nhân viên.");
                }
                dsNhanVien[index] = value;
            }
        }

        // =========================================================================
        // c. NHẬP / XUẤT DANH SÁCH NHÂN VIÊN
        // =========================================================================

        public void Nhap()
        {
            int n;
            Console.Write("Nhập số lượng nhân viên trong phòng ban (n): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Số lượng phải là số nguyên dương. Nhập lại n: ");
            }

            dsNhanVien = new NhanVien[n];

            Console.WriteLine($"\n--- NHẬP THÔNG TIN {n} NHÂN VIÊN ---");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\n[Nhân viên thứ {i + 1}]");

                Console.Write("  Nhập họ tên: ");
                string hoTen = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(hoTen))
                {
                    Console.Write("  Họ tên không được để trống. Nhập lại: ");
                    hoTen = Console.ReadLine();
                }

                Console.Write("  Nhập mức lương (VNĐ): ");
                double mucLuong;
                while (!double.TryParse(Console.ReadLine(), out mucLuong) || mucLuong < 0)
                {
                    Console.Write("  Mức lương không hợp lệ. Nhập lại mức lương: ");
                }

                Console.Write("  Nhập số ngày vắng: ");
                int soNgayVang;
                while (!int.TryParse(Console.ReadLine(), out soNgayVang) || soNgayVang < 0)
                {
                    Console.Write("  Số ngày vắng không hợp lệ. Nhập lại: ");
                }

                dsNhanVien[i] = new NhanVien(hoTen, mucLuong, soNgayVang);
            }
        }

        public void Xuat()
        {
            if (dsNhanVien == null || SoLuong == 0)
            {
                Console.WriteLine("Danh sách nhân viên rỗng.");
                return;
            }

            Console.WriteLine("\n--- DANH SÁCH LƯƠNG NHÂN VIÊN ---");
            for (int i = 0; i < SoLuong; i++)
            {
                Console.WriteLine($"{i + 1}. {dsNhanVien[i]}");
            }
        }

        // =========================================================================
        // d. TÍNH TỔNG LƯƠNG CỦA PHÒNG BAN
        // =========================================================================

        public double TinhTongLuong()
        {
            double tongLuong = 0;
            foreach (NhanVien nv in dsNhanVien)
            {
                tongLuong += nv.TinhLuongThucLinh();
            }
            return tongLuong;
        }
    }

    // =========================================================================
    // CHƯƠNG TRÌNH CHÍNH (MAIN TRẠY ĐỘC LẬP BÀI 2.5)
    // =========================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== BÀI TẬP 2.5: TÍNH LƯƠNG NHÂN VIÊN PHÒNG BAN ===");

            // Khởi tạo đối tượng Phòng ban
            PhongBan pb = new PhongBan();

            // 1. Nhập thông tin các nhân viên
            pb.Nhap();

            // 2. Xuất danh sách nhân viên kèm lương thực lĩnh
            pb.Xuat();

            // 3. Tính tổng lương toàn phòng ban
            double tongLuong = pb.TinhTongLuong();
            Console.WriteLine("\n==================================================");
            Console.WriteLine($"--> TỔNG LƯƠNG PHÒNG BAN: {tongLuong:N0} VNĐ");
            Console.WriteLine("==================================================");

            // 4. Thử nghiệm Indexer
            if (pb.SoLuong > 0)
            {
                Console.WriteLine($"\nThông tin nhân viên đầu tiên (pb[0]):\n{pb[0]}");
            }

            Console.ReadLine();
        }
    }
}