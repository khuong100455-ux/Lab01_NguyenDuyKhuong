﻿using System;
using System.Collections.Generic;

namespace Bai2_2
{
    // Lớp Person (từ Bài 1.3)
    class Person
    {
        private int id;
        private string name;
        private int yob;   // năm sinh
        private int yod;   // năm mất (0 nếu còn sống)

        public Person()
        {
            id = 0;
            name = "";
            yob = 0;
            yod = 0;
        }

        public Person(int id, string name, int yob, int yod)
        {
            this.id = id;
            this.name = name;
            this.yob = yob;
            this.yod = yod;
        }

        public Person(Person p)
        {
            id = p.id;
            name = p.name;
            yob = p.yob;
            yod = p.yod;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Yob
        {
            get { return yob; }
            set { yob = value; }
        }

        public int Yod
        {
            get { return yod; }
            set { yod = value; }
        }

        public void Input()
        {
            do
            {
                Console.Write("  Nhập id: ");
            } while (!int.TryParse(Console.ReadLine(), out id));

            Console.Write("  Nhập họ tên: ");
            name = Console.ReadLine();

            do
            {
                Console.Write("  Nhập năm sinh: ");
            } while (!int.TryParse(Console.ReadLine(), out yob)
                     || yob <= 0 || yob > DateTime.Now.Year);

            do
            {
                Console.Write("  Nhập năm mất (nhập 0 nếu còn sống): ");
            } while (!int.TryParse(Console.ReadLine(), out yod)
                     || (yod != 0 && (yod < yob || yod > DateTime.Now.Year)));
        }

        public void Output()
        {
            Console.WriteLine("  ID: " + id);
            Console.WriteLine("  Họ tên: " + name);
            Console.WriteLine("  Năm sinh: " + yob);
            Console.WriteLine("  Năm mất: " + (IsLiving() ? "Còn sống" : yod.ToString()));
        }

        public bool IsLiving()
        {
            return yod == 0;
        }
    }

    class PersonList
    {
        // Field: danh sách các Person
        private List<Person> ds;

        // Constructor mặc định
        public PersonList()
        {
            ds = new List<Person>();
        }

        // Constructor sao chép (sao chép sâu)
        public PersonList(PersonList other)
        {
            ds = new List<Person>();
            foreach (Person p in other.ds)
                ds.Add(new Person(p));
        }

        // Số người trong danh sách
        public int Count
        {
            get { return ds.Count; }
        }

        // Thêm một Person vào danh sách
        public void Add(Person x)
        {
            if (x == null)
                throw new ArgumentNullException("x", "Không thể thêm đối tượng null");
            ds.Add(x);
        }

        // Nhập danh sách
        public void Input()
        {
            int n;
            do
            {
                Console.Write("Nhập số người: ");
            } while (!int.TryParse(Console.ReadLine(), out n) || n < 0);

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Nhập người thứ " + (i + 1) + ":");
                Person p = new Person();
                p.Input();
                Add(p);
            }
        }

        // Xuất danh sách
        public void Output()
        {
            if (ds.Count == 0)
            {
                Console.WriteLine("Danh sách rỗng");
                return;
            }

            for (int i = 0; i < ds.Count; i++)
            {
                Console.WriteLine("Người thứ " + (i + 1) + ":");
                ds[i].Output();
            }
        }

        // Trả về danh sách những người còn sống
        public PersonList LivingPeople()
        {
            PersonList kq = new PersonList();
            foreach (Person p in ds)
            {
                if (p.IsLiving())
                    kq.Add(new Person(p));
            }
            return kq;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            PersonList danhSach = new PersonList();
            danhSach.Input();

            // Thêm trực tiếp một người bằng Add
            danhSach.Add(new Person(99, "Trần Thị B", 1990, 0));

            Console.WriteLine("\n===== DANH SÁCH NHÂN KHẨU =====");
            danhSach.Output();

            PersonList conSong = danhSach.LivingPeople();
            Console.WriteLine("\n===== NHỮNG NGƯỜI CÒN SỐNG (" + conSong.Count + " người) =====");
            conSong.Output();

            Console.ReadKey();
        }
    }
}