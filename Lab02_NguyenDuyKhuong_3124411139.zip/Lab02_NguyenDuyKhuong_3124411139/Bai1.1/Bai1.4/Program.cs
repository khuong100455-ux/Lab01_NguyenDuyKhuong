﻿using System;

namespace Bai1_4
{
    class PhanSo
    {
        // Field
        private int tu;
        private int mau;

        // Constructor mặc nhiên: 0/1
        public PhanSo()
        {
            tu = 0;
            mau = 1;
        }

        // Constructor có 2 tham số: tử, mẫu
        public PhanSo(int tu, int mau)
        {
            if (mau == 0)
                throw new ArgumentException("Mẫu số phải khác 0");
            this.tu = tu;
            this.mau = mau;
            ChuanHoa();
        }

        // Constructor có 1 tham số: số nguyên n -> n/1
        public PhanSo(int tu) : this(tu, 1)
        {
        }

        // Constructor sao chép
        public PhanSo(PhanSo p)
        {
            tu = p.tu;
            mau = p.mau;
        }

        // Property
        public int TuSo
        {
            get { return tu; }
            set
            {
                tu = value;
                ChuanHoa();
            }
        }

        public int MauSo
        {
            get { return mau; }
            set
            {
                if (value == 0)
                    throw new ArgumentException("Mẫu số phải khác 0");
                mau = value;
                ChuanHoa();
            }
        }

        // Ước chung lớn nhất (thuật toán Euclid)
        private static int UCLN(int a, int b)
        {
            while (b != 0)
            {
                int r = a % b;
                a = b;
                b = r;
            }
            return a;
        }

        // Rút gọn và đưa dấu âm lên tử
        private void ChuanHoa()
        {
            if (mau < 0)
            {
                tu = -tu;
                mau = -mau;
            }
            int u = UCLN(Math.Abs(tu), mau);
            tu /= u;
            mau /= u;
        }

        // Override ToString
        public override string ToString()
        {
            if (mau == 1)
                return tu.ToString();
            return tu + "/" + mau;
        }

        // Toán tử một ngôi
        public static PhanSo operator +(PhanSo a)
        {
            return new PhanSo(a.tu, a.mau);
        }

        public static PhanSo operator -(PhanSo a)
        {
            return new PhanSo(-a.tu, a.mau);
        }

        // Toán tử hai ngôi
        public static PhanSo operator +(PhanSo a, PhanSo b)
        {
            return new PhanSo(a.tu * b.mau + b.tu * a.mau, a.mau * b.mau);
        }

        public static PhanSo operator -(PhanSo a, PhanSo b)
        {
            return new PhanSo(a.tu * b.mau - b.tu * a.mau, a.mau * b.mau);
        }

        public static PhanSo operator *(PhanSo a, PhanSo b)
        {
            return new PhanSo(a.tu * b.tu, a.mau * b.mau);
        }

        public static PhanSo operator /(PhanSo a, PhanSo b)
        {
            if (b.tu == 0)
                throw new DivideByZeroException("Không thể chia cho phân số bằng 0");
            return new PhanSo(a.tu * b.mau, a.mau * b.tu);
        }

        // Toán tử so sánh
        public static bool operator >(PhanSo a, PhanSo b)
        {
            return (long)a.tu * b.mau > (long)b.tu * a.mau;
        }

        public static bool operator <(PhanSo a, PhanSo b)
        {
            return (long)a.tu * b.mau < (long)b.tu * a.mau;
        }

        public static bool operator >=(PhanSo a, PhanSo b)
        {
            return (long)a.tu * b.mau >= (long)b.tu * a.mau;
        }

        public static bool operator <=(PhanSo a, PhanSo b)
        {
            return (long)a.tu * b.mau <= (long)b.tu * a.mau;
        }

        public static bool operator ==(PhanSo a, PhanSo b)
        {
            if (ReferenceEquals(a, b)) return true;
            if (ReferenceEquals(a, null) || ReferenceEquals(b, null)) return false;
            return a.tu == b.tu && a.mau == b.mau;
        }

        public static bool operator !=(PhanSo a, PhanSo b)
        {
            return !(a == b);
        }

        // Đi kèm khi đa năng == và !=
        public override bool Equals(object obj)
        {
            return this == (obj as PhanSo);
        }

        public override int GetHashCode()
        {
            return tu.GetHashCode() ^ mau.GetHashCode();
        }
    }

    class Program
    {
        static PhanSo Nhap(string ten)
        {
            int tu, mau;
            do
            {
                Console.Write("Nhập tử số của " + ten + ": ");
            } while (!int.TryParse(Console.ReadLine(), out tu));

            do
            {
                Console.Write("Nhập mẫu số của " + ten + " (khác 0): ");
            } while (!int.TryParse(Console.ReadLine(), out mau) || mau == 0);

            return new PhanSo(tu, mau);
        }

        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            PhanSo a = Nhap("phân số a");
            PhanSo b = Nhap("phân số b");

            Console.WriteLine("\na = " + a);
            Console.WriteLine("b = " + b);

            Console.WriteLine("\n+a = " + (+a));
            Console.WriteLine("-a = " + (-a));

            Console.WriteLine("\na + b = " + (a + b));
            Console.WriteLine("a - b = " + (a - b));
            Console.WriteLine("a * b = " + (a * b));
            try
            {
                Console.WriteLine("a / b = " + (a / b));
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("a / b: " + ex.Message);
            }

            Console.WriteLine("\na >  b : " + (a > b));
            Console.WriteLine("a <  b : " + (a < b));
            Console.WriteLine("a >= b : " + (a >= b));
            Console.WriteLine("a <= b : " + (a <= b));
            Console.WriteLine("a == b : " + (a == b));
            Console.WriteLine("a != b : " + (a != b));

            Console.ReadKey();
        }
    }
}