﻿using System;

namespace Bai1_3
{
    class Person
    {
        // Field
        private int id;
        private string name;
        private int yob;   // năm sinh
        private int yod;   // năm mất (0 nếu còn sống)

        // Constructor mặc định
        public Person()
        {
            id = 0;
            name = "";
            yob = 0;
            yod = 0;
        }

        // Constructor có tham số
        public Person(int id, string name, int yob, int yod)
        {
            this.id = id;
            this.name = name;
            this.yob = yob;
            this.yod = yod;
        }

        // Constructor sao chép
        public Person(Person p)
        {
            id = p.id;
            name = p.name;
            yob = p.yob;
            yod = p.yod;
        }

        // Property
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Yob
        {
            get { return yob; }
            set { yob = value; }
        }

        public int Yod
        {
            get { return yod; }
            set { yod = value; }
        }

        // Nhập dữ liệu
        public void Input()
        {
            do
            {
                Console.Write("Nhập id: ");
            } while (!int.TryParse(Console.ReadLine(), out id));

            Console.Write("Nhập họ tên: ");
            name = Console.ReadLine();

            do
            {
                Console.Write("Nhập năm sinh: ");
            } while (!int.TryParse(Console.ReadLine(), out yob)
                     || yob <= 0 || yob > DateTime.Now.Year);

            do
            {
                Console.Write("Nhập năm mất (nhập 0 nếu còn sống): ");
            } while (!int.TryParse(Console.ReadLine(), out yod)
                     || (yod != 0 && (yod < yob || yod > DateTime.Now.Year)));
        }

        // Xuất dữ liệu
        public void Output()
        {
            Console.WriteLine("ID: " + id);
            Console.WriteLine("Họ tên: " + name);
            Console.WriteLine("Năm sinh: " + yob);
            Console.WriteLine("Năm mất: " + (IsLiving() ? "Còn sống" : yod.ToString()));
        }

        // Kiểm tra còn sống hay không
        public bool IsLiving()
        {
            return yod == 0;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            Person p1 = new Person();
            Console.WriteLine("Nhập thông tin người thứ nhất:");
            p1.Input();

            Console.WriteLine("\nThông tin người thứ nhất:");
            p1.Output();

            // Dùng copy constructor
            Person p2 = new Person(p1);
            Console.WriteLine("\nBản sao (p2) của người thứ nhất:");
            p2.Output();

            if (p1.IsLiving())
                Console.WriteLine("\n" + p1.Name + " vẫn còn sống.");
            else
                Console.WriteLine("\n" + p1.Name + " đã mất.");

            Console.ReadKey();
        }
    }
}
