﻿using System;

namespace BaiTapSapXepDelegate
{
    public class QuanLySapXep
    {
        // =========================================================================
        // a. KHAI BÁO DELEGATE SO SÁNH TỔNG QUÁT (GENERIC DELEGATE)
        // =========================================================================

        /// <summary>
        /// Delegate nhận vào 2 đối tượng kiểu T, trả về:
        ///  > 0 nếu x > y
        ///  = 0 nếu x == y
        ///  < 0 nếu x < y
        /// </summary>
        public delegate int SoSanhDelegate<T>(T x, T y);

        // =========================================================================
        // b. PHƯƠNG THỨC SẮP XẾP TỔNG QUÁT SỬ DỤNG DELEGATE
        // =========================================================================

        /// <summary>
        /// Phương thức sắp xếp tổng quát (Generic) nhận vào một mảng và 1 delegate so sánh
        /// </summary>
        public static void SapXepTongQuat<T>(T[] arr, SoSanhDelegate<T> soSanh)
        {
            if (arr == null || arr.Length <= 1 || soSanh == null) return;

            int n = arr.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    // Ủy quyền việc so sánh cho Delegate
                    if (soSanh(arr[i], arr[j]) > 0)
                    {
                        T temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
        }

        // =========================================================================
        // c. STRUCT SẢN PHẨM VÀ CÁC PHƯƠNG THỨC SO SÁNH TỰ ĐỊNH NGHĨA
        // =========================================================================

        public struct SanPham
        {
            public string TenSP;
            public double GiaBan;

            public SanPham(string tenSP, double giaBan)
            {
                TenSP = tenSP;
                GiaBan = giaBan;
            }

            public override string ToString()
            {
                return $"Tên SP: {TenSP,-15} | Giá bán: {GiaBan,12:N0} VNĐ";
            }
        }

        // Phương thức so sánh Sản phẩm theo Giá bán (Tăng dần)
        public static int SoSanhTheoGiaTangDan(SanPham sp1, SanPham sp2)
        {
            return sp1.GiaBan.CompareTo(sp2.GiaBan);
        }

        // Phương thức so sánh Sản phẩm theo Tên (Alphabet)
        public static int SoSanhTheoTen(SanPham sp1, SanPham sp2)
        {
            return string.Compare(sp1.TenSP, sp2.TenSP, StringComparison.OrdinalIgnoreCase);
        }

        // =========================================================================
        // d. PHƯƠNG THỨC NHẬP / XUẤT DỮ LIỆU TỪ BÀN PHÍM
        // =========================================================================

        public static int[] NhapMangSoNguyen()
        {
            Console.Write("Nhập số lượng phần tử số nguyên (n): ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Số lượng phải > 0. Nhập lại n: ");
            }

            int[] arr = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write($"  Nhập phần tử thứ [{i}]: ");
                while (!int.TryParse(Console.ReadLine(), out arr[i]))
                {
                    Console.Write($"  Giá trị không hợp lệ. Nhập lại [{i}]: ");
                }
            }
            return arr;
        }

        public static SanPham[] NhapMangSanPham()
        {
            Console.Write("Nhập số lượng sản phẩm (n): ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Số lượng phải > 0. Nhập lại n: ");
            }

            SanPham[] arr = new SanPham[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\n[Sản phẩm thứ {i + 1}]");
                Console.Write("  Nhập tên sản phẩm: ");
                string ten = Console.ReadLine();

                Console.Write("  Nhập giá bán: ");
                double gia;
                while (!double.TryParse(Console.ReadLine(), out gia) || gia < 0)
                {
                    Console.Write("  Giá bán không hợp lệ. Nhập lại: ");
                }

                arr[i] = new SanPham(ten, gia);
            }
            return arr;
        }

        public static void XuatMang<T>(T[] arr)
        {
            if (arr == null || arr.Length == 0)
            {
                Console.WriteLine("Mảng rỗng.");
                return;
            }

            foreach (T item in arr)
            {
                Console.WriteLine(item);
            }
        }
    }

    // =========================================================================
    // CHƯƠNG TRÌNH CHÍNH (MAIN TRẠY ĐỘC LẬP BÀI 3.3)
    // =========================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== BÀI TẬP 3.3: SẮP XẾP MẢNG TỔNG QUÁT BẰNG DELEGATE ===");

            // ---------------------------------------------------------------------
            // 1. Thử nghiệm với Mảng Số Nguyên (Dùng Lambda Expression / Anonymous Function)
            // ---------------------------------------------------------------------
            Console.WriteLine("\n--- 1. TỰ SẮP XẾP MẢNG SỐ NGUYÊN ---");
            int[] mangSo = QuanLySapXep.NhapMangSoNguyen();

            // Truyền Delegate dạng Lambda Expression (x, y) => x.CompareTo(y)
            QuanLySapXep.SapXepTongQuat(mangSo, (x, y) => x.CompareTo(y));
            Console.WriteLine("--> Mảng số nguyên sau khi sắp xếp tăng dần:");
            Console.WriteLine(string.Join(", ", mangSo));

            // ---------------------------------------------------------------------
            // 2. Thử nghiệm với Mảng Đối Tượng Sản Phẩm (Dùng Phương thức ủy quyền)
            // ---------------------------------------------------------------------
            Console.WriteLine("\n--- 2. TỰ SẮP XẾP MẢNG ĐỐI TƯỢNG SẢN PHẨM ---");
            QuanLySapXep.SanPham[] dsSanPham = QuanLySapXep.NhapMangSanPham();

            // A. Sắp xếp theo Giá bán bằng cách truyền tên phương thức so sánh
            QuanLySapXep.SoSanhDelegate<QuanLySapXep.SanPham> delegateGia = QuanLySapXep.SoSanhTheoGiaTangDan;
            QuanLySapXep.SapXepTongQuat(dsSanPham, delegateGia);
            Console.WriteLine("\n--> Danh sách sản phẩm sau khi sắp xếp theo GIÁ BÁN TĂNG DẦN:");
            QuanLySapXep.XuatMang(dsSanPham);

            // B. Sắp xếp theo Tên bằng cách truyền tên phương thức so sánh khác
            QuanLySapXep.SapXepTongQuat(dsSanPham, QuanLySapXep.SoSanhTheoTen);
            Console.WriteLine("\n--> Danh sách sản phẩm sau khi sắp xếp theo TÊN (ALPHABET):");
            QuanLySapXep.XuatMang(dsSanPham);

            Console.ReadLine();
        }
    }
}