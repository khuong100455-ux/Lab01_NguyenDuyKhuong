﻿using System;
using System.Collections.Generic;

namespace BaiTapTinhLuongDaHinh
{
    public class QuanLyNhanSu
    {
        // =========================================================================
        // 1. LỚP TRỪU TƯỢNG BASE (NhanVien) - ÁP DỤNG KẾ THỪA VÀ ĐA HÌNH
        // =========================================================================
        public abstract class NhanVien
        {
            public string MaNV { get; set; }
            public string HoTen { get; set; }

            public NhanVien() { }

            public NhanVien(string maNV, string hoTen)
            {
                MaNV = maNV;
                HoTen = hoTen;
            }

            // Phương thức ảo/trừu tượng để tính lương (Tính đa hình)
            public abstract double TinhLuong();

            // Phương thức nhập thông tin cơ bản
            public virtual void Nhap()
            {
                Console.Write("  Nhập mã nhân viên: ");
                MaNV = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(MaNV))
                {
                    Console.Write("  Mã NV không được để trống. Nhập lại: ");
                    MaNV = Console.ReadLine();
                }

                Console.Write("  Nhập họ tên: ");
                HoTen = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(HoTen))
                {
                    Console.Write("  Họ tên không được để trống. Nhập lại: ");
                    HoTen = Console.ReadLine();
                }
            }

            public override string ToString()
            {
                return $"Mã NV: {MaNV,-8} | Họ tên: {HoTen,-20}";
            }
        }

        // =========================================================================
        // 2. LỚP CON 1: NhanVienKinhDoanh (KẾ THỪA TỪ NhanVien)
        // =========================================================================
        public class NhanVienKinhDoanh : NhanVien
        {
            public double LuongCoBan { get; set; }
            public int SoHopDong { get; set; }

            public NhanVienKinhDoanh() : base() { }

            public NhanVienKinhDoanh(string maNV, string hoTen, double luongCoBan, int soHopDong)
                : base(maNV, hoTen)
            {
                LuongCoBan = luongCoBan;
                SoHopDong = soHopDong;
            }

            // Ghi đè phương thức TinhLuong()
            // Công thức: Lương cơ bản + (Số hợp đồng * 500.000)
            public override double TinhLuong()
            {
                return LuongCoBan + (SoHopDong * 500000.0);
            }

            public override void Nhap()
            {
                base.Nhap();

                Console.Write("  Nhập lương cơ bản (VNĐ): ");
                double lcb;
                while (!double.TryParse(Console.ReadLine(), out lcb) || lcb < 0)
                {
                    Console.Write("  Lương cơ bản không hợp lệ. Nhập lại: ");
                }
                LuongCoBan = lcb;

                Console.Write("  Nhập số hợp đồng đã ký kết: ");
                int shd;
                while (!int.TryParse(Console.ReadLine(), out shd) || shd < 0)
                {
                    Console.Write("  Số hợp đồng không hợp lệ. Nhập lại: ");
                }
                SoHopDong = shd;
            }

            public override string ToString()
            {
                return $"{base.ToString()} | Loại: Kinh doanh | Lương CB: {LuongCoBan,10:N0} VNĐ | Số HĐ: {SoHopDong,2} | Thực lĩnh: {TinhLuong(),12:N0} VNĐ";
            }
        }

        // =========================================================================
        // 3. LỚP CON 2: NhanVienSanXuat (KẾ THỪA TỪ NhanVien)
        // =========================================================================
        public class NhanVienSanXuat : NhanVien
        {
            public int SoSanPham { get; set; }

            public NhanVienSanXuat() : base() { }

            public NhanVienSanXuat(string maNV, string hoTen, int soSanPham)
                : base(maNV, hoTen)
            {
                SoSanPham = soSanPham;
            }

            // Ghi đè phương thức TinhLuong()
            // Công thức: Số SP * 1000. Nếu > 3000 SP thì thưởng thêm 5%
            public override double TinhLuong()
            {
                double luong = SoSanPham * 1000.0;
                if (SoSanPham > 3000)
                {
                    luong += luong * 0.05; // Thưởng thêm 5%
                }
                return luong;
            }

            public override void Nhap()
            {
                base.Nhap();

                Console.Write("  Nhập số lượng sản phẩm: ");
                int ssp;
                while (!int.TryParse(Console.ReadLine(), out ssp) || ssp < 0)
                {
                    Console.Write("  Số sản phẩm không hợp lệ. Nhập lại: ");
                }
                SoSanPham = ssp;
            }

            public override string ToString()
            {
                return $"{base.ToString()} | Loại: Sản xuất  | Số SP: {SoSanPham,6:N0}         | Thực lĩnh: {TinhLuong(),12:N0} VNĐ";
            }
        }

        // =========================================================================
        // 4. CÁC PHƯƠNG THỨC QUẢN LÝ DANH SÁCH NHÂN VIÊN
        // =========================================================================
        private List<NhanVien> dsNhanVien = new List<NhanVien>();

        public void NhapDanhSach()
        {
            Console.Write("Nhập số lượng nhân viên toàn công ty (n): ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Số lượng phải là số nguyên dương. Nhập lại n: ");
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\n[Nhân viên thứ {i + 1}]");
                Console.WriteLine("  Chọn loại nhân viên: 1 - Kinh doanh | 2 - Sản xuất");
                Console.Write("  Lựa chọn (1 hoặc 2): ");
                string loai = Console.ReadLine();

                NhanVien nv;
                if (loai == "2")
                {
                    nv = new NhanVienSanXuat();
                }
                else
                {
                    nv = new NhanVienKinhDoanh(); // Mặc định là Kinh doanh
                }

                nv.Nhap();
                dsNhanVien.Add(nv);
            }
        }

        public void XuatDanhSach()
        {
            if (dsNhanVien.Count == 0)
            {
                Console.WriteLine("Danh sách nhân viên rỗng.");
                return;
            }

            Console.WriteLine("\n=============================== DANH SÁCH BẢNG LƯƠNG NHÂN VIÊN ===============================");
            for (int i = 0; i < dsNhanVien.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {dsNhanVien[i]}");
            }
        }

        public double TinhTongLuongCongTy()
        {
            double tong = 0;
            foreach (NhanVien nv in dsNhanVien)
            {
                // Nhờ tính Đa hình (Polymorphism), phương thức TinhLuong() đúng của từng lớp con sẽ được gọi
                tong += nv.TinhLuong();
            }
            return tong;
        }
    }

    // =========================================================================
    // CHƯƠNG TRÌNH CHÍNH (MAIN TRẠY ĐỘC LẬP BÀI 3.5)
    // =========================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== BÀI TẬP 3.5: TÍNH LƯƠNG NHÂN VIÊN (KẾ THỪA & ĐA HÌNH) ===");

            QuanLyNhanSu qlns = new QuanLyNhanSu();

            // 1. Nhập danh sách nhân viên
            qlns.NhapDanhSach();

            // 2. Xuất chi tiết lương từng nhân viên
            qlns.XuatDanhSach();

            // 3. Tính tổng lương công ty phải trả
            double tongLuong = qlns.TinhTongLuongCongTy();
            Console.WriteLine("==============================================================================================");
            Console.WriteLine($"--> TỔNG TỔNG QUỸ LƯƠNG CÔNG TY X PHẢI TRẢ: {tongLuong:N0} VNĐ");
            Console.WriteLine("==============================================================================================");

            Console.ReadLine();
        }
    }
}
