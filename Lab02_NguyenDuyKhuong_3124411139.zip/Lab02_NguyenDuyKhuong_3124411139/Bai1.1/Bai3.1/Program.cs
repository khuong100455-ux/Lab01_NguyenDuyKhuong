﻿using System;

namespace BaiTapSapXep
{
    public class QuanLySinhVien
    {
        // Struct SinhVien khai báo nội bộ, thực thi interface IComparable<SinhVien>
        public struct SinhVien : IComparable<SinhVien>
        {
            public string HoTen;
            public double DiemTB;

            public SinhVien(string hoTen, double diemTB)
            {
                HoTen = hoTen;
                DiemTB = diemTB;
            }

            // Thực thi phương thức CompareTo để Array.Sort biết cách so sánh 2 đối tượng
            public int CompareTo(SinhVien other)
            {
                // Sắp xếp theo Điểm trung bình tăng dần
                return this.DiemTB.CompareTo(other.DiemTB);

                // Nếu muốn sắp xếp giảm dần, có thể đổi lại thành:
                // return other.DiemTB.CompareTo(this.DiemTB);
            }

            public override string ToString()
            {
                return $"Họ tên: {HoTen,-20} | Điểm TB: {DiemTB,5:F2}";
            }
        }

        // Mảng private chứa danh sách sinh viên
        private SinhVien[] dsSinhVien;

        // Thuộc tính lấy số lượng sinh viên
        public int SoLuong
        {
            get { return dsSinhVien != null ? dsSinhVien.Length : 0; }
        }

        // =========================================================================
        // a. CÁC LOẠI CONSTRUCTOR
        // =========================================================================

        // 1. Constructor mặc định
        public QuanLySinhVien()
        {
            dsSinhVien = new SinhVien[0];
        }

        // 2. Constructor tạo danh sách có n sinh viên
        public QuanLySinhVien(int n)
        {
            if (n < 0) n = 0;
            dsSinhVien = new SinhVien[n];
        }

        // =========================================================================
        // b. INDEXER TRUY CẬP SINH VIÊN THỨ I
        // =========================================================================

        public SinhVien this[int index]
        {
            get
            {
                if (index < 0 || index >= SoLuong)
                {
                    throw new IndexOutOfRangeException("Chỉ số vượt quá số lượng sinh viên.");
                }
                return dsSinhVien[index];
            }
            set
            {
                if (index < 0 || index >= SoLuong)
                {
                    throw new IndexOutOfRangeException("Chỉ số vượt quá số lượng sinh viên.");
                }
                dsSinhVien[index] = value;
            }
        }

        // =========================================================================
        // c. NHẬP / XUẤT DANH SÁCH SINH VIÊN
        // =========================================================================

        public void Nhap()
        {
            int n;
            Console.Write("Nhập số lượng sinh viên (n): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Số lượng phải là số nguyên dương. Nhập lại n: ");
            }

            dsSinhVien = new SinhVien[n];

            Console.WriteLine($"\n--- NHẬP THÔNG TIN {n} SINH VIÊN ---");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\n[Sinh viên thứ {i + 1}]");

                Console.Write("  Nhập họ tên: ");
                string hoTen = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(hoTen))
                {
                    Console.Write("  Họ tên không được để trống. Nhập lại: ");
                    hoTen = Console.ReadLine();
                }

                Console.Write("  Nhập điểm trung bình (0 - 10): ");
                double diemTB;
                while (!double.TryParse(Console.ReadLine(), out diemTB) || diemTB < 0 || diemTB > 10)
                {
                    Console.Write("  Điểm không hợp lệ (0 đến 10). Nhập lại điểm TB: ");
                }

                dsSinhVien[i] = new SinhVien(hoTen, diemTB);
            }
        }

        public void Xuat()
        {
            if (dsSinhVien == null || SoLuong == 0)
            {
                Console.WriteLine("Danh sách sinh viên rỗng.");
                return;
            }

            for (int i = 0; i < SoLuong; i++)
            {
                Console.WriteLine($"{i + 1}. {dsSinhVien[i]}");
            }
        }

        // =========================================================================
        // d. SẮP XẾP SỬ DỤNG HÀM TĨNH Array.Sort(...)
        // =========================================================================

        public void SapXep()
        {
            if (dsSinhVien != null && dsSinhVien.Length > 0)
            {
                // Hàm tĩnh Array.Sort sẽ tự động gọi phương thức CompareTo() của struct SinhVien
                Array.Sort(dsSinhVien);
            }
        }
    }

    // =========================================================================
    // CHƯƠNG TRÌNH CHÍNH (MAIN TRẠY ĐỘC LẬP BÀI 3.1)
    // =========================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== BÀI TẬP 3.1: SẮP XẾP ĐỐI TƯỢNG BẰNG Array.Sort(...) ===");

            // Khởi tạo đối tượng Quản lý sinh viên
            QuanLySinhVien qlsv = new QuanLySinhVien();

            // 1. Nhập thông tin danh sách sinh viên
            qlsv.Nhap();

            // 2. Xuất danh sách trước khi sắp xếp
            Console.WriteLine("\n--- DANH SÁCH BAN ĐẦU ---");
            qlsv.Xuat();

            // 3. Thực hiện sắp xếp bằng phương thức tĩnh Array.Sort(...)
            qlsv.SapXep();

            // 4. Xuất danh sách sau khi sắp xếp
            Console.WriteLine("\n--- DANH SÁCH SAU KI SẮP XẾP THEO ĐIỂM TB (TĂNG DẦN) ---");
            qlsv.Xuat();

            Console.ReadLine();
        }
    }
}
