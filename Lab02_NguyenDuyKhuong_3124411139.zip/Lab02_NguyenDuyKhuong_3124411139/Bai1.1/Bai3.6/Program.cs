﻿using System;
using System.Collections.Generic;

namespace BaiTapTinhDiemThiSinh
{
    public class CuocThiTinHoc
    {
        // =========================================================================
        // 1. LỚP TRỪU TƯỢNG BASE (ThiSinh) - ÁP DỤNG KẾ THỪA VÀ ĐA HÌNH
        // =========================================================================
        public abstract class ThiSinh
        {
            public string SBD { get; set; }
            public string HoTen { get; set; }
            public double Bai1 { get; set; }
            public double Bai2 { get; set; }
            public double Bai3 { get; set; }

            public ThiSinh() { }

            public ThiSinh(string sbd, string hoTen, double bai1, double bai2, double bai3)
            {
                SBD = sbd;
                HoTen = hoTen;
                Bai1 = bai1;
                Bai2 = bai2;
                Bai3 = bai3;
            }

            // Phương thức trừu tượng tính tổng điểm (Tính đa hình)
            public abstract double TinhTongDiem();

            // Phương thức ảo nhập thông tin chung
            public virtual void Nhap()
            {
                Console.Write("  Nhập Số báo danh (SBD): ");
                SBD = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(SBD))
                {
                    Console.Write("  SBD không được để trống. Nhập lại: ");
                    SBD = Console.ReadLine();
                }

                Console.Write("  Nhập Họ tên: ");
                HoTen = Console.ReadLine();
                while (string.IsNullOrWhiteSpace(HoTen))
                {
                    Console.Write("  Họ tên không được để trống. Nhập lại: ");
                    HoTen = Console.ReadLine();
                }

                Bai1 = NhapDiem("  Nhập điểm Bài 1 (0-10): ");
                Bai2 = NhapDiem("  Nhập điểm Bài 2 (0-10): ");
                Bai3 = NhapDiem("  Nhập điểm Bài 3 (0-10): ");
            }

            // Hàm hỗ trợ kiểm tra tính hợp lệ của điểm nhập vào
            protected double NhapDiem(string thongBao)
            {
                double diem;
                Console.Write(thongBao);
                while (!double.TryParse(Console.ReadLine(), out diem) || diem < 0 || diem > 10)
                {
                    Console.Write("  Điểm không hợp lệ (phải từ 0 đến 10). Nhập lại: ");
                }
                return diem;
            }

            public override string ToString()
            {
                return $"SBD: {SBD,-8} | Họ tên: {HoTen,-18} | B1: {Bai1,4:F1} | B2: {Bai2,4:F1} | B3: {Bai3,4:F1}";
            }
        }

        // =========================================================================
        // 2. LỚP CON 1: ThiSinhChuyen (KẾ THỪA TỪ ThiSinh)
        // =========================================================================
        public class ThiSinhChuyen : ThiSinh
        {
            public double TiengAnh { get; set; }

            public ThiSinhChuyen() : base() { }

            public ThiSinhChuyen(string sbd, string hoTen, double bai1, double bai2, double bai3, double tiengAnh)
                : base(sbd, hoTen, bai1, bai2, bai3)
            {
                TiengAnh = tiengAnh;
            }

            // Ghi đè phương thức TinhTongDiem()
            // Công thức: Tổng 3 bài lập trình + Điểm thưởng tiếng Anh
            //  - 7 <= tiengAnh <= 8: cộng 1 điểm
            //  - 9 <= tiengAnh <= 10: cộng 2 điểm
            public override double TinhTongDiem()
            {
                double tongLapTrinh = Bai1 + Bai2 + Bai3;
                double diemThuong = 0;

                if (TiengAnh >= 9.0 && TiengAnh <= 10.0)
                {
                    diemThuong = 2.0;
                }
                else if (TiengAnh >= 7.0 && TiengAnh <= 8.0)
                {
                    diemThuong = 1.0;
                }

                return tongLapTrinh + diemThuong;
            }

            public override void Nhap()
            {
                base.Nhap();
                TiengAnh = NhapDiem("  Nhập điểm Tiếng Anh (0-10): ");
            }

            public override string ToString()
            {
                return $"{base.ToString()} | Tiếng Anh: {TiengAnh,4:F1} | Đối tượng: Chuyên   | TỔNG ĐIỂM: {TinhTongDiem(),5:F1}";
            }
        }

        // =========================================================================
        // 3. LỚP CON 2: ThiSinhSieuCup (KẾ THỪA TỪ ThiSinh)
        // =========================================================================
        public class ThiSinhSieuCup : ThiSinh
        {
            public double CSDL { get; set; }

            public ThiSinhSieuCup() : base() { }

            public ThiSinhSieuCup(string sbd, string hoTen, double bai1, double bai2, double bai3, double csdl)
                : base(sbd, hoTen, bai1, bai2, bai3)
            {
                CSDL = csdl;
            }

            // Ghi đè phương thức TinhTongDiem()
            // Công thức: Tổng cả 4 bài thi (Bài 1 + Bài 2 + Bài 3 + CSDL)
            public override double TinhTongDiem()
            {
                return Bai1 + Bai2 + Bai3 + CSDL;
            }

            public override void Nhap()
            {
                base.Nhap();
                CSDL = NhapDiem("  Nhập điểm Cơ sở dữ liệu (0-10): ");
            }

            public override string ToString()
            {
                return $"{base.ToString()} | Điểm CSDL : {CSDL,4:F1} | Đối tượng: Siêu cúp | TỔNG ĐIỂM: {TinhTongDiem(),5:F1}";
            }
        }

        // =========================================================================
        // 4. PHƯƠNG THỨC QUẢN LÝ DANH SÁCH THÍ SINH
        // =========================================================================
        private List<ThiSinh> dsThiSinh = new List<ThiSinh>();

        public void NhapDanhSach()
        {
            Console.Write("Nhập số lượng thí sinh tham gia cuộc thi (n): ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Số lượng phải là số nguyên dương. Nhập lại n: ");
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\n[Thí sinh thứ {i + 1}]");
                Console.WriteLine("  Chọn loại thí sinh: 1 - Chuyên | 2 - Siêu cúp");
                Console.Write("  Lựa chọn (1 hoặc 2): ");
                string loai = Console.ReadLine();

                ThiSinh ts;
                if (loai == "2")
                {
                    ts = new ThiSinhSieuCup();
                }
                else
                {
                    ts = new ThiSinhChuyen(); // Mặc định là Chuyên
                }

                ts.Nhap();
                dsThiSinh.Add(ts);
            }
        }

        public void XuatDanhSach()
        {
            if (dsThiSinh.Count == 0)
            {
                Console.WriteLine("Danh sách thí sinh rỗng.");
                return;
            }

            Console.WriteLine("\n=================================== KẾT QUẢ THI TÍN HỌC ===================================");
            for (int i = 0; i < dsThiSinh.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {dsThiSinh[i]}");
            }
            Console.WriteLine("===========================================================================================");
        }
    }

    // =========================================================================
    // CHƯƠNG TRÌNH CHÍNH (MAIN TRẠY ĐỘC LẬP BÀI 3.6)
    // =========================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== BÀI TẬP 3.6: TÍNH ĐIỂM THÍ SINH CUỘC THI TIN HỌC ===");

            CuocThiTinHoc cuộcThi = new CuocThiTinHoc();

            // 1. Nhập thông tin danh sách thí sinh
            cuộcThi.NhapDanhSach();

            // 2. Xuất bảng điểm tổng hợp của từng thí sinh
            cuộcThi.XuatDanhSach();

            Console.ReadLine();
        }
    }
}