﻿using System;

namespace Bai1_1
{
    class SinhVien
    {
        // Field
        private string hoTen;
        private int namSinh;

        // Constructor mặc định
        public SinhVien()
        {
            hoTen = "";
            namSinh = DateTime.Now.Year;
        }

        // Constructor có tham số
        public SinhVien(string hoTen, int namSinh)
        {
            this.hoTen = hoTen;
            this.namSinh = namSinh;
        }

        // Constructor sao chép
        public SinhVien(SinhVien sv)
        {
            hoTen = sv.hoTen;
            namSinh = sv.namSinh;
        }

        // Property
        public string HoTen
        {
            get { return hoTen; }
            set { hoTen = value; }
        }

        public int NamSinh
        {
            get { return namSinh; }
            set
            {
                if (value > 0 && value <= DateTime.Now.Year)
                    namSinh = value;
            }
        }

        // Method
        public void Nhap()
        {
            Console.Write("Nhập họ tên: ");
            HoTen = Console.ReadLine();

            int nam;
            do
            {
                Console.Write("Nhập năm sinh: ");
            } while (!int.TryParse(Console.ReadLine(), out nam)
                     || nam <= 0 || nam > DateTime.Now.Year);
            NamSinh = nam;
        }

        public int TinhTuoi()
        {
            return DateTime.Now.Year - namSinh;
        }

        public void Xuat()
        {
            Console.WriteLine("Họ tên: " + hoTen);
            Console.WriteLine("Năm sinh: " + namSinh);
            Console.WriteLine("Tuổi: " + TinhTuoi());
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            SinhVien sv = new SinhVien();
            sv.Nhap();
            Console.WriteLine();
            sv.Xuat();

            Console.ReadKey();
        }
    }
}