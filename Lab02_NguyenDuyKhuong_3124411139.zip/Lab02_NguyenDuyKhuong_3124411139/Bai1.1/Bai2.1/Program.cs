﻿using System;
using System.Collections;

namespace Bai2_1
{
    // Lớp Point (rút gọn từ Bài 1.2)
    class Point
    {
        private double x;
        private double y;

        public Point()
        {
            x = 0;
            y = 0;
        }

        public Point(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public Point(Point p)
        {
            x = p.x;
            y = p.y;
        }

        public double X
        {
            get { return x; }
            set { x = value; }
        }

        public double Y
        {
            get { return y; }
            set { y = value; }
        }

        public void Input()
        {
            do
            {
                Console.Write("  Nhập x: ");
            } while (!double.TryParse(Console.ReadLine(), out x));

            do
            {
                Console.Write("  Nhập y: ");
            } while (!double.TryParse(Console.ReadLine(), out y));
        }

        public override string ToString()
        {
            return "(" + x + ", " + y + ")";
        }
    }

    class ArrayPoint
    {
        // Field: ArrayList chứa các Point
        private ArrayList ds;

        // Constructor mặc định
        public ArrayPoint()
        {
            ds = new ArrayList();
        }

        // Constructor sao chép (sao chép sâu)
        public ArrayPoint(ArrayPoint other)
        {
            ds = new ArrayList();
            foreach (Point p in other.ds)
                ds.Add(new Point(p));
        }

        // Số lượng điểm
        public int Count
        {
            get { return ds.Count; }
        }

        // Thêm một điểm vào cuối danh sách
        public void Add(Point p)
        {
            ds.Add(p);
        }

        // Indexer: truy cập Point thứ i
        public Point this[int i]
        {
            get
            {
                if (i < 0 || i >= ds.Count)
                    throw new IndexOutOfRangeException("Chỉ số " + i + " nằm ngoài danh sách");
                return (Point)ds[i];
            }
            set
            {
                if (i < 0 || i >= ds.Count)
                    throw new IndexOutOfRangeException("Chỉ số " + i + " nằm ngoài danh sách");
                ds[i] = value;
            }
        }

        // Nhập danh sách điểm
        public void Input()
        {
            int n;
            do
            {
                Console.Write("Nhập số lượng điểm: ");
            } while (!int.TryParse(Console.ReadLine(), out n) || n < 0);

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Nhập điểm thứ " + i + ":");
                Point p = new Point();
                p.Input();
                ds.Add(p);
            }
        }

        // Xuất danh sách điểm
        public void Output()
        {
            if (ds.Count == 0)
            {
                Console.WriteLine("Danh sách rỗng");
                return;
            }
            for (int i = 0; i < ds.Count; i++)
                Console.WriteLine("Điểm thứ " + i + ": " + this[i]);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            ArrayPoint ap = new ArrayPoint();
            ap.Input();

            Console.WriteLine("\nDanh sách điểm vừa nhập:");
            ap.Output();

            if (ap.Count > 0)
            {
                // Dùng indexer để đọc
                Console.WriteLine("\nĐiểm đầu tiên ap[0] = " + ap[0]);
                Console.WriteLine("Điểm cuối cùng ap[" + (ap.Count - 1) + "] = " + ap[ap.Count - 1]);

                // Dùng indexer để ghi
                ap[0] = new Point(9, 9);
                Console.WriteLine("\nSau khi gán ap[0] = (9, 9):");
                ap.Output();
            }

            // Truy cập chỉ số sai
            try
            {
                Console.WriteLine(ap[100]);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("\nLỗi: " + ex.Message);
            }

            Console.ReadKey();
        }
    }
}