﻿using System;
using System.Collections.Generic;

namespace ThietKeLopNangCao
{
    public class DaySo
    {
        // Trường private lưu trữ mảng 1 chiều các số nguyên
        private int[] data;

        // Thuộc tính kiểm tra số lượng phần tử hiện tại
        public int SoPhanTu
        {
            get { return data != null ? data.Length : 0; }
        }

        // =========================================================================
        // a. CÁC LOẠI CONSTRUCTOR
        // =========================================================================

        // 1. Constructor không tham số (mặc định)
        public DaySo()
        {
            data = new int[0];
        }

        // 2. Constructor có tham số kích thước n
        public DaySo(int n)
        {
            if (n < 0) n = 0;
            data = new int[n];
        }

        // 3. Constructor sao chép từ một mảng có sẵn
        public DaySo(int[] arr)
        {
            if (arr != null)
            {
                data = new int[arr.Length];
                Array.Copy(arr, data, arr.Length);
            }
            else
            {
                data = new int[0];
            }
        }

        // =========================================================================
        // b. INDEXER TRUY CẬP PHẦN TỬ THỨ I
        // =========================================================================

        public int this[int index]
        {
            get
            {
                if (index < 0 || index >= data.Length)
                {
                    throw new IndexOutOfRangeException("Chỉ số nằm ngoài phạm vi của dãy số.");
                }
                return data[index];
            }
            set
            {
                if (index < 0 || index >= data.Length)
                {
                    throw new IndexOutOfRangeException("Chỉ số nằm ngoài phạm vi của dãy số.");
                }
                data[index] = value;
            }
        }

        // =========================================================================
        // c. NHẬP / XUẤT DÃY SỐ
        // =========================================================================

        public void Nhap()
        {
            Console.Write("Nhập số lượng phần tử n: ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n < 0)
            {
                Console.Write("Số lượng không hợp lệ. Nhập lại n: ");
            }

            data = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Nhập phần tử thứ [{i}]: ");
                while (!int.TryParse(Console.ReadLine(), out data[i]))
                {
                    Console.Write($"Giá trị không hợp lệ. Nhập lại phần tử thứ [{i}]: ");
                }
            }
        }

        public void Xuat()
        {
            if (data == null || data.Length == 0)
            {
                Console.WriteLine("Dãy số rỗng.");
                return;
            }

            Console.WriteLine(string.Join(" ", data));
        }

        // =========================================================================
        // d. TÌM CÁC SỐ CHẴN
        // =========================================================================

        public List<int> TimSoChan()
        {
            List<int> dsSoChan = new List<int>();
            foreach (int item in data)
            {
                if (item % 2 == 0)
                {
                    dsSoChan.Add(item);
                }
            }
            return dsSoChan;
        }
    }

    // =============================================================================
    // CHƯƠNG TRÌNH CHÍNH (MAIN) ĐỂ KIỂM THỬ
    // =============================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== 1. KIỂM THỬ NHẬP / XUẤT DÃY SỐ ===");
            DaySo ds = new DaySo();
            ds.Nhap();
            Console.Write("Dãy số vừa nhập: ");
            ds.Xuat();

            Console.WriteLine("\n=== 2. KIỂM THỬ INDEXER ===");
            if (ds.SoPhanTu > 0)
            {
                Console.WriteLine($"Đọc phần tử ds[0]: {ds[0]}");
                ds[0] = 999; // Thay đổi giá trị bằng Indexer
                Console.Write("Dãy số sau khi gán ds[0] = 999: ");
                ds.Xuat();
            }

            Console.WriteLine("\n=== 3. KIỂM THỬ TÌM SỐ CHẴN ===");
            List<int> cacSoChan = ds.TimSoChan();
            Console.Write("Các số chẵn trong dãy: ");
            if (cacSoChan.Count > 0)
            {
                Console.WriteLine(string.Join(" ", cacSoChan));
            }
            else
            {
                Console.WriteLine("Không có số chẵn nào.");
            }

            Console.WriteLine("\n=== 4. KIỂM THỬ CÁC CONSTRUCTOR KHÁC ===");
            int[] mangGoc = { 10, 15, 20, 25, 30 };
            DaySo dsSaoChep = new DaySo(mangGoc);
            Console.Write("Dãy số khởi tạo từ mảng { 10, 15, 20, 25, 30 }: ");
            dsSaoChep.Xuat();

            Console.ReadLine();
        }
    }
}