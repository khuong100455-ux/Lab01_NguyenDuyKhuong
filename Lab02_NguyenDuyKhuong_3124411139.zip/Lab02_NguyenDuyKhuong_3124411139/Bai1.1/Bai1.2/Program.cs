﻿using System;

namespace Bai1_2
{
    class Point
    {
        // Field
        private double x;
        private double y;

        // Constructor mặc định: x = y = 0
        public Point()
        {
            x = 0;
            y = 0;
        }

        // Constructor có tham số
        public Point(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        // Constructor sao chép
        public Point(Point p)
        {
            x = p.x;
            y = p.y;
        }

        // Property
        public double X
        {
            get { return x; }
            set { x = value; }
        }

        public double Y
        {
            get { return y; }
            set { y = value; }
        }

        // Nhập, xuất
        public void Input()
        {
            Console.Write("  Nhập x: ");
            x = double.Parse(Console.ReadLine());
            Console.Write("  Nhập y: ");
            y = double.Parse(Console.ReadLine());
        }

        public void Output()
        {
            Console.WriteLine(this.ToString());
        }

        // Override ToString
        public override string ToString()
        {
            return "(" + x + ", " + y + ")";
        }

        // Đa năng toán tử
        public static Point operator +(Point a, Point b)
        {
            return new Point(a.x + b.x, a.y + b.y);
        }

        public static Point operator -(Point a, Point b)
        {
            return new Point(a.x - b.x, a.y - b.y);
        }

        // Lấy âm (toán tử một ngôi)
        public static Point operator -(Point a)
        {
            return new Point(-a.x, -a.y);
        }

        // (a) Khoảng cách: phương thức thành viên
        public double KhoangCach(Point other)
        {
            double dx = x - other.x;
            double dy = y - other.y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        // (a) Khoảng cách: phương thức tĩnh
        public static double KhoangCach(Point a, Point b)
        {
            double dx = a.x - b.x;
            double dy = a.y - b.y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        // (b) Trung điểm: phương thức thành viên
        public Point TrungDiem(Point other)
        {
            return new Point((x + other.x) / 2, (y + other.y) / 2);
        }

        // (b) Trung điểm: phương thức tĩnh
        public static Point TrungDiem(Point a, Point b)
        {
            return new Point((a.x + b.x) / 2, (a.y + b.y) / 2);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            Point A = new Point();
            Point B = new Point();

            Console.WriteLine("Nhập điểm A:");
            A.Input();
            Console.WriteLine("Nhập điểm B:");
            B.Input();

            Console.Write("\nĐiểm A = ");
            A.Output();
            Console.WriteLine("Điểm B = " + B);

            // Đa năng toán tử
            Console.WriteLine("\nA + B = " + (A + B));
            Console.WriteLine("A - B = " + (A - B));
            Console.WriteLine("-A    = " + (-A));

            // (a) Khoảng cách
            Console.WriteLine("\n(a) Khoảng cách AB");
            Console.WriteLine("  Phương thức thành viên: " + A.KhoangCach(B));
            Console.WriteLine("  Phương thức tĩnh      : " + Point.KhoangCach(A, B));

            // (b) Trung điểm
            Console.WriteLine("\n(b) Trung điểm I của AB");
            Console.WriteLine("  Phương thức thành viên: " + A.TrungDiem(B));
            Console.WriteLine("  Phương thức tĩnh      : " + Point.TrungDiem(A, B));

            Console.ReadKey();
        }
    }
}