﻿using System;

namespace Bai1_5
{
    class DonThuc
    {
        // Field
        private double a;   // hệ số (số thực)
        private int n;      // số mũ (số nguyên không âm)

        // Constructor mặc định: đơn thức 0
        public DonThuc()
        {
            a = 0;
            n = 0;
        }

        // Constructor có tham số
        public DonThuc(double a, int n)
        {
            if (n < 0)
                throw new ArgumentException("Số mũ phải là số nguyên không âm");
            this.a = a;
            this.n = n;
        }

        // Constructor sao chép
        public DonThuc(DonThuc d)
        {
            a = d.a;
            n = d.n;
        }

        // Property
        public double HeSo
        {
            get { return a; }
            set { a = value; }
        }

        public int SoMu
        {
            get { return n; }
            set
            {
                if (value < 0)
                    throw new ArgumentException("Số mũ phải là số nguyên không âm");
                n = value;
            }
        }

        // Nhập đơn thức
        public void Nhap()
        {
            do
            {
                Console.Write("Nhập hệ số a: ");
            } while (!double.TryParse(Console.ReadLine(), out a));

            do
            {
                Console.Write("Nhập số mũ n (số nguyên >= 0): ");
            } while (!int.TryParse(Console.ReadLine(), out n) || n < 0);
        }

        // (a) Tính giá trị đơn thức tại x
        public double TinhGiaTri(double x)
        {
            return a * Math.Pow(x, n);
        }

        // (b) Đạo hàm: Q(x) = a.n.x^(n-1)
        public DonThuc DaoHam()
        {
            if (n == 0)
                return new DonThuc(0, 0);   // đạo hàm của hằng số là 0
            return new DonThuc(a * n, n - 1);
        }

        // Override ToString
        public override string ToString()
        {
            if (a == 0) return "0";
            if (n == 0) return a.ToString();

            string heSo;
            if (a == 1) heSo = "";
            else if (a == -1) heSo = "-";
            else heSo = a.ToString();

            string bien = (n == 1) ? "x" : "x^" + n;
            return heSo + bien;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            DonThuc p = new DonThuc();
            Console.WriteLine("Nhập đơn thức P(x) = a.x^n:");
            p.Nhap();

            double x;
            do
            {

            } while (true);
            {
                Console.Write("Nhập giá trị x: ");
            } while (!double.TryParse(Console.ReadLine(), out x));

            Console.WriteLine("\nP(x) = " + p);
            Console.WriteLine("(a) P(" + x + ") = " + p.TinhGiaTri(x));

            DonThuc q = p.DaoHam();
            Console.WriteLine("\n(b) Q(x) = P'(x) = " + q);
            Console.WriteLine("    Q(" + x + ") = " + q.TinhGiaTri(x));

            Console.ReadKey();
        }
    }
}
