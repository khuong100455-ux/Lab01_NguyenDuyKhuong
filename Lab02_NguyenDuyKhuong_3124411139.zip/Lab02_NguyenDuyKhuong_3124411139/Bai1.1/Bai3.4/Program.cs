﻿using System;

namespace BaiTapConsoleMenu
{
    // =========================================================================
    // 1. CƠ SỞ: LỚP ConsoleMenu TỔNG QUÁT HỖ TRỢ CẢ KẾ THỪA VÀ EVENT
    // =========================================================================
    public class ConsoleMenu
    {
        // Khai báo Delegate và Event để hỗ trợ mở rộng qua Sự kiện (Event)
        public delegate void MenuChoiceHandler(int choice);
        public event MenuChoiceHandler Choose;

        // Tiêu đề và danh sách các lựa chọn trong Menu
        public string Title { get; set; } = "Menu";
        public string[] Options { get; set; }

        public ConsoleMenu() { }

        public ConsoleMenu(string title, string[] options)
        {
            Title = title;
            Options = options;
        }

        // Phương thức hiển thị giao diện Menu
        public virtual void Display()
        {
            Console.WriteLine($"=== {Title} ===");
            if (Options != null)
            {
                for (int i = 0; i < Options.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {Options[i]}");
                }
            }
            Console.WriteLine("0. Thoát chương trình");
        }

        // Phương thức ảo cho phép lớp con override (Mở rộng qua Kế thừa)
        protected virtual void OnChoose(int choice)
        {
            // Bắn sự kiện Choose cho các hàm đăng ký bên ngoài (Mở rộng qua Event)
            Choose?.Invoke(choice);
        }

        // Phương thức điều hành vòng lặp Menu
        public void Run()
        {
            int choice = -1;
            while (choice != 0)
            {
                Console.Clear();
                Display();
                Console.Write("\nThực hiện: ");

                if (int.TryParse(Console.ReadLine(), out choice))
                {
                    if (choice == 0)
                    {
                        Console.WriteLine("Cảm ơn bạn đã sử dụng chương trình. Tạm biệt!");
                        break;
                    }

                    Console.WriteLine($"\nBạn thực hiện chức năng {choice}");
                    OnChoose(choice);
                }
                else
                {
                    Console.WriteLine("\nLựa chọn không hợp lệ! Vui lòng nhập số.");
                }

                Console.WriteLine("\nNhấn phím bất kỳ để tiếp tục...");
                Console.ReadKey();
            }
        }
    }

    // =========================================================================
    // 2. MỞ RỘNG BẰNG KẾ THỪA (PTBac2Console : ConsoleMenu)
    // =========================================================================
    public class PTBac2Console : ConsoleMenu
    {
        private double a, b, c;

        public PTBac2Console()
        {
            Title = "GIẢI PHƯƠNG TRÌNH BẬC 2 (KẾ THỪA)";
            Options = new string[]
            {
                "Nhập các hệ số (a, b, c)",
                "Giải phương trình bậc 2"
            };
        }

        // Ghi đè phương thức OnChoose để xử lý các chức năng theo kế thừa
        protected override void OnChoose(int choice)
        {
            // Gọi base.OnChoose(choice) để kích hoạt cả event Choose nếu có đăng ký
            base.OnChoose(choice);

            switch (choice)
            {
                case 1:
                    NhapHeSo();
                    break;
                case 2:
                    GiaiPT();
                    break;
                default:
                    Console.WriteLine("Chức năng không tồn tại!");
                    break;
            }
        }

        private void NhapHeSo()
        {
            Console.WriteLine("--- NHẬP HỆ SỐ PHƯƠNG TRÌNH a*x^2 + b*x + c = 0 ---");

            Console.Write("  Nhập a: ");
            while (!double.TryParse(Console.ReadLine(), out a))
                Console.Write("  a không hợp lệ. Nhập lại a: ");

            Console.Write("  Nhập b: ");
            while (!double.TryParse(Console.ReadLine(), out b))
                Console.Write("  b không hợp lệ. Nhập lại b: ");

            Console.Write("  Nhập c: ");
            while (!double.TryParse(Console.ReadLine(), out c))
                Console.Write("  c không hợp lệ. Nhập lại c: ");

            Console.WriteLine($"--> Đã nhập phương trình: {a}x^2 + {b}x + {c} = 0");
        }

        private void GiaiPT()
        {
            Console.WriteLine($"--- GIẢI PHƯƠNG TRÌNH: {a}x^2 + {b}x + {c} = 0 ---");

            if (a == 0)
            {
                // Trở thành phương trình bậc 1: bx + c = 0
                if (b == 0)
                {
                    Console.WriteLine(c == 0 ? "--> Phương trình có vô số nghiệm." : "--> Phương trình vô nghiệm.");
                }
                else
                {
                    Console.WriteLine($"--> Phương trình bậc 1 có 1 nghiệm: x = {-c / b:F2}");
                }
                return;
            }

            // Tính Delta cho PT bậc 2
            double delta = b * b - 4 * a * c;
            if (delta < 0)
            {
                Console.WriteLine("--> Phương trình vô nghiệm (không có nghiệm thực).");
            }
            else if (delta == 0)
            {
                double x = -b / (2 * a);
                Console.WriteLine($"--> Phương trình có nghiệm kép: x1 = x2 = {x:F2}");
            }
            else
            {
                double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
                Console.WriteLine($"--> Phương trình có 2 nghiệm phân biệt:\n    x1 = {x1:F2}\n    x2 = {x2:F2}");
            }
        }
    }

    // =========================================================================
    // 3. CHƯƠNG TRÌNH CHÍNH (MAIN CHẠY CẢ 2 CÁCH: KẾ THỪA VÀ EVENT)
    // =========================================================================
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("CHỌN CHẾ ĐỘ CHẠY CHƯƠNG TRÌNH:");
            Console.WriteLine("1. Chạy qua KẾ THỪA (PTBac2Console)");
            Console.WriteLine("2. Chạy qua EVENT (app.Choose += ...)");
            Console.Write("Lựa chọn của bạn (1 hoặc 2): ");
            string chon = Console.ReadLine();

            if (chon == "1")
            {
                // cách 1: Mở rộng qua Kế thừa
                PTBac2Console app = new PTBac2Console();
                app.Run();
            }
            else
            {
                // Cách 2: Mở rộng qua Sự kiện (Event Choose)
                ConsoleMenu app = new ConsoleMenu(
                    "GIẢI PHƯƠNG TRÌNH BẬC 2 (EVENT)",
                    new string[] { "Nhập các hệ số (a, b, c)", "Giải phương trình bậc 2" }
                );

                double a = 0, b = 0, c = 0;

                // Đăng ký phương thức xử lý vào Event Choose
                app.Choose += (choice) =>
                {
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("--- NHẬP HỆ SỐ PHƯƠNG TRÌNH ---");
                            Console.Write("  Nhập a: "); double.TryParse(Console.ReadLine(), out a);
                            Console.Write("  Nhập b: "); double.TryParse(Console.ReadLine(), out b);
                            Console.Write("  Nhập c: "); double.TryParse(Console.ReadLine(), out c);
                            Console.WriteLine($"--> Đã nhập: {a}x^2 + {b}x + {c} = 0");
                            break;
                        case 2:
                            Console.WriteLine($"--- GIẢI PHƯƠNG TRÌNH: {a}x^2 + {b}x + {c} = 0 ---");
                            if (a == 0)
                            {
                                if (b == 0) Console.WriteLine(c == 0 ? "Vô số nghiệm" : "Vô nghiệm");
                                else Console.WriteLine($"Nghiệm x = {-c / b:F2}");
                            }
                            else
                            {
                                double delta = b * b - 4 * a * c;
                                if (delta < 0) Console.WriteLine("Phương trình vô nghiệm");
                                else if (delta == 0) Console.WriteLine($"Nghiệm kép x = {-b / (2 * a):F2}");
                                else
                                {
                                    double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                                    double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
                                    Console.WriteLine($"x1 = {x1:F2}, x2 = {x2:F2}");
                                }
                            }
                            break;
                    }
                };

                app.Run();
            }
        }
    }
}