﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ
{
    // =========================================================================
    // 1. ĐỊNH NGHĨA DỮ LIỆU CƠ BẢN (BÀI 4.1)
    // =========================================================================
    public class MonHoc
    {
        public string MaMon { get; set; } = "";
        public string TenMon { get; set; } = "";
        public string He { get; set; } = "";
        public byte SoTiet { get; set; }
    }

    public class DuLieu
    {
        public static List<MonHoc> DS_Mon()
        {
            return new List<MonHoc>
            {
                new MonHoc { MaMon = "HP2_1", TenMon = "Nền tảng C#", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP2_2", TenMon = "Công nghệ ADO.NET", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP3_1", TenMon = "Lập trình Windows Forms", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP3_2", TenMon = "Xây dựng ứng dụng Windows Forms", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP4_1", TenMon = "Lập trình Web với HTML, CSS và JavaScript", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP4_2", TenMon = "Xây dựng ứng dụng Web với ASP.NET", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP5_1", TenMon = "Lập trình CSDL SQL Server căn bản", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP5_2", TenMon = "Lập trình CSDL SQL Server nâng cao", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "JLCB",  TenMon = "Joomla cơ bản", He = "CD", SoTiet = 72 },
                new MonHoc { MaMon = "LINQ",  TenMon = "Language-Integrated Query", He = "CD", SoTiet = 64 },
                new MonHoc { MaMon = "DAWEB", TenMon = "Đồ án thực tế Web với ASP.NET", He = "CD", SoTiet = 40 },
                new MonHoc { MaMon = "DAWIN", TenMon = "Đồ án thực tế Windows Forms", He = "CD", SoTiet = 40 },
                new MonHoc { MaMon = "CC++",  TenMon = "Lập trình hướng đối tượng với C/C++", He = "CD", SoTiet = 128 },
                new MonHoc { MaMon = "JQUE",  TenMon = "JQuery", He = "CD", SoTiet = 22 },
                new MonHoc { MaMon = "XML",   TenMon = "Công nghệ XML", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "CRYS",  TenMon = "Crystal Report trong Visual Studio", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "BWEB",  TenMon = "HTML, CSS và JavaScript", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "XYZ",   TenMon = "Chưa đặt tên môn", He = "", SoTiet = 0 }
            };
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Bai5_2();

            Console.WriteLine("\nHoàn thành Bài 5.2! Bấm phím bất kỳ để thoát.");
            Console.ReadLine();
        }

        public static void Bai5_2()
        {
            Console.WriteLine("========== BÀI 5.2: THỐNG KÊ TRÊN LIST<MONHOC> ==========\n");

            List<MonHoc> dsMon = DuLieu.DS_Mon();

            // ---------------------------------------------------------------------
            // a. Cho biết tổng số môn hiện có
            // ---------------------------------------------------------------------
            Console.WriteLine("a. Tổng số môn hiện có:");
            int cauA_Query = (from m in dsMon select m).Count();
            int cauA_Method = dsMon.Count();
            Console.WriteLine($"   - [Query Syntax] : {cauA_Query}");
            Console.WriteLine($"   - [Method Syntax]: {cauA_Method}\n");

            // ---------------------------------------------------------------------
            // b. Đếm số môn có tên bắt đầu bằng "Lập trình"
            // ---------------------------------------------------------------------
            Console.WriteLine("b. Đếm số môn có tên bắt đầu bằng 'Lập trình':");
            int cauB_Query = (from m in dsMon where m.TenMon.StartsWith("Lập trình") select m).Count();
            int cauB_Method = dsMon.Count(m => m.TenMon.StartsWith("Lập trình"));
            Console.WriteLine($"   - [Query Syntax] : {cauB_Query}");
            Console.WriteLine($"   - [Method Syntax]: {cauB_Method}\n");

            // ---------------------------------------------------------------------
            // c. Tính tổng số tiết của hệ Kỹ thuật viên (KTV)
            // ---------------------------------------------------------------------
            Console.WriteLine("c. Tổng số tiết của hệ Kỹ thuật viên (KTV):");
            int cauC_Query = (from m in dsMon where m.He == "KTV" select (int)m.SoTiet).Sum();
            int cauC_Method = dsMon.Where(m => m.He == "KTV").Sum(m => m.SoTiet);
            Console.WriteLine($"   - [Query Syntax] : {cauC_Query}");
            Console.WriteLine($"   - [Method Syntax]: {cauC_Method}\n");

            // ---------------------------------------------------------------------
            // d. Cho biết tổng số môn của mỗi hệ: Hệ, Tổng số môn
            // ---------------------------------------------------------------------
            Console.WriteLine("d. Tổng số môn của mỗi hệ:");
            var cauD_Query = from m in dsMon
                             group m by m.He into g
                             select new { He = string.IsNullOrEmpty(g.Key) ? "Chưa xác định" : g.Key, SoLuong = g.Count() };

            var cauD_Method = dsMon.GroupBy(m => m.He)
                                   .Select(g => new { He = string.IsNullOrEmpty(g.Key) ? "Chưa xác định" : g.Key, SoLuong = g.Count() });

            Console.WriteLine("  [Method Syntax]:");
            foreach (var item in cauD_Method)
            {
                Console.WriteLine($"   - Hệ: {item.He,-15} | Tổng số môn: {item.SoLuong}");
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // e. Nhóm theo Số tiết; in Số tiết và Tổng số môn, sắp xếp giảm dần theo Số tiết
            // ---------------------------------------------------------------------
            Console.WriteLine("e. Nhóm theo Số tiết (Sắp xếp giảm dần theo Số tiết):");
            var cauE_Query = from m in dsMon
                             group m by m.SoTiet into g
                             orderby g.Key descending
                             select new { SoTiet = g.Key, TongSoMon = g.Count() };

            var cauE_Method = dsMon.GroupBy(m => m.SoTiet)
                                   .OrderByDescending(g => g.Key)
                                   .Select(g => new { SoTiet = g.Key, TongSoMon = g.Count() });

            Console.WriteLine("  [Query Syntax]:");
            foreach (var item in cauE_Query)
            {
                Console.WriteLine($"   - {item.SoTiet} tiết: {item.TongSoMon} môn");
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // f. Cho biết thông tin môn học có số tiết cao nhất
            // ---------------------------------------------------------------------
            Console.WriteLine("f. Thông tin môn học có số tiết cao nhất:");
            byte maxTiet = dsMon.Max(m => m.SoTiet);

            var cauF_Query = from m in dsMon where m.SoTiet == maxTiet select m;
            var cauF_Method = dsMon.Where(m => m.SoTiet == maxTiet);

            Console.WriteLine("  [Method Syntax]:");
            foreach (var m in cauF_Method)
            {
                Console.WriteLine($"   - [{m.MaMon}] {m.TenMon} - Hệ: {m.He} - Số tiết: {m.SoTiet}");
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // g. Thống kê theo Hệ: tổng số môn, tổng số tiết, số tiết cao nhất, số tiết thấp nhất
            // ---------------------------------------------------------------------
            Console.WriteLine("g. Thống kê chi tiết theo Hệ:");
            var cauG_Query = from m in dsMon
                             group m by m.He into g
                             select new
                             {
                                 He = string.IsNullOrEmpty(g.Key) ? "Chưa xác định" : g.Key,
                                 TongMon = g.Count(),
                                 TongTiet = g.Sum(x => x.SoTiet),
                                 MaxTiet = g.Max(x => x.SoTiet),
                                 MinTiet = g.Min(x => x.SoTiet)
                             };

            var cauG_Method = dsMon.GroupBy(m => m.He)
                                   .Select(g => new
                                   {
                                       He = string.IsNullOrEmpty(g.Key) ? "Chưa xác định" : g.Key,
                                       TongMon = g.Count(),
                                       TongTiet = g.Sum(x => x.SoTiet),
                                       MaxTiet = g.Max(x => x.SoTiet),
                                       MinTiet = g.Min(x => x.SoTiet)
                                   });

            Console.WriteLine("  [Query Syntax]:");
            foreach (var item in cauG_Query)
            {
                Console.WriteLine($"   + Hệ [{item.He}]: Tổng môn = {item.TongMon}, Tổng tiết = {item.TongTiet}, Cao nhất = {item.MaxTiet}, Thấp nhất = {item.MinTiet}");
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // h. Liệt kê các môn học được phân nhóm theo Hệ
            // ---------------------------------------------------------------------
            Console.WriteLine("h. Liệt kê môn học phân nhóm theo Hệ:");
            var cauH_Query = from m in dsMon group m by m.He into g select g;
            var cauH_Method = dsMon.GroupBy(m => m.He);

            Console.WriteLine("  [Method Syntax]:");
            foreach (var group in cauH_Method)
            {
                string tenHe = string.IsNullOrEmpty(group.Key) ? "Chưa xác định" : group.Key;
                Console.WriteLine($"   + Hệ [{tenHe}]:");
                foreach (var m in group)
                {
                    Console.WriteLine($"       - [{m.MaMon}] {m.TenMon}");
                }
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // i. Liệt kê các môn học được phân nhóm theo Số tiết và tăng dần theo Số tiết
            // ---------------------------------------------------------------------
            Console.WriteLine("i. Liệt kê môn học phân nhóm theo Số tiết (Tăng dần):");
            var cauI_Query = from m in dsMon
                             group m by m.SoTiet into g
                             orderby g.Key ascending
                             select g;

            var cauI_Method = dsMon.GroupBy(m => m.SoTiet).OrderBy(g => g.Key);

            Console.WriteLine("  [Query Syntax]:");
            foreach (var group in cauI_Query)
            {
                Console.WriteLine($"   + Nhóm {group.Key} tiết:");
                foreach (var m in group)
                {
                    Console.WriteLine($"       - [{m.MaMon}] {m.TenMon} ({m.He})");
                }
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // j. Với hệ KTV, phân nhóm theo học phần HP2, HP3, HP4, HP5; sắp xếp theo Mã môn
            // ---------------------------------------------------------------------
            Console.WriteLine("j. Hệ KTV phân nhóm theo Học phần (HP2, HP3, HP4, HP5):");
            var cauJ_Query = from m in dsMon
                             where m.He == "KTV" && m.MaMon.Length >= 3
                             group m by m.MaMon.Substring(0, 3) into g
                             orderby g.Key
                             select g;

            var cauJ_Method = dsMon.Where(m => m.He == "KTV" && m.MaMon.Length >= 3)
                                   .GroupBy(m => m.MaMon.Substring(0, 3))
                                   .OrderBy(g => g.Key);

            Console.WriteLine("  [Method Syntax]:");
            foreach (var group in cauJ_Method)
            {
                Console.WriteLine($"   + Học phần [{group.Key}]:");
                foreach (var m in group.OrderBy(x => x.MaMon))
                {
                    Console.WriteLine($"       - [{m.MaMon}] {m.TenMon}");
                }
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // k. Phân nhóm theo Hệ, chỉ lấy các môn có Số tiết > 40; trong mỗi nhóm sắp xếp theo Mã môn
            // ---------------------------------------------------------------------
            Console.WriteLine("k. Phân nhóm theo Hệ (chỉ lấy môn có Số tiết > 40):");
            var cauK_Query = from m in dsMon
                             where m.SoTiet > 40
                             group m by m.He into g
                             select g;

            var cauK_Method = dsMon.Where(m => m.SoTiet > 40)
                                   .GroupBy(m => m.He);

            Console.WriteLine("  [Query Syntax]:");
            foreach (var group in cauK_Query)
            {
                string tenHe = string.IsNullOrEmpty(group.Key) ? "Chưa xác định" : group.Key;
                Console.WriteLine($"   + Hệ [{tenHe}]:");
                foreach (var m in group.OrderBy(x => x.MaMon))
                {
                    Console.WriteLine($"       - [{m.MaMon}] {m.TenMon} ({m.SoTiet} tiết)");
                }
            }
            Console.WriteLine();
        }
    }
}