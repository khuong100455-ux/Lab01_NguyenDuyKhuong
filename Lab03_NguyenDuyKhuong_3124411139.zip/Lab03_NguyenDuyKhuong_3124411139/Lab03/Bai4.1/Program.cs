﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ
{
    // 1. Khai báo lớp MonHoc
    public class MonHoc
    {
        public string MaMon { get; set; } = "";
        public string TenMon { get; set; } = "";
        public string He { get; set; } = "";
        public byte SoTiet { get; set; }
    }

    // 2. Khai báo lớp DuLieu
    public class DuLieu
    {
        public static List<MonHoc> DS_Mon()
        {
            return new List<MonHoc>
            {
                new MonHoc { MaMon = "HP2_1", TenMon = "Nền tảng C#", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP2_2", TenMon = "Công nghệ ADO.NET", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP3_1", TenMon = "Lập trình Windows Forms", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP3_2", TenMon = "Xây dựng ứng dụng Windows Forms", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP4_1", TenMon = "Lập trình Web với HTML, CSS và JavaScript", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP4_2", TenMon = "Xây dựng ứng dụng Web với ASP.NET", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP5_1", TenMon = "Lập trình CSDL SQL Server căn bản", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP5_2", TenMon = "Lập trình CSDL SQL Server nâng cao", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "JLCB",  TenMon = "Joomla cơ bản", He = "CD", SoTiet = 72 },
                new MonHoc { MaMon = "LINQ",  TenMon = "Language-Integrated Query", He = "CD", SoTiet = 64 },
                new MonHoc { MaMon = "DAWEB", TenMon = "Đồ án thực tế Web với ASP.NET", He = "CD", SoTiet = 40 },
                new MonHoc { MaMon = "DAWIN", TenMon = "Đồ án thực tế Windows Forms", He = "CD", SoTiet = 40 },
                new MonHoc { MaMon = "CC++",  TenMon = "Lập trình hướng đối tượng với C/C++", He = "CD", SoTiet = 128 },
                new MonHoc { MaMon = "JQUE",  TenMon = "JQuery", He = "CD", SoTiet = 22 },
                new MonHoc { MaMon = "XML",   TenMon = "Công nghệ XML", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "CRYS",  TenMon = "Crystal Report trong Visual Studio", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "BWEB",  TenMon = "HTML, CSS và JavaScript", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "XYZ",   TenMon = "Chưa đặt tên môn", He = "", SoTiet = 0 }
            };
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            List<MonHoc> dsMon = DuLieu.DS_Mon();

            Console.WriteLine("================ TRUY VẤN LIST<MONHOC> ================\n");

            // -----------------------------------------------------------------
            // 1. Lọc danh sách môn thuộc Hệ "CD"
            // -----------------------------------------------------------------
            Console.WriteLine("1. Các môn học thuộc Hệ 'CD':");

            // Query Syntax
            var q1_Query = from m in dsMon
                           where m.He == "CD"
                           select m;

            // Method Syntax
            var q1_Method = dsMon.Where(m => m.He == "CD");

            foreach (var m in q1_Query)
            {
                Console.WriteLine($"   [{m.MaMon}] {m.TenMon} - {m.SoTiet} tiết");
            }
            Console.WriteLine();

            // -----------------------------------------------------------------
            // 2. Lọc môn có Số tiết >= 64 và Sắp xếp theo Số tiết giảm dần
            // -----------------------------------------------------------------
            Console.WriteLine("2. Các môn có Số tiết >= 64 (Sắp xếp số tiết giảm dần):");

            // Query Syntax
            var q2_Query = from m in dsMon
                           where m.SoTiet >= 64
                           orderby m.SoTiet descending, m.TenMon ascending
                           select m;

            // Method Syntax
            var q2_Method = dsMon.Where(m => m.SoTiet >= 64)
                                 .OrderByDescending(m => m.SoTiet)
                                 .ThenBy(m => m.TenMon);

            foreach (var m in q2_Query)
            {
                Console.WriteLine($"   [{m.MaMon}] {m.TenMon} ({m.He}) - {m.SoTiet} tiết");
            }
            Console.WriteLine();

            // -----------------------------------------------------------------
            // 3. Phân nhóm môn học theo Hệ (GroupBy)
            // -----------------------------------------------------------------
            Console.WriteLine("3. Phân nhóm môn học theo Hệ:");

            // Query Syntax
            var q3_Query = from m in dsMon
                           group m by m.He into g
                           select g;

            // Method Syntax
            var q3_Method = dsMon.GroupBy(m => m.He);

            foreach (var group in q3_Query)
            {
                string tenHe = string.IsNullOrEmpty(group.Key) ? "Chưa xác định" : group.Key;
                Console.WriteLine($"   + Hệ [{tenHe}] ({group.Count()} môn):");
                foreach (var m in group)
                {
                    Console.WriteLine($"       - {m.TenMon} ({m.SoTiet} tiết)");
                }
            }
            Console.WriteLine();

            // -----------------------------------------------------------------
            // 4. Thống kê tổng số tiết và trung bình số tiết
            // -----------------------------------------------------------------
            Console.WriteLine("4. Thống kê tổng quan:");

            int tongSoTiet = dsMon.Sum(m => m.SoTiet);
            double trungBinhTiet = dsMon.Average(m => m.SoTiet);
            MonHoc monMaxTiet = dsMon.OrderByDescending(m => m.SoTiet).First();

            Console.WriteLine($"   - Tổng số tiết của tất cả các môn: {tongSoTiet}");
            Console.WriteLine($"   - Trung bình số tiết mỗi môn: {trungBinhTiet:F1}");
            Console.WriteLine($"   - Món có số tiết nhiều nhất: {monMaxTiet.TenMon} ({monMaxTiet.SoTiet} tiết)");

            Console.WriteLine("\n=======================================================");
            Console.ReadLine();
        }
    }
}