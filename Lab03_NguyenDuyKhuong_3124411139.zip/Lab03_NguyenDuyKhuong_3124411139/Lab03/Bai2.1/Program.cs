﻿using System;
using System.Linq;

namespace BaiThucHanhLINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            int[] mangSo = { 50, 42, 16, 3, 9, 8, 12, 7, 24, 0 };

            // a. Phần tử chia hết cho 4 và 3
            var cauA = mangSo.Where(x => x % 4 == 0 && x % 3 == 0);
            Console.WriteLine("a. Chia hết cho 4 và 3: " + string.Join(", ", cauA));

            // b. Phần tử <= 3
            var cauB = mangSo.Where(x => x <= 3);
            Console.WriteLine("b. Nhỏ hơn hoặc bằng 3: " + string.Join(", ", cauB));

            // c. Dãy mới
            var cauC = mangSo.Select(x => x % 2 == 0 ? x / 2 : x);
            Console.WriteLine("c. Dãy mới: " + string.Join(", ", cauC));
        }
    }
}