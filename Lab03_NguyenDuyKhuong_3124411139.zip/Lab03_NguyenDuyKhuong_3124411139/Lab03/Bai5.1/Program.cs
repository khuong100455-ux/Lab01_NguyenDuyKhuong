﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ
{
    // 1. Lớp MonHoc (Bài 4.1)
    public class MonHoc
    {
        public string MaMon { get; set; } = "";
        public string TenMon { get; set; } = "";
        public string He { get; set; } = "";
        public byte SoTiet { get; set; }
    }

    // 2. Lớp DuLieu (Bài 4.1)
    public class DuLieu
    {
        public static List<MonHoc> DS_Mon()
        {
            return new List<MonHoc>
            {
                new MonHoc { MaMon = "HP2_1", TenMon = "Nền tảng C#", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP2_2", TenMon = "Công nghệ ADO.NET", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP3_1", TenMon = "Lập trình Windows Forms", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP3_2", TenMon = "Xây dựng ứng dụng Windows Forms", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP4_1", TenMon = "Lập trình Web với HTML, CSS và JavaScript", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP4_2", TenMon = "Xây dựng ứng dụng Web với ASP.NET", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP5_1", TenMon = "Lập trình CSDL SQL Server căn bản", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP5_2", TenMon = "Lập trình CSDL SQL Server nâng cao", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "JLCB",  TenMon = "Joomla cơ bản", He = "CD", SoTiet = 72 },
                new MonHoc { MaMon = "LINQ",  TenMon = "Language-Integrated Query", He = "CD", SoTiet = 64 },
                new MonHoc { MaMon = "DAWEB", TenMon = "Đồ án thực tế Web với ASP.NET", He = "CD", SoTiet = 40 },
                new MonHoc { MaMon = "DAWIN", TenMon = "Đồ án thực tế Windows Forms", He = "CD", SoTiet = 40 },
                new MonHoc { MaMon = "CC++",  TenMon = "Lập trình hướng đối tượng với C/C++", He = "CD", SoTiet = 128 },
                new MonHoc { MaMon = "JQUE",  TenMon = "JQuery", He = "CD", SoTiet = 22 },
                new MonHoc { MaMon = "XML",   TenMon = "Công nghệ XML", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "CRYS",  TenMon = "Crystal Report trong Visual Studio", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "BWEB",  TenMon = "HTML, CSS và JavaScript", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "XYZ",   TenMon = "Chưa đặt tên môn", He = "", SoTiet = 0 }
            };
        }
    }

    // 3. Thực thi Bài 5.1
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Bai5_1();

            Console.ReadLine();
        }

        public static void Bai5_1()
        {
            Console.WriteLine("========== BÀI 5.1: TRUY VẤN CƠ BẢN TÊN LIST<MONHOC> ==========\n");

            List<MonHoc> dsMon = DuLieu.DS_Mon();

            // ---------------------------------------------------------------------
            // Câu a: Liệt kê tên các môn học bắt đầu bằng "Lập trình"
            // ---------------------------------------------------------------------
            Console.WriteLine("a. Các môn học bắt đầu bằng 'Lập trình':");

            // Query Syntax
            var cauA_Query = from m in dsMon
                             where m.TenMon.StartsWith("Lập trình")
                             select m;

            // Method Syntax
            var cauA_Method = dsMon.Where(m => m.TenMon.StartsWith("Lập trình"));

            Console.WriteLine("  [Query Syntax] :");
            foreach (var m in cauA_Query) Console.WriteLine($"   - [{m.MaMon}] {m.TenMon}");

            Console.WriteLine("  [Method Syntax]:");
            foreach (var m in cauA_Method) Console.WriteLine($"   - [{m.MaMon}] {m.TenMon}");
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // Câu b: Môn thuộc hệ "CD", sắp xếp số tiết giảm dần rồi mã môn tăng dần
            // ---------------------------------------------------------------------
            Console.WriteLine("b. Môn thuộc hệ 'CD' (Số tiết giảm dần, Mã môn tăng dần):");

            // Query Syntax
            var cauB_Query = from m in dsMon
                             where m.He == "CD"
                             orderby m.SoTiet descending, m.MaMon ascending
                             select m;

            // Method Syntax
            var cauB_Method = dsMon.Where(m => m.He == "CD")
                                   .OrderByDescending(m => m.SoTiet)
                                   .ThenBy(m => m.MaMon);

            Console.WriteLine("  [Query Syntax] :");
            foreach (var m in cauB_Query) Console.WriteLine($"   - [{m.MaMon}] {m.TenMon} ({m.SoTiet} tiết)");

            Console.WriteLine("  [Method Syntax]:");
            foreach (var m in cauB_Method) Console.WriteLine($"   - [{m.MaMon}] {m.TenMon} ({m.SoTiet} tiết)");
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // Câu c: Các môn có tên chứa từ "web" (Chỉ lấy Tên môn và Hệ)
            // ---------------------------------------------------------------------
            Console.WriteLine("c. Các môn có tên chứa từ 'web' (Chỉ lấy Tên môn và Hệ):");

            // Query Syntax
            var cauC_Query = from m in dsMon
                             where m.TenMon.ToLower().Contains("web")
                             select new { m.TenMon, m.He };

            // Method Syntax
            var cauC_Method = dsMon.Where(m => m.TenMon.ToLower().Contains("web"))
                                   .Select(m => new { m.TenMon, m.He });

            Console.WriteLine("  [Query Syntax] :");
            foreach (var item in cauC_Query) Console.WriteLine($"   - Tên môn: {item.TenMon} | Hệ: {item.He}");

            Console.WriteLine("  [Method Syntax]:");
            foreach (var item in cauC_Method) Console.WriteLine($"   - Tên môn: {item.TenMon} | Hệ: {item.He}");
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // Câu d: Các môn thuộc hệ "KTV", sắp xếp tăng dần theo Mã môn
            // ---------------------------------------------------------------------
            Console.WriteLine("d. Các môn thuộc hệ 'KTV' (Sắp xếp tăng dần theo Mã môn):");

            // Query Syntax
            var cauD_Query = from m in dsMon
                             where m.He == "KTV"
                             orderby m.MaMon ascending
                             select m;

            // Method Syntax
            var cauD_Method = dsMon.Where(m => m.He == "KTV")
                                   .OrderBy(m => m.MaMon);

            Console.WriteLine("  [Query Syntax] :");
            foreach (var m in cauD_Query) Console.WriteLine($"   - [{m.MaMon}] {m.TenMon}");

            Console.WriteLine("  [Method Syntax]:");
            foreach (var m in cauD_Method) Console.WriteLine($"   - [{m.MaMon}] {m.TenMon}");
            Console.WriteLine();
        }
    }
}