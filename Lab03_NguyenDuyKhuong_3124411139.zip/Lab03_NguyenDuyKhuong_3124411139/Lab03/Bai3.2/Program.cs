﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Gọi chạy Bài 3.2
            Bai3_2();

            Console.ReadLine();
        }

        public static void Bai3_2()
        {
            Console.WriteLine("========== BÀI 3.2: THỐNG KÊ MẢNG CHUỖI ==========\n");

            string[] monAn = {
                "Bún bò Huế", "Hủ tiếu heo", "Bánh canh", "Bánh mì",
                "Nước Cà phê", "Mì quảng", "Cơm tấm", "Nước Chanh dây", "Mì xào",
                "Bún riêu", "Bánh cuốn", "Mì gói", "Bún chả", "Hủ tiếu Nam vang"
            };

            // ----------------------------------------------------
            // Câu a: Tìm các phần tử có chiều dài ngắn nhất và dài nhất
            // ----------------------------------------------------
            Console.WriteLine("a. Phần tử có chiều dài ngắn nhất và dài nhất:");

            int minLength = monAn.Min(s => s.Length);
            var dsNganNhat = monAn.Where(s => s.Length == minLength);

            int maxLength = monAn.Max(s => s.Length);
            var dsDaiNhat = monAn.Where(s => s.Length == maxLength);

            Console.WriteLine($" - Ngắn nhất ({minLength} ký tự): {string.Join(", ", dsNganNhat)}");
            Console.WriteLine($" - Dài nhất ({maxLength} ký tự) : {string.Join(", ", dsDaiNhat)}");
            Console.WriteLine();

            // ----------------------------------------------------
            // Câu b: Phân nhóm theo từ đầu tiên của tên món
            // ----------------------------------------------------
            Console.WriteLine("b. Phân nhóm theo từ đầu tiên của tên món:");

            // Query Syntax
            var nhomTuDau_Query = from s in monAn
                                  group s by s.Split(' ')[0] into g
                                  select g;

            // Method Syntax
            var nhomTuDau_Method = monAn.GroupBy(s => s.Split(' ')[0]);

            foreach (var nhom in nhomTuDau_Query)
            {
                Console.WriteLine($"   + Nhóm '{nhom.Key}': {string.Join(", ", nhom)}");
            }
            Console.WriteLine();

            // ----------------------------------------------------
            // Câu c: Đếm số phần tử có từ đầu tiên là "Bánh"
            // ----------------------------------------------------
            Console.WriteLine("c. Đếm số phần tử có từ đầu tiên là 'Bánh':");

            // Query Syntax / Method Syntax
            int demBanh = monAn.Count(s => s.Split(' ')[0] == "Bánh");

            Console.WriteLine($" - Số lượng món ăn bắt đầu bằng từ 'Bánh': {demBanh}");
            Console.WriteLine();
        }
    }
}