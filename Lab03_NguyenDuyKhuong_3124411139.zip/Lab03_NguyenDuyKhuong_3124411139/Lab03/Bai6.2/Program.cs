﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Bai6_2
{
    // 1. Lớp He (Bài 6.1)
    public class He
    {
        public string MaHe { get; set; } = "";
        public string TenHe { get; set; } = "";
    }

    // 2. Lớp MonHoc (Bài 4.1)
    public class MonHoc
    {
        public string MaMon { get; set; } = "";
        public string TenMon { get; set; } = "";
        public string He { get; set; } = "";
        public byte SoTiet { get; set; }
    }

    // 3. Khởi tạo dữ liệu
    public class DuLieu
    {
        public static List<He> DS_He()
        {
            return new List<He>
            {
                new He { MaHe = "KTV", TenHe = "Kỹ thuật viên" },
                new He { MaHe = "CD",  TenHe = "Chuyên đề" },
                new He { MaHe = "QT",  TenHe = "Chứng chỉ quốc tế" }
            };
        }

        public static List<MonHoc> DS_Mon()
        {
            return new List<MonHoc>
            {
                new MonHoc { MaMon = "HP2_1", TenMon = "Nền tảng C#", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP2_2", TenMon = "Công nghệ ADO.NET", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP3_1", TenMon = "Lập trình Windows Forms", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP3_2", TenMon = "Xây dựng ứng dụng Windows Forms", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP4_1", TenMon = "Lập trình Web với HTML, CSS và JavaScript", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP4_2", TenMon = "Xây dựng ứng dụng Web với ASP.NET", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP5_1", TenMon = "Lập trình CSDL SQL Server căn bản", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP5_2", TenMon = "Lập trình CSDL SQL Server nâng cao", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "JLCB",  TenMon = "Joomla cơ bản", He = "CD", SoTiet = 72 },
                new MonHoc { MaMon = "LINQ",  TenMon = "Language-Integrated Query", He = "CD", SoTiet = 64 },
                new MonHoc { MaMon = "DAWEB", TenMon = "Đồ án thực tế Web với ASP.NET", He = "CD", SoTiet = 40 },
                new MonHoc { MaMon = "DAWIN", TenMon = "Đồ án thực tế Windows Forms", He = "CD", SoTiet = 40 },
                new MonHoc { MaMon = "CC++",  TenMon = "Lập trình hướng đối tượng với C/C++", He = "CD", SoTiet = 128 },
                new MonHoc { MaMon = "JQUE",  TenMon = "JQuery", He = "CD", SoTiet = 22 },
                new MonHoc { MaMon = "XML",   TenMon = "Công nghệ XML", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "CRYS",  TenMon = "Crystal Report trong Visual Studio", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "BWEB",  TenMon = "HTML, CSS và JavaScript", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "XYZ",   TenMon = "Chưa đặt tên môn", He = "", SoTiet = 0 }
            };
        }
    }

    // 4. Chương trình chính cho Bài 6.2
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("========== BÀI 6.2: JOIN VÀ CÁC TOÁN TỬ TẬP HỢP ==========\n");

            List<He> dsHe = DuLieu.DS_He();
            List<MonHoc> dsMon = DuLieu.DS_Mon();

            // ---------------------------------------------------------------------
            // a. Dùng join để liệt kê: Tên hệ, Mã môn, Tên môn
            // ---------------------------------------------------------------------
            Console.WriteLine("a. Liệt kê (Inner Join): Tên hệ, Mã môn, Tên môn:");

            // Query Syntax
            var cauA_Query = from h in dsHe
                             join m in dsMon on h.MaHe equals m.He
                             select new { h.TenHe, m.MaMon, m.TenMon };

            // Method Syntax
            var cauA_Method = dsHe.Join(dsMon, h => h.MaHe, m => m.He, (h, m) => new { h.TenHe, m.MaMon, m.TenMon });

            Console.WriteLine("   [Query Syntax]:");
            foreach (var item in cauA_Query)
            {
                Console.WriteLine($"   - {item.TenHe,-20} | [{item.MaMon}] {item.TenMon}");
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // b. Liệt kê cả những hệ chưa có môn học (Left Outer Join)
            // ---------------------------------------------------------------------
            Console.WriteLine("b. Liệt kê cả hệ chưa có môn học (Left Outer Join):");

            // Query Syntax
            var cauB_Query = from h in dsHe
                             join m in dsMon on h.MaHe equals m.He into subMon
                             from m in subMon.DefaultIfEmpty()
                             select new
                             {
                                 TenHe = h.TenHe,
                                 MaMon = m != null ? m.MaMon : "(Chưa có)",
                                 TenMon = m != null ? m.TenMon : "(Chưa có môn học)"
                             };

            // Method Syntax
            var cauB_Method = dsHe.GroupJoin(dsMon, h => h.MaHe, m => m.He, (h, subMon) => new { h, subMon })
                                  .SelectMany(x => x.subMon.DefaultIfEmpty(), (x, m) => new
                                  {
                                      TenHe = x.h.TenHe,
                                      MaMon = m != null ? m.MaMon : "(Chưa có)",
                                      TenMon = m != null ? m.TenMon : "(Chưa có môn học)"
                                  });

            Console.WriteLine("   [Method Syntax]:");
            foreach (var item in cauB_Method)
            {
                Console.WriteLine($"   - Hệ: {item.TenHe,-20} | Mã: {item.MaMon,-8} | Môn: {item.TenMon}");
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // c. Liệt kê cả hệ chưa có môn học VÀ môn học chưa khai báo hệ
            // ---------------------------------------------------------------------
            Console.WriteLine("c. Liệt kê cả hệ chưa có môn VÀ môn chưa khai báo hệ:");

            // Query Syntax
            var leftJoin_Q = from h in dsHe
                             join m in dsMon on h.MaHe equals m.He into subMon
                             from m in subMon.DefaultIfEmpty()
                             select new { TenHe = h.TenHe, TenMon = m != null ? m.TenMon : "(Chưa có môn học)" };

            var monKhongHe_Q = from m in dsMon
                               where !dsHe.Any(h => h.MaHe == m.He)
                               select new { TenHe = "(Chưa khai báo hệ)", TenMon = m.TenMon };

            var cauC_Query = leftJoin_Q.Concat(monKhongHe_Q);

            // Method Syntax
            var leftJoin_M = dsHe.GroupJoin(dsMon, h => h.MaHe, m => m.He, (h, sub) => new { h, sub })
                                 .SelectMany(x => x.sub.DefaultIfEmpty(), (x, m) => new { TenHe = x.h.TenHe, TenMon = m != null ? m.TenMon : "(Chưa có môn học)" });
            var monKhongHe_M = dsMon.Where(m => !dsHe.Any(h => h.MaHe == m.He))
                                    .Select(m => new { TenHe = "(Chưa khai báo hệ)", TenMon = m.TenMon });
            var cauC_Method = leftJoin_M.Concat(monKhongHe_M);

            Console.WriteLine("   [Query Syntax + Concat]:");
            foreach (var item in cauC_Query)
            {
                Console.WriteLine($"   - Hệ: {item.TenHe,-22} | Tên môn: {item.TenMon}");
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // d. Chỉ liệt kê những hệ chưa có môn học VÀ những môn học chưa khai báo hệ
            // ---------------------------------------------------------------------
            Console.WriteLine("d. CHỈ liệt kê hệ chưa có môn VÀ môn chưa khai báo hệ:");

            // Method Syntax
            var heRong_M = dsHe.Where(h => !dsMon.Any(m => m.He == h.MaHe))
                               .Select(h => new { Loai = "Hệ chưa có môn", ThongTin = $"Hệ: {h.TenHe} ({h.MaHe})" });

            var monRong_M = dsMon.Where(m => string.IsNullOrEmpty(m.He) || !dsHe.Any(h => h.MaHe == m.He))
                                 .Select(m => new { Loai = "Môn chưa khai báo hệ", ThongTin = $"Môn: [{m.MaMon}] {m.TenMon}" });

            var cauD_Method = heRong_M.Concat(monRong_M);

            Console.WriteLine("   [Method Syntax]:");
            foreach (var item in cauD_Method)
            {
                Console.WriteLine($"   - [{item.Loai}] -> {item.ThongTin}");
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // e. Lấy 5 môn học đầu tiên có số tiết giảm dần
            // ---------------------------------------------------------------------
            Console.WriteLine("e. Lấy 5 môn học đầu tiên có số tiết giảm dần (Take 5):");

            // Method Syntax
            var cauE_Method = dsMon.OrderByDescending(m => m.SoTiet)
                                   .Take(5)
                                   .Select(m => new
                                   {
                                       TenHe = dsHe.FirstOrDefault(h => h.MaHe == m.He)?.TenHe ?? "(Trống)",
                                       m.MaMon,
                                       m.TenMon,
                                       m.SoTiet
                                   });

            Console.WriteLine("   [Method Syntax]:");
            foreach (var item in cauE_Method)
            {
                Console.WriteLine($"   - [{item.SoTiet} tiết] Hệ: {item.TenHe,-20} | [{item.MaMon}] {item.TenMon}");
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // f. Cho biết tổng số môn học của mỗi hệ: Mã hệ, Tên hệ, Tổng số môn
            // ---------------------------------------------------------------------
            Console.WriteLine("f. Tổng số môn học của mỗi hệ (Mã hệ, Tên hệ, Tổng số môn):");

            // Query Syntax
            var cauF_Query = from h in dsHe
                             join m in dsMon on h.MaHe equals m.He into subMon
                             select new
                             {
                                 h.MaHe,
                                 h.TenHe,
                                 TongSoMon = subMon.Count()
                             };

            Console.WriteLine("   [Query Syntax]:");
            foreach (var item in cauF_Query)
            {
                Console.WriteLine($"   - Mã hệ: {item.MaHe,-5} | Tên hệ: {item.TenHe,-20} | Tổng số môn: {item.TongSoMon}");
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // g. Cho biết có bao nhiêu loại Số tiết khác nhau trong danh sách môn học
            // ---------------------------------------------------------------------
            Console.WriteLine("g. Có bao nhiêu loại Số tiết khác nhau (Distinct):");

            int cauG_Method = dsMon.Select(m => m.SoTiet).Distinct().Count();
            var cacLoaiTiet = dsMon.Select(m => m.SoTiet).Distinct().OrderBy(x => x);

            Console.WriteLine($"   - Tổng số loại số tiết khác nhau: {cauG_Method}");
            Console.WriteLine($"   - Các mức tiết: {string.Join(", ", cacLoaiTiet)}\n");

            // ---------------------------------------------------------------------
            // h. Tìm môn học đầu tiên có tên bắt đầu bằng "Lập trình"
            // ---------------------------------------------------------------------
            Console.WriteLine("h. Môn học đầu tiên có tên bắt đầu bằng 'Lập trình':");

            MonHoc cauH_Method = dsMon.FirstOrDefault(m => m.TenMon.StartsWith("Lập trình"));

            if (cauH_Method != null)
            {
                Console.WriteLine($"   - Môn đầu tiên: [{cauH_Method.MaMon}] {cauH_Method.TenMon} ({cauH_Method.SoTiet} tiết)");
            }
            Console.WriteLine();

            // ---------------------------------------------------------------------
            // i. Liệt kê các môn theo từng hệ, đánh số thứ tự trong mỗi nhóm
            // ---------------------------------------------------------------------
            Console.WriteLine("i. Liệt kê môn theo từng hệ, đánh số thứ tự trong mỗi nhóm:");

            var cauI_Method = dsMon.GroupBy(m => m.He)
                                   .Select(g => new
                                   {
                                       He = string.IsNullOrEmpty(g.Key) ? "Chưa xác định" : g.Key,
                                       DanhSach = g.Select((m, index) => new { STT = index + 1, Mon = m })
                                   });

            Console.WriteLine("   [Method Syntax (Select với Index)]:");
            foreach (var group in cauI_Method)
            {
                Console.WriteLine($"   + Hệ [{group.He}]:");
                foreach (var item in group.DanhSach)
                {
                    Console.WriteLine($"       {item.STT}. [{item.Mon.MaMon}] {item.Mon.TenMon} ({item.Mon.SoTiet} tiết)");
                }
            }

            Console.WriteLine("\nHoàn thành Bài 6.2! Bấm phím bất kỳ để thoát.");
            Console.ReadLine();
        }
    }
}