﻿using System;
using System.Collections.Generic;

namespace Bai6_1
{
    // Định nghĩa lớp He (Bài 6.1)
    public class He
    {
        public string MaHe { get; set; } = "";
        public string TenHe { get; set; } = "";
    }

    // Định nghĩa lớp DuLieu
    public class DuLieu
    {
        public static List<He> DS_He()
        {
            return new List<He>
            {
                new He { MaHe = "KTV", TenHe = "Kỹ thuật viên" },
                new He { MaHe = "CD",  TenHe = "Chuyên đề" },
                new He { MaHe = "QT",  TenHe = "Chứng chỉ quốc tế" }
            };
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("========== BÀI 6.1: XÂY DỰNG LỚP HE VÀ DANH SÁCH DS_HE ==========\n");

            List<He> dsHe = DuLieu.DS_He();

            Console.WriteLine("Danh sách các Hệ đào tạo:");
            Console.WriteLine("{0,-10} | {1,-25}", "Mã hệ", "Tên hệ");
            Console.WriteLine("----------------------------------------");

            foreach (var h in dsHe)
            {
                Console.WriteLine("{0,-10} | {1,-25}", h.MaHe, h.TenHe);
            }

            Console.WriteLine("\nHoàn thành Bài 6.1! Bấm phím bất kỳ để thoát.");
            Console.ReadLine();
        }
    }
}