﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Gọi chạy Bài 3.1
            Bai3_1();

            Console.ReadLine();
        }

        public static void Bai3_1()
        {
            Console.WriteLine("========== BÀI 3.1: THỐNG KÊ MẢNG SỐ ==========\n");

            int[] mangSo = { 50, 42, 12, 3, 9, 8, 1, 50, 3, 42, 85 };

            // ----------------------------------------------------
            // Câu a: Tổng số phần tử, số phần tử chẵn và số phần tử lẻ
            // ----------------------------------------------------
            Console.WriteLine("a. Thống kê số lượng phần tử:");
            int tongSoPhanTu = mangSo.Count();
            int soChan = mangSo.Count(x => x % 2 == 0);
            int soLe = mangSo.Count(x => x % 2 != 0);

            Console.WriteLine($" - Tổng số phần tử: {tongSoPhanTu}");
            Console.WriteLine($" - Số phần tử chẵn : {soChan}");
            Console.WriteLine($" - Số phần tử lẻ   : {soLe}");
            Console.WriteLine();

            // ----------------------------------------------------
            // Câu b: Tính tổng các giá trị, giá trị lớn nhất và nhỏ nhất
            // ----------------------------------------------------
            Console.WriteLine("b. Tính toán tổng, Max, Min:");
            int tongGiaTri = mangSo.Sum();
            int maxGiaTri = mangSo.Max();
            int minGiaTri = mangSo.Min();

            Console.WriteLine($" - Tổng các giá trị : {tongGiaTri}");
            Console.WriteLine($" - Giá trị lớn nhất  : {maxGiaTri}");
            Console.WriteLine($" - Giá trị nhỏ nhất  : {minGiaTri}");
            Console.WriteLine();

            // ----------------------------------------------------
            // Câu c: Cho biết có bao nhiêu giá trị khác nhau trong mảng
            // ----------------------------------------------------
            Console.WriteLine("c. Số lượng giá trị khác nhau trong mảng:");
            var cacGiaTriDuyNhat = mangSo.Distinct();
            int soGiaTriKhatNhau = cacGiaTriDuyNhat.Count();

            Console.WriteLine($" - Số giá trị khác nhau: {soGiaTriKhatNhau}");
            Console.WriteLine($" - Các giá trị đó là  : {string.Join(", ", cacGiaTriDuyNhat)}");
            Console.WriteLine();

            // ----------------------------------------------------
            // Câu d: Phân nhóm các phần tử theo số dư khi chia cho 5
            // ----------------------------------------------------
            Console.WriteLine("d. Phân nhóm các phần tử theo số dư khi chia cho 5:");

            // Query Syntax
            var nhomSoDu_Query = from x in mangSo
                                 group x by x % 5 into g
                                 orderby g.Key
                                 select g;

            // Method Syntax
            var nhomSoDu_Method = mangSo.GroupBy(x => x % 5)
                                       .OrderBy(g => g.Key);

            Console.WriteLine(" -> Kết quả phân nhóm (Query Syntax):");
            foreach (var nhom in nhomSoDu_Query)
            {
                Console.WriteLine($"   + Dư {nhom.Key}: {string.Join(", ", nhom)}");
            }
            Console.WriteLine();
        }
    }
}