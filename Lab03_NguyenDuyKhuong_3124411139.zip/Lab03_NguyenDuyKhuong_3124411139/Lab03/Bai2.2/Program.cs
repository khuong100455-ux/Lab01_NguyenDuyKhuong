﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Gọi các bài tập
            // Bai2_1();
            Bai2_2();

            Console.ReadLine();
        }

        public static void Bai2_2()
        {
            Console.WriteLine("========== BÀI 2.2: TRUY VẤN MẢNG CHUỖI ==========\n");

            string[] mangChuoi = { "đầu", "lòng", "hai", "ả", "tố", "nga", "Thúy", "Kiều", "là", "chị", "em", "là", "Thúy", "Vân" };

            // ----------------------------------------------------
            // Câu a: Các phần tử có 4 ký tự và sắp xếp tăng dần theo ký tự đầu tiên
            // ----------------------------------------------------
            Console.WriteLine("a. Các phần tử có 4 ký tự, sắp xếp tăng dần theo ký tự đầu:");

            // Query Syntax
            var cauA_Query = from s in mangChuoi
                             where s.Length == 4
                             orderby s[0]
                             select s;

            // Method Syntax
            var cauA_Method = mangChuoi.Where(s => s.Length == 4)
                                       .OrderBy(s => s[0]);

            Console.WriteLine(" - [Query Syntax] : " + string.Join(", ", cauA_Query));
            Console.WriteLine(" - [Method Syntax]: " + string.Join(", ", cauA_Method));
            Console.WriteLine();

            // ----------------------------------------------------
            // Câu b: Biến đổi mỗi phần tử thành dạng: <chữ thường> - <CHỮ HOA>
            // ----------------------------------------------------
            Console.WriteLine("b. Biến đổi dạng: <chữ thường> - <CHỮ HOA>:");

            // Query Syntax
            var cauB_Query = from s in mangChuoi
                             select $"{s.ToLower()} - {s.ToUpper()}";

            // Method Syntax
            var cauB_Method = mangChuoi.Select(s => $"{s.ToLower()} - {s.ToUpper()}");

            Console.WriteLine(" - [Query Syntax] :");
            foreach (var item in cauB_Query)
            {
                Console.WriteLine("   " + item);
            }
            Console.WriteLine();

            // ----------------------------------------------------
            // Câu c: Liệt kê các phần tử có chứa ký tự "u"
            // ----------------------------------------------------
            Console.WriteLine("c. Các phần tử chứa ký tự 'u':");

            // Query Syntax
            var cauC_Query = from s in mangChuoi
                             where s.Contains("u")
                             select s;

            // Method Syntax
            var cauC_Method = mangChuoi.Where(s => s.Contains("u"));

            Console.WriteLine(" - [Query Syntax] : " + string.Join(", ", cauC_Query));
            Console.WriteLine(" - [Method Syntax]: " + string.Join(", ", cauC_Method));
            Console.WriteLine();

            // ----------------------------------------------------
            // Câu d: Liệt kê các từ bắt đầu bằng chữ in hoa
            // ----------------------------------------------------
            Console.WriteLine("d. Các từ bắt đầu bằng chữ in hoa (Thúy Kiều Thúy Vân):");

            // Query Syntax
            var cauD_Query = from s in mangChuoi
                             where char.IsUpper(s[0])
                             select s;

            // Method Syntax
            var cauD_Method = mangChuoi.Where(s => char.IsUpper(s[0]));

            Console.WriteLine(" - [Query Syntax] : " + string.Join(" ", cauD_Query));
            Console.WriteLine(" - [Method Syntax]: " + string.Join(" ", cauD_Method));
            Console.WriteLine();
        }
    }
}