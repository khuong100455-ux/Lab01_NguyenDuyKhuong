using System;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyKhachSan
{
    public partial class Form1 : Form
    {
        // Khai báo các điều khiển trên Form (sử dụng dấu ? để tránh cảnh báo null)
        private Label? lblTieuDe, lblHoTen, lblDiaChi, lblSoNgay, lblThanhTien, lblThongTinTongKet, lblSoLuotNguoi, lblTongSoTien;
        private TextBox? txtHoTen, txtDiaChi, txtSoNgay, txtThanhTien, txtSoLuotNguoi, txtTongSoTien;
        private RadioButton? radDon, radDoi, radBa;
        private CheckBox? chkTivi, chkInternet, chkMayNuocNong, chkKaraoke, chkAnSang;
        private Button? btnThanhToan, btnNhapMoi, btnTongKet, btnThoat;
        private GroupBox? grpLoaiPhong, grpTienNghi, grpDichVu;

        // Biến tích lũy cho tổng kết cuối ngày
        private int tongSoLuot = 0;
        private decimal tongTienNgay = 0;

        public Form1()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "frmDangKyKS";
            this.Size = new Size(800, 520);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Load += new EventHandler(Form1_Load);

            // Tiêu đề
            lblTieuDe = new Label() { Text = "KHÁCH SẠN THANH THANH - TRẢ PHÒNG", Font = new Font("Arial", 16, FontStyle.Bold), ForeColor = Color.Chocolate, TextAlign = ContentAlignment.MiddleCenter, Bounds = new Rectangle(20, 10, 740, 40) };
            this.Controls.Add(lblTieuDe);

            // Họ và tên
            lblHoTen = new Label() { Text = "Họ và tên:", Location = new Point(30, 70), AutoSize = true };
            txtHoTen = new TextBox() { Location = new Point(120, 67), Width = 250 };
            txtHoTen.TextChanged += new EventHandler(KiemtraDieuKienNhap);
            this.Controls.Add(lblHoTen);
            this.Controls.Add(txtHoTen);

            // Địa chỉ
            lblDiaChi = new Label() { Text = "Địa chỉ:", Location = new Point(30, 110), AutoSize = true };
            txtDiaChi = new TextBox() { Location = new Point(120, 107), Width = 250 };
            txtDiaChi.TextChanged += new EventHandler(KiemtraDieuKienNhap);
            this.Controls.Add(lblDiaChi);
            this.Controls.Add(txtDiaChi);

            // Số ngày ở
            lblSoNgay = new Label() { Text = "Số ngày ở:", Location = new Point(30, 150), AutoSize = true };
            txtSoNgay = new TextBox() { Location = new Point(120, 147), Width = 100 };
            txtSoNgay.TextChanged += new EventHandler(KiemtraDieuKienNhap);
            this.Controls.Add(lblSoNgay);
            this.Controls.Add(txtSoNgay);

            // Group Loại phòng
            grpLoaiPhong = new GroupBox() { Text = "Loại phòng", Location = new Point(30, 190), Size = new Size(140, 170) };
            radDon = new RadioButton() { Text = "Phòng đơn", Location = new Point(15, 30), Checked = true, AutoSize = true };
            radDoi = new RadioButton() { Text = "Phòng đôi", Location = new Point(15, 70), AutoSize = true };
            radBa = new RadioButton() { Text = "Phòng ba", Location = new Point(15, 110), AutoSize = true };
            grpLoaiPhong.Controls.Add(radDon);
            grpLoaiPhong.Controls.Add(radDoi);
            grpLoaiPhong.Controls.Add(radBa);
            this.Controls.Add(grpLoaiPhong);

            // Group Tiện nghi
            grpTienNghi = new GroupBox() { Text = "Tiện nghi", Location = new Point(180, 190), Size = new Size(140, 170) };
            chkTivi = new CheckBox() { Text = "Tivi", Location = new Point(15, 30), AutoSize = true };
            chkInternet = new CheckBox() { Text = "Internet", Location = new Point(15, 70), AutoSize = true };
            chkMayNuocNong = new CheckBox() { Text = "Máy nước nóng", Location = new Point(15, 110), AutoSize = true };
            grpTienNghi.Controls.Add(chkTivi);
            grpTienNghi.Controls.Add(chkInternet);
            grpTienNghi.Controls.Add(chkMayNuocNong);
            this.Controls.Add(grpTienNghi);

            // Group Dịch vụ
            grpDichVu = new GroupBox() { Text = "Dịch vụ", Location = new Point(330, 190), Size = new Size(140, 170) };
            chkKaraoke = new CheckBox() { Text = "Karaoke", Location = new Point(15, 50), AutoSize = true };
            chkAnSang = new CheckBox() { Text = "Ăn sáng", Location = new Point(15, 100), AutoSize = true };
            grpDichVu.Controls.Add(chkKaraoke);
            grpDichVu.Controls.Add(chkAnSang);
            this.Controls.Add(grpDichVu);

            // Buttons Phía trên
            btnThanhToan = new Button() { Text = "Thanh toán", Location = new Point(490, 65), Size = new Size(100, 30) };
            btnThanhToan.Click += new EventHandler(BtnThanhToan_Click);
            
            btnNhapMoi = new Button() { Text = "Nhập mới", Location = new Point(600, 65), Size = new Size(100, 30) };
            btnNhapMoi.Click += new EventHandler(BtnNhapMoi_Click);

            this.Controls.Add(btnThanhToan);
            this.Controls.Add(btnNhapMoi);

            // Thành tiền
            lblThanhTien = new Label() { Text = "Thành tiền:", Location = new Point(490, 115), AutoSize = true };
            txtThanhTien = new TextBox() { Location = new Point(570, 112), Width = 180, ReadOnly = true };
            this.Controls.Add(lblThanhTien);
            this.Controls.Add(txtThanhTien);

            // Nút Tổng kết
            btnTongKet = new Button() { Text = "Tổng kết", Location = new Point(490, 160), Size = new Size(100, 30) };
            btnTongKet.Click += new EventHandler(BtnTongKet_Click);
            this.Controls.Add(btnTongKet);

            // Thông tin tổng kết
            lblThongTinTongKet = new Label() { Text = "Thông tin tổng kết", Location = new Point(490, 205), Font = new Font("Arial", 9, FontStyle.Bold), AutoSize = true };
            
            lblSoLuotNguoi = new Label() { Text = "Số lượt người:", Location = new Point(490, 235), AutoSize = true };
            txtSoLuotNguoi = new TextBox() { Location = new Point(580, 232), Width = 170, ReadOnly = true };

            lblTongSoTien = new Label() { Text = "Tổng số tiền:", Location = new Point(490, 275), AutoSize = true };
            txtTongSoTien = new TextBox() { Location = new Point(580, 272), Width = 170, ReadOnly = true };

            this.Controls.Add(lblThongTinTongKet);
            this.Controls.Add(lblSoLuotNguoi);
            this.Controls.Add(txtSoLuotNguoi);
            this.Controls.Add(lblTongSoTien);
            this.Controls.Add(txtTongSoTien);

            // Nút Thoát
            btnThoat = new Button() { Text = "Thoát", Location = new Point(490, 330), Size = new Size(210, 30) };
            btnThoat.Click += new EventHandler(BtnThoat_Click);
            this.Controls.Add(btnThoat);
        }

        private void Form1_Load(object? sender, EventArgs e)
        {
            txtHoTen?.Focus();
            if (btnThanhToan != null) btnThanhToan.Enabled = false;
            if (btnNhapMoi != null) btnNhapMoi.Enabled = false;
            if (btnTongKet != null) btnTongKet.Enabled = false;
        }

        private void KiemtraDieuKienNhap(object? sender, EventArgs e)
        {
            if (txtHoTen != null && txtDiaChi != null && txtSoNgay != null && btnThanhToan != null)
            {
                // Làm sạch chuỗi bằng Trim() để tránh lỗi khoảng trắng ẩn
                string hoTen = txtHoTen.Text.Trim();
                string diaChi = txtDiaChi.Text.Trim();
                string soNgay = txtSoNgay.Text.Trim();

                if (!string.IsNullOrEmpty(hoTen) && 
                    !string.IsNullOrEmpty(diaChi) && 
                    !string.IsNullOrEmpty(soNgay))
                {
                    btnThanhToan.Enabled = true;
                }
                else
                {
                    btnThanhToan.Enabled = false;
                }
            }
        }

        private void BtnThanhToan_Click(object? sender, EventArgs e)
        {
            if (txtSoNgay == null || txtThanhTien == null || radDon == null || radDoi == null || radBa == null ||
                chkTivi == null || chkInternet == null || chkMayNuocNong == null || chkKaraoke == null || chkAnSang == null ||
                btnNhapMoi == null || btnTongKet == null || btnThanhToan == null) return;

            // Làm sạch chuỗi trước khi chuyển đổi sang số
            string cleanSoNgay = txtSoNgay.Text.Trim();

            if (!int.TryParse(cleanSoNgay, out int soNgay) || soNgay <= 0)
            {
                MessageBox.Show("Số ngày ở phải là một số nguyên dương hợp lệ!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSoNgay.Focus();
                return;
            }

            decimal tienPhong = 0;
            if (radDon.Checked) tienPhong = 300000 * soNgay;
            else if (radDoi.Checked) tienPhong = 350000 * soNgay;
            else if (radBa.Checked) tienPhong = 400000 * soNgay;

            decimal tienTienNghi = 0;
            if (chkTivi.Checked) tienTienNghi += 10000;
            if (chkInternet.Checked) tienTienNghi += 10000;
            if (chkMayNuocNong.Checked) tienTienNghi += 10000;

            decimal tienDichVu = 0;
            if (chkKaraoke.Checked) tienDichVu += 50000;
            if (chkAnSang.Checked) tienDichVu += (15000 * soNgay);

            decimal thanhTien = tienPhong + tienTienNghi + tienDichVu;
            txtThanhTien.Text = thanhTien.ToString("N0") + " VNĐ";

            tongSoLuot++;
            tongTienNgay += thanhTien;

            btnNhapMoi.Enabled = true;
            btnTongKet.Enabled = true;
            btnThanhToan.Enabled = false;
        }

        private void BtnNhapMoi_Click(object? sender, EventArgs e)
        {
            if (txtHoTen == null || txtDiaChi == null || txtSoNgay == null || txtThanhTien == null ||
                radDon == null || chkTivi == null || chkInternet == null || chkMayNuocNong == null ||
                chkKaraoke == null || chkAnSang == null || btnNhapMoi == null) return;

            txtHoTen.Clear();
            txtDiaChi.Clear();
            txtSoNgay.Clear();
            txtThanhTien.Clear();
            radDon.Checked = true;
            chkTivi.Checked = false;
            chkInternet.Checked = false;
            chkMayNuocNong.Checked = false;
            chkKaraoke.Checked = false;
            chkAnSang.Checked = false;

            btnNhapMoi.Enabled = false;
            txtHoTen.Focus();
        }

        private void BtnTongKet_Click(object? sender, EventArgs e)
        {
            if (txtSoLuotNguoi == null || txtTongSoTien == null || btnTongKet == null) return;

            txtSoLuotNguoi.Text = tongSoLuot.ToString();
            txtTongSoTien.Text = tongTienNgay.ToString("N0") + " VNĐ";

            tongSoLuot = 0;
            tongTienNgay = 0;
            btnTongKet.Enabled = false;
        }

        private void BtnThoat_Click(object? sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát khỏi chương trình hay không?", "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}