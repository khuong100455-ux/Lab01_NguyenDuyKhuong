using System;
using System.Drawing;
using System.Windows.Forms;

namespace MayTinhBoTui
{
    public partial class Form1 : Form
    {
        private Label? lblTieuDe;
        private TextBox? txtManHinh;
        private Button[] btnSo = new Button[10];
        private Button? btnCong, btnTru, btnNhan, btnChia, btnBang, btnXoa;

        // Các biến lưu trữ logic máy tính
        private double soHienTai = 0;
        private double soLuuTru = 0;
        private string phepToan = "";
        private bool vuaTinhToan = false;
        private bool đangNhapSoMoi = false; // Cờ hiệu để reset màn hình khi nhập số tiếp theo

        public Form1()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "MayTinhBoTui";
            this.Size = new Size(330, 420);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Tiêu đề
            lblTieuDe = new Label()
            {
                Text = "Máy Tính Bỏ Túi",
                Font = new Font("Arial", 16, FontStyle.Bold),
                ForeColor = Color.Red,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(20, 10),
                Size = new Size(270, 35)
            };
            this.Controls.Add(lblTieuDe);

            // Màn hình hiển thị
            txtManHinh = new TextBox()
            {
                Text = "0",
                Font = new Font("Arial", 16, FontStyle.Bold),
                ForeColor = Color.Blue,
                TextAlign = HorizontalAlignment.Right,
                Location = new Point(20, 50),
                Size = new Size(270, 35),
                ReadOnly = true
            };
            this.Controls.Add(txtManHinh);

            // Tọa độ bắt đầu cho các nút bấm
            int startX = 20;
            int startY = 95;
            int width = 60;
            int height = 45;
            int gap = 10;

            // Mảng vị trí (X, Y) cho từng nút số theo thứ tự 1->9 và số 0
            Point[] viTriSo = {
                new Point(startX, startY),                             // 1
                new Point(startX + width + gap, startY),         // 2
                new Point(startX + (width + gap) * 2, startY),   // 3
                new Point(startX + (width + gap) * 3, startY),   // 4
                new Point(startX, startY + height + gap),          // 5
                new Point(startX + width + gap, startY + height + gap),         // 6
                new Point(startX + (width + gap) * 2, startY + height + gap),   // 7
                new Point(startX + (width + gap) * 3, startY + height + gap),   // 8
                new Point(startX, startY + (height + gap) * 2),     // 9
                new Point(startX + width + gap, startY + (height + gap) * 2)   // 0
            };

            for (int i = 0; i <= 9; i++)
            {
                btnSo[i] = new Button()
                {
                    Text = i.ToString(),
                    Font = new Font("Arial", 12, FontStyle.Bold),
                    Location = viTriSo[i],
                    Size = new Size(width, height)
                };
                int val = i;
                btnSo[i].Click += (s, e) => BtnSo_Click(val);
                this.Controls.Add(btnSo[i]);
            }

            // Nút Dấu bằng (=) ở hàng 3, cột 3
            btnBang = new Button()
            {
                Text = "=",
                Font = new Font("Arial", 12, FontStyle.Bold),
                Location = new Point(startX + (width + gap) * 2, startY + (height + gap) * 2),
                Size = new Size(width, height)
            };
            btnBang.Click += BtnBang_Click;
            this.Controls.Add(btnBang);

            // Nút Xóa (C) ở hàng 3, cột 4
            btnXoa = new Button()
            {
                Text = "C",
                Font = new Font("Arial", 12, FontStyle.Bold),
                Location = new Point(startX + (width + gap) * 3, startY + (height + gap) * 2),
                Size = new Size(width, height)
            };
            btnXoa.Click += BtnXoa_Click;
            this.Controls.Add(btnXoa);

            // Hàng 4: Các phép toán +, -, *, /
            string[] phepToans = { "+", "-", "*", "/" };
            Button[] btnPhepToanArr = new Button[4];

            for (int i = 0; i < 4; i++)
            {
                btnPhepToanArr[i] = new Button()
                {
                    Text = phepToans[i],
                    Font = new Font("Arial", 14, FontStyle.Bold),
                    Location = new Point(startX + (width + gap) * i, startY + (height + gap) * 3),
                    Size = new Size(width, height)
                };
                string pt = phepToans[i];
                btnPhepToanArr[i].Click += (s, e) => BtnPhepToan_Click(pt);
                this.Controls.Add(btnPhepToanArr[i]);
            }

            btnCong = btnPhepToanArr[0];
            btnTru = btnPhepToanArr[1];
            btnNhan = btnPhepToanArr[2];
            btnChia = btnPhepToanArr[3];
        }

        // Sự kiện khi bấm phím số (0-9)
        private void BtnSo_Click(int so)
        {
            if (txtManHinh == null) return;

            if (txtManHinh.Text == "0" || đangNhapSoMoi || vuaTinhToan)
            {
                txtManHinh.Text = so.ToString();
                đangNhapSoMoi = false;
                vuaTinhToan = false;
            }
            else
            {
                txtManHinh.Text += so.ToString();
            }
        }

        // Sự kiện khi bấm các phép tính (+, -, *, /)
        private void BtnPhepToan_Click(string pt)
        {
            if (txtManHinh == null) return;

            double.TryParse(txtManHinh.Text, out soLuuTru);
            phepToan = pt;
            đangNhapSoMoi = true; // Đánh dấu sẵn sàng nhận số hạng tiếp theo
            vuaTinhToan = false;
        }

        // Sự kiện nút Bằng (=)
        private void BtnBang_Click(object? sender, EventArgs e)
        {
            if (txtManHinh == null) return;

            double.TryParse(txtManHinh.Text, out soHienTai);
            double ketQua = 0;

            switch (phepToan)
            {
                case "+":
                    ketQua = soLuuTru + soHienTai;
                    break;
                case "-":
                    ketQua = soLuuTru - soHienTai;
                    break;
                case "*":
                    ketQua = soLuuTru * soHienTai;
                    break;
                case "/":
                    if (soHienTai == 0)
                    {
                        MessageBox.Show("Không thể chia cho số 0!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    ketQua = soLuuTru / soHienTai;
                    break;
                default:
                    return;
            }

            txtManHinh.Text = ketQua.ToString();
            soLuuTru = ketQua;
            vuaTinhToan = true;
            đangNhapSoMoi = false;
        }

        // Sự kiện nút Xóa (C) - Reset máy tính về 0
        private void BtnXoa_Click(object? sender, EventArgs e)
        {
            if (txtManHinh == null) return;

            txtManHinh.Text = "0";
            soHienTai = 0;
            soLuuTru = 0;
            phepToan = "";
            vuaTinhToan = false;
            đangNhapSoMoi = false;
        }
    }
}